(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 9239:
/***/ ((module) => {

// Exports
module.exports = {
	"Footer": "Footer_Footer__xoBiX",
	"FooterLeft": "Footer_FooterLeft__RF2Bt",
	"FooterRight": "Footer_FooterRight__i8JSp"
};


/***/ }),

/***/ 7371:
/***/ ((module) => {

// Exports
module.exports = {
	"Header": "Header_Header__UmNKh",
	"Initial": "Header_Initial__oTWUC",
	"NavWrapper": "Header_NavWrapper__F_h3w",
	"OpenNav": "Header_OpenNav__OqbKD",
	"PrivacyHeader": "Header_PrivacyHeader__fLSZv",
	"Close": "Header_Close__QmjLj",
	"OnScroll": "Header_OnScroll__37frV",
	"OnScrollDisble": "Header_OnScrollDisble___k3uS",
	"Open": "Header_Open__rF6tq",
	"Nav": "Header_Nav__jAu4y",
	"NavList": "Header_NavList__LqvmL"
};


/***/ }),

/***/ 249:
/***/ ((module) => {

// Exports
module.exports = {
	"MobileNav": "MobileNav_MobileNav__qkrhY",
	"LinksWrapper": "MobileNav_LinksWrapper__ZPXMw",
	"NavList": "MobileNav_NavList__y3Jtq",
	"Open": "MobileNav_Open__kQ6up"
};


/***/ }),

/***/ 995:
/***/ ((module) => {

// Exports
module.exports = {
	"SocialMedia": "SocialMedia_SocialMedia__uEfXZ"
};


/***/ }),

/***/ 7603:
/***/ ((module) => {

// Exports
module.exports = {
	"Logo": "Logo_Logo__EI9IV"
};


/***/ }),

/***/ 9975:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/ui/Navlink.js



const NavLink = ({ children , setOpen , href  })=>{
    const { route  } = (0,router_.useRouter)();
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        className: "/" + href === route ? "active-link" : "",
        onClick: ()=>setOpen(false),
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: `/${href}`,
            children: children
        })
    });
};
/* harmony default export */ const Navlink = (NavLink);

;// CONCATENATED MODULE: external "hamburger-react"
const external_hamburger_react_namespaceObject = require("hamburger-react");
var external_hamburger_react_default = /*#__PURE__*/__webpack_require__.n(external_hamburger_react_namespaceObject);
// EXTERNAL MODULE: ./src/components/ui/Logo.module.css
var Logo_module = __webpack_require__(7603);
var Logo_module_default = /*#__PURE__*/__webpack_require__.n(Logo_module);
;// CONCATENATED MODULE: ./src/components/svgs/logo.svg
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgLogo = function SvgLogo(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 219.353,
    height: 219.353,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 909 909"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M455 0c251 0 454 204 454 455S706 909 455 909 0 706 0 455 204 0 455 0zM309 204c-39 0-71 31-71 71 0 39 32 70 71 70s71-31 71-70c0-40-32-71-71-71zm190 420c0 25-20 44-44 44-25 0-45-19-45-44v-79c0-20-8-38-21-51-13-14-31-22-51-22s-38 8-52 22c-13 13-21 31-21 51v151c0 25-20 45-44 45-25 0-45-20-45-45V545c0-45 18-85 48-114 29-29 69-48 114-48 33 0 63 10 89 27 8-16 18-30 31-43 29-29 69-47 114-47 44 0 84 18 114 47 29 29 47 70 47 114v152c0 24-20 44-44 44-25 0-45-20-45-44V481c0-20-8-38-21-51s-31-21-51-21-38 8-52 21c-13 13-21 31-21 51v143zm102-484c39 0 70 32 70 71s-31 71-70 71-71-32-71-71 32-71 71-71z",
    style: {
      fill: "#fff"
    }
  }));
};
/* harmony default export */ const logo = (SvgLogo);
;// CONCATENATED MODULE: ./src/components/svgs/logo-blue.svg
function logo_blue_extends() { logo_blue_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return logo_blue_extends.apply(this, arguments); }

var SvgLogoBlue = function SvgLogoBlue(props) {
  return /*#__PURE__*/external_react_.createElement("svg", logo_blue_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 219.353,
    height: 219.353,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 909 909"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M455 0c251 0 454 204 454 455S706 909 455 909 0 706 0 455 204 0 455 0zM309 204c-39 0-71 31-71 71 0 39 32 70 71 70s71-31 71-70c0-40-32-71-71-71zm190 420c0 25-20 44-44 44-25 0-45-19-45-44v-79c0-20-8-38-21-51-13-14-31-22-51-22s-38 8-52 22c-13 13-21 31-21 51v151c0 25-20 45-44 45-25 0-45-20-45-45V545c0-45 18-85 48-114 29-29 69-48 114-48 33 0 63 10 89 27 8-16 18-30 31-43 29-29 69-47 114-47 44 0 84 18 114 47 29 29 47 70 47 114v152c0 24-20 44-44 44-25 0-45-20-45-44V481c0-20-8-38-21-51s-31-21-51-21-38 8-52 21c-13 13-21 31-21 51v143zm102-484c39 0 70 32 70 71s-31 71-70 71-71-32-71-71 32-71 71-71z",
    style: {
      fill: "#00aae6"
    }
  }));
};
/* harmony default export */ const logo_blue = (SvgLogoBlue);
;// CONCATENATED MODULE: ./src/components/ui/Logo.js





const Logo = ({ isWhite , isOpen  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            opacity: isOpen ? "0" : "1"
        },
        className: `${(Logo_module_default()).Logo} ${!isWhite ? (Logo_module_default()).RegularColor : (Logo_module_default()).White}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: "/",
            children: isWhite ? /*#__PURE__*/ jsx_runtime_.jsx(logo, {}) : /*#__PURE__*/ jsx_runtime_.jsx(logo_blue, {})
        })
    });
};
/* harmony default export */ const ui_Logo = (Logo);

// EXTERNAL MODULE: ./src/components/layout/header/Header.module.css
var Header_module = __webpack_require__(7371);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
;// CONCATENATED MODULE: ./src/data/data.js
const NAV_LINKS = [
    {
        id: 1,
        name: "home",
        href: ""
    },
    {
        id: 2,
        name: "our mission",
        href: "our-mission"
    },
    {
        id: 3,
        name: "our team",
        href: "our-team"
    },
    {
        id: 4,
        name: "get involved",
        href: "get-involved"
    }
];

;// CONCATENATED MODULE: ./src/components/svgs/linkeding.svg
function linkeding_extends() { linkeding_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return linkeding_extends.apply(this, arguments); }

var SvgLinkeding = function SvgLinkeding(props) {
  return /*#__PURE__*/external_react_.createElement("svg", linkeding_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 180.159,
    height: 180.159,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 1457 1457"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M729 0c402 0 728 326 728 729 0 402-326 728-728 728-403 0-729-326-729-728C0 326 326 0 729 0zM531 393c0 53-43 96-96 96-52 0-96-43-96-95 0-53 43-97 96-97s96 43 96 96zm251 242c11-13 20-25 32-36 35-33 76-50 125-49 26 0 52 2 78 9 59 17 93 57 109 115 12 43 15 87 15 131v281c0 8-3 11-11 11-48-1-97-1-145 0-8 0-10-3-10-11V819c0-22-1-44-8-66-11-40-40-60-82-58-57 3-86 31-94 89-1 14-2 28-2 42v260c0 8-2 11-11 11-48-1-97-1-145 0-8 0-10-2-10-10V573c0-8 2-10 10-10h139c8 0 10 2 10 10v62zM518 830v255c0 9-2 12-12 12-48-1-96-1-144 0-8 0-10-2-10-10V572c0-7 2-9 9-9h147c9 0 10 3 10 11v256z",
    style: {
      fill: "#fff"
    }
  }));
};
/* harmony default export */ const linkeding = (SvgLinkeding);
;// CONCATENATED MODULE: ./src/components/svgs/facebook.svg
function facebook_extends() { facebook_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return facebook_extends.apply(this, arguments); }

var SvgFacebook = function SvgFacebook(props) {
  return /*#__PURE__*/external_react_.createElement("svg", facebook_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 180.159,
    height: 180.159,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 5249 5249"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M2624 0C1177 0 0 1177 0 2624c0 1448 1177 2625 2624 2625 1448 0 2625-1177 2625-2625C5249 1177 4072 0 2624 0zm653 2717h-427v1522h-633V2717h-300v-538h300v-348c0-249 119-638 639-638l469 1v522h-340c-56 0-135 28-135 147v316h482l-55 538z",
    style: {
      fill: "#fff"
    }
  }));
};
/* harmony default export */ const facebook = (SvgFacebook);
;// CONCATENATED MODULE: ./src/components/svgs/youtube.svg
function youtube_extends() { youtube_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return youtube_extends.apply(this, arguments); }

var SvgYoutube = function SvgYoutube(props) {
  return /*#__PURE__*/external_react_.createElement("svg", youtube_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 180,
    height: 180,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 1338 1338"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M594 782V556l195 113-195 113zm744-113c0 370-299 669-669 669-369 0-669-299-669-669C0 300 300 0 669 0c370 0 669 300 669 669zm-309-181c-8-32-34-58-66-66-59-16-294-16-294-16s-235 0-293 16c-33 8-58 34-67 66-16 59-16 181-16 181s0 122 16 181c9 32 34 58 67 66 58 16 293 16 293 16s235 0 294-16c32-8 58-34 66-66 16-59 16-181 16-181s0-122-16-181z",
    style: {
      fill: "#fff",
      fillRule: "nonzero"
    }
  }));
};
/* harmony default export */ const youtube = (SvgYoutube);
;// CONCATENATED MODULE: ./src/components/svgs/emal.svg
var _defs, _g;
function emal_extends() { emal_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return emal_extends.apply(this, arguments); }

var SvgEmal = function SvgEmal(props) {
  return /*#__PURE__*/external_react_.createElement("svg", emal_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 180.16,
    height: 180.16,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 858 858"
  }, props), _defs || (_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("style", null, ".emal_svg__fil0{fill:#fff}"))), _g || (_g = /*#__PURE__*/external_react_.createElement("g", {
    id: "emal_svg__Layer_x0020_1"
  }, /*#__PURE__*/external_react_.createElement("g", {
    id: "emal_svg___2472621585392"
  }, /*#__PURE__*/external_react_.createElement("path", {
    className: "emal_svg__fil0",
    d: "M429 858C193 858 0 666 0 429 0 193 193 0 429 0c237 0 429 193 429 429 0 237-192 429-429 429zm277-570v282c0 30-25 54-54 54H207c-30 0-54-24-54-54V288c0-30 24-54 54-54h445c29 0 54 24 54 54z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    className: "emal_svg__fil0",
    d: "M618 278 429 429 240 278z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    className: "emal_svg__fil0",
    d: "M652 580c5 0 9-4 9-10V301L443 474c-4 4-9 5-14 5s-10-1-14-5L197 301v269c0 6 4 10 10 10h445z"
  })))));
};
/* harmony default export */ const emal = (SvgEmal);
// EXTERNAL MODULE: ./src/components/layout/sections/SocialMedia.module.css
var SocialMedia_module = __webpack_require__(995);
var SocialMedia_module_default = /*#__PURE__*/__webpack_require__.n(SocialMedia_module);
;// CONCATENATED MODULE: ./src/components/svgs/instagram.svg
function instagram_extends() { instagram_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return instagram_extends.apply(this, arguments); }

var SvgInstagram = function SvgInstagram(props) {
  return /*#__PURE__*/external_react_.createElement("svg", instagram_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 180.159,
    height: 180.159,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 3945 3945"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "M1973 0c1089 0 1972 883 1972 1973 0 1089-883 1972-1972 1972C883 3945 0 3062 0 1973 0 883 883 0 1973 0zm0 733c-337 0-380 2-512 8s-222 27-301 58c-82 31-151 74-220 143s-111 138-143 220c-31 79-52 169-58 301s-7 174-7 511 1 380 7 512 27 222 58 301c32 82 74 151 143 220s138 112 220 143c79 31 169 52 301 58s175 7 512 7 379-1 511-7 223-27 302-58c81-31 150-74 219-143s112-138 144-220c30-79 51-169 57-301s8-175 8-512-2-379-8-511-27-222-57-301c-32-82-75-151-144-220s-138-112-219-143c-79-31-170-52-302-58s-174-8-511-8zm0 224c331 0 370 1 501 7 121 6 187 26 231 43 58 23 99 49 142 93 44 43 71 85 93 143 17 43 37 109 43 230 6 131 7 170 7 501 0 332-1 371-7 502-6 121-26 187-43 230-22 58-49 100-93 143-43 43-84 70-142 93-44 17-110 37-231 43-131 6-170 7-501 7-332 0-371-1-502-7-121-6-186-26-230-43-58-23-99-50-143-93-43-43-70-85-93-143-17-43-37-109-42-230-6-131-8-170-8-502 0-331 2-370 8-501 5-121 25-187 42-230 23-58 50-100 93-143 44-44 85-70 143-93 44-17 109-37 230-43 131-6 170-7 502-7zm0 1431c-229 0-414-185-414-414 0-228 185-413 414-413 228 0 413 185 413 413 0 229-185 414-413 414zm0-1051c-352 0-638 286-638 637 0 352 286 638 638 638s637-286 637-638c0-351-285-637-637-637zm662-179c85 0 155 69 155 154s-70 154-155 154-154-69-154-154 69-154 154-154z",
    style: {
      fill: "#fff"
    }
  }));
};
/* harmony default export */ const instagram = (SvgInstagram);
;// CONCATENATED MODULE: ./src/components/layout/sections/SocialMedia.js







const SocialMedia = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (SocialMedia_module_default()).SocialMedia,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "mailto:Info@mpathyapps.com",
                target: "_blank",
                children: /*#__PURE__*/ jsx_runtime_.jsx(emal, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "https://www.linkedin.com/company/mpathyfoundation/about/",
                target: "_blank",
                children: /*#__PURE__*/ jsx_runtime_.jsx(linkeding, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "https://m.facebook.com/Mpathyapps/",
                target: "_blank",
                children: /*#__PURE__*/ jsx_runtime_.jsx(facebook, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "https://www.instagram.com/mpathyapps/",
                target: "_blank",
                children: /*#__PURE__*/ jsx_runtime_.jsx(instagram, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "https://www.youtube.com/channel/UCwxVvq5LYsqCLUlW7HyhFMg",
                target: "_blank",
                children: /*#__PURE__*/ jsx_runtime_.jsx(youtube, {})
            })
        ]
    });
};
/* harmony default export */ const sections_SocialMedia = (SocialMedia);

// EXTERNAL MODULE: ./src/components/layout/header/MobileNav.module.css
var MobileNav_module = __webpack_require__(249);
var MobileNav_module_default = /*#__PURE__*/__webpack_require__.n(MobileNav_module);
;// CONCATENATED MODULE: ./src/components/layout/header/MobileNav.js






// import LinkedIn from "../../svgs/LinkedIn";
// import Mail from "../../svgs/Mail";
const MobileNav = ({ setOpen , isOpen  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${(MobileNav_module_default()).MobileNav} ${isOpen ? (MobileNav_module_default()).Open : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ui_Logo, {
                isWhite: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: (MobileNav_module_default()).Nav,
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: (MobileNav_module_default()).NavList,
                    children: NAV_LINKS.map(({ name , id , href  })=>/*#__PURE__*/ jsx_runtime_.jsx(Navlink, {
                            href: `${href}`,
                            setOpen: setOpen,
                            children: name
                        }, id))
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (MobileNav_module_default()).LinksWrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx(sections_SocialMedia, {})
            })
        ]
    });
};
/* harmony default export */ const header_MobileNav = (MobileNav);

;// CONCATENATED MODULE: ./src/components/layout/header/Header.js









const Header = ()=>{
    const [isOpen, setOpen] = (0,external_react_.useState)(false);
    const [headerIsVisible, setHeaderIsVisible] = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    const isMainPage = router.pathname === "/";
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>setHeaderIsVisible(window.pageYOffset > 1);
        document.addEventListener("scroll", handleScroll);
        return ()=>{
            document.removeEventListener("scroll", handleScroll);
        };
    }, []);
    (0,external_react_.useEffect)(()=>{
        if (isOpen) {
            document.body.style.height = "100vh";
            document.body.style.overflowY = "hidden";
        } else {
            document.body.style.height = "auto";
            document.body.style.overflowY = "auto";
        }
    }, [
        isOpen
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_MobileNav, {
                isOpen: isOpen,
                setOpen: ()=>{
                    setOpen(false);
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: ` ${(Header_module_default()).Header} ${isOpen ? (Header_module_default()).OpenNav : ""}  ${isMainPage ? (Header_module_default()).Initial : (Header_module_default()).PrivacyHeader} ${headerIsVisible ? (Header_module_default()).Close : ""}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `${(Header_module_default()).NavWrapper} $ container`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ui_Logo, {
                            isWhite: true
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                            className: (Header_module_default()).Nav,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: (Header_module_default()).NavList,
                                children: NAV_LINKS.map(({ name , id , href  })=>/*#__PURE__*/ jsx_runtime_.jsx(Navlink, {
                                        href: href,
                                        setOpen: setOpen,
                                        children: name
                                    }, id))
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((external_hamburger_react_default()), {
                            toggled: isOpen,
                            toggle: setOpen
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: `${(Header_module_default()).Header} ${isOpen ? (Header_module_default()).OpenNav : ""}  ${(Header_module_default()).OnScroll} ${headerIsVisible ? (Header_module_default()).Open : ""} ${headerIsVisible ? "visible-header" : ""}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `${(Header_module_default()).NavWrapper} container`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(ui_Logo, {
                            isWhite: false,
                            isOpen: isOpen
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                            className: (Header_module_default()).Nav,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: (Header_module_default()).NavList,
                                children: NAV_LINKS.map(({ name , id , href  })=>/*#__PURE__*/ jsx_runtime_.jsx(Navlink, {
                                        href: href,
                                        setOpen: setOpen,
                                        children: name
                                    }, id))
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((external_hamburger_react_default()), {
                            toggled: isOpen,
                            toggle: setOpen
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const header_Header = (Header);

// EXTERNAL MODULE: ./src/components/layout/footer/Footer.module.css
var Footer_module = __webpack_require__(9239);
var Footer_module_default = /*#__PURE__*/__webpack_require__.n(Footer_module);
;// CONCATENATED MODULE: ./src/components/layout/footer/Footer.js




const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: `${(Footer_module_default()).Footer}`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (Footer_module_default()).FooterLeft,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(sections_SocialMedia, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (Footer_module_default()).FooterRight,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Copyright \xa9 2023 Mpathy Apps CIC. "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "All rights reserved."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/privacy-policy",
                            children: "Privacy policy"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const footer_Footer = (Footer);

;// CONCATENATED MODULE: ./src/components/layout/Layout.js



const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(footer_Footer, {})
        ]
    });
};
/* harmony default export */ const layout_Layout = (Layout);

;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./src/lib/gtag.js
const pageview = (url)=>{
    if (url === "/privacy-policy") return;
    window.gtag("config", "G-CBZTCHWWJ9", {
        page_path: url
    });
};
const gtag_event = ({ action , category , label , value  })=>{
    window.gtag("event", action, {
        event_category: category,
        event_label: label,
        value
    });
};

;// CONCATENATED MODULE: ./pages/_app.js








function MyApp({ Component , pageProps  }) {
    const router = (0,router_.useRouter)();
    (0,external_react_.useEffect)(()=>{
        const handleRouteChange = (url)=>{
            pageview(url);
        };
        router.events.on("routeChangeComplete", handleRouteChange);
        return ()=>{
            router.events.off("routeChangeComplete", handleRouteChange);
        };
    }, [
        router.events
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                strategy: "afterInteractive",
                src: `https://www.googletagmanager.com/gtag/js?id=${"G-CBZTCHWWJ9"}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                id: "google-analytics",
                strategy: "afterInteractive",
                dangerouslySetInnerHTML: {
                    __html: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${"G-CBZTCHWWJ9"}', {
            page_path: window.location.pathname,
          });
        `
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                    name: "viewport",
                    content: "width=device-width, initial-scale=1.0"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout_Layout, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664], () => (__webpack_exec__(9975)));
module.exports = __webpack_exports__;

})();