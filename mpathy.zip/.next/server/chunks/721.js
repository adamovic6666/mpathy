exports.id = 721;
exports.ids = [721];
exports.modules = {

/***/ 7292:
/***/ ((module) => {

// Exports
module.exports = {
	"Hero": "Hero_Hero__HqQm4",
	"HeroSvgJoinUsPosition": "Hero_HeroSvgJoinUsPosition__4jNIH",
	"Title": "Hero_Title__dr8kD",
	"HeroSvgOurMissionPosition": "Hero_HeroSvgOurMissionPosition__quMnr",
	"OurCrewHero": "Hero_OurCrewHero__frIhH",
	"HeroExtendedPadding": "Hero_HeroExtendedPadding__Nv0id",
	"Image": "Hero_Image__qidZS",
	"OurMissionImage": "Hero_OurMissionImage__Tifei",
	"JoinUseImage": "Hero_JoinUseImage__557AY",
	"LinksWrapper": "Hero_LinksWrapper__LTIiB",
	"MaxWidth": "Hero_MaxWidth__Na_BA"
};


/***/ }),

/***/ 4514:
/***/ ((module) => {

// Exports
module.exports = {
	"Link": "Link_Link__BJA55",
	"Transparent": "Link_Transparent__3q4gY"
};


/***/ }),

/***/ 7979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ sections_Hero)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/layout/sections/Hero.module.css
var Hero_module = __webpack_require__(7292);
var Hero_module_default = /*#__PURE__*/__webpack_require__.n(Hero_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/components/ui/Link.module.css
var Link_module = __webpack_require__(4514);
var Link_module_default = /*#__PURE__*/__webpack_require__.n(Link_module);
;// CONCATENATED MODULE: ./src/components/ui/Link.js



const Link = ({ href , children , type  })=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: href,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `${type === "transparent" ? (Link_module_default()).Transparent : ""} ${(Link_module_default()).Link}`,
            children: children
        })
    });
/* harmony default export */ const ui_Link = (Link);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/svgs/mpathy-hero.svg
var _defs, _path, _path2, _path3, _path4, _path5, _path6, _path7, _path8, _path9, _path10, _path11, _path12, _path13, _path14, _path15, _path16, _path17, _path18, _path19, _path20, _path21, _path22, _path23, _path24, _path25, _path26, _path27, _path28, _path29, _path30, _path31, _path32, _path33, _path34, _path35, _path36, _path37, _path38, _path39, _path40, _path41, _path42, _path43, _path44, _path45, _path46, _path47, _path48, _path49, _path50, _path51, _path52, _path53, _path54, _path55, _path56, _path57, _path58, _path59, _path60, _path61, _path62, _path63, _path64, _path65, _path66, _path67, _path68, _path69;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgMpathyHero = function SvgMpathyHero(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 460.906,
    height: 576.605,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 5067 6242"
  }, props), _defs || (_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("style", null, ".mpathy-hero_svg__fil2,.mpathy-hero_svg__fil3{fill:#000;fill-rule:nonzero}.mpathy-hero_svg__fil2{fill:#371a45}.mpathy-hero_svg__fil10,.mpathy-hero_svg__fil13,.mpathy-hero_svg__fil9{fill:#857b8c;fill-rule:nonzero}.mpathy-hero_svg__fil13,.mpathy-hero_svg__fil9{fill:#8c7b94}.mpathy-hero_svg__fil13{fill:#999}.mpathy-hero_svg__fil16,.mpathy-hero_svg__fil18,.mpathy-hero_svg__fil5{fill:#a26dbd;fill-rule:nonzero}.mpathy-hero_svg__fil16,.mpathy-hero_svg__fil5{fill:#afafb2}.mpathy-hero_svg__fil16{fill:#b51953}.mpathy-hero_svg__fil4,.mpathy-hero_svg__fil7,.mpathy-hero_svg__fil8{fill:#b9afbe;fill-rule:nonzero}.mpathy-hero_svg__fil7,.mpathy-hero_svg__fil8{fill:#c3bac7}.mpathy-hero_svg__fil8{fill:#e7e7e8}.mpathy-hero_svg__fil1,.mpathy-hero_svg__fil17,.mpathy-hero_svg__fil6{fill:#f4e1ff;fill-rule:nonzero}.mpathy-hero_svg__fil1,.mpathy-hero_svg__fil17{fill:#fc8cad}.mpathy-hero_svg__fil1{fill:#fff}"))), /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-hero_svg__Layer_x0020_1"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M2533 6242C1134 6242 0 6155 0 6047c0-38 148-75 403-105 16 8 32 15 50 19 19 35 32 39 43 43 44 14 106 19 170 19 125 0 256-19 264-20s743-100 1317-130c79 47 143 82 185 105 21 11 43 16 66 16s46-5 67-17c42-23 106-60 185-107 582 25 1378 132 1387 133 8 1 139 20 264 20 64 0 126-5 170-19 11-4 24-8 43-43 17-4 34-11 50-19 255 30 403 67 403 105 0 108-1134 195-2534 195z",
    style: {
      fill: "#000",
      fillRule: "nonzero",
      fillOpacity: 0.14902
    }
  }), _path || (_path = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M4053 5541H872s-3-326 59-810c11-87 25-179 41-275 70-424 189-928 392-1429 31-76 64-151 98-226 27-60 56-119 86-178 22-43 44-86 68-129h1693c23 43 46 86 68 129 30 60 59 120 87 180 39 86 76 172 110 258 195 490 310 981 379 1395 16 97 29 189 41 276 62 484 59 809 59 809z"
  })), _path2 || (_path2 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M4090 5579H835l-1-38c0-4-3-424 87-1008 83-539 266-1334 662-2057 10-18 33-25 51-15s25 33 15 51C964 3763 914 5250 910 5503h3105c-2-114-12-481-86-960-83-533-263-1318-653-2031-10-18-4-41 15-51 18-10 41-3 51 15 396 723 578 1518 662 2057 90 584 86 1004 86 1008v38z"
  })), _path3 || (_path3 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M1507 2757c-297 0-538 241-538 538v1530c0 296 241 538 538 538h1911c297 0 538-242 538-538V3295c0-297-241-538-538-538H1507zm1911 2681H1507c-338 0-614-275-614-613V3295c0-338 276-614 614-614h1911c338 0 613 276 613 614v1530c0 338-275 613-613 613z"
  })), _path4 || (_path4 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M4907 4688s-263 1252-348 1280c-123 39-417-2-417-2s-612-83-1160-121c-161-11-316-18-449-18-152 0-334 9-520 23-528 40-1088 116-1088 116s-295 41-417 2c-86-28-348-1280-348-1280 156-226 517-202 689 197 4-8 9-15 13-21 67-98 161-184 295-232 20-8 41-14 61-19 285-74 543 52 726 189 17 13 32 25 48 38 1 1 3 2 4 4 12 10 24 20 35 30 55 48 117 88 182 119 9 4 19 8 28 12 92 39 191 59 292 59 185 0 363-68 502-190 155-136 393-292 666-283 68 3 138 15 209 41 110 39 192 104 255 179 20 24 37 48 53 74 172-399 533-423 689-197z"
  })), _path5 || (_path5 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M4403 5947c-97 0-205-12-256-19-4 0-214-29-496-59-87-178-111-371-73-576 185-152 367-321 518-501 16 16 31 33 46 51-82 105-175 208-274 306-1 0-2 1-2 2-85 83-46 227 69 255 128 31 207 53 207 53s96 13 200 18c-4 43-8 85-9 125h-1c-19 0-36 15-38 34-1 21 14 40 35 41l4 1c3 86 17 160 48 212v1s0 1 1 1v1c14 22 30 40 50 54h-29zm-3739 0h-29c19-13 36-31 49-54h1v-2h1c30-52 45-127 48-213l4-1c21-1 36-20 34-41-1-19-18-34-37-34h-1c-1-40-5-82-10-126 105-4 201-17 201-17s53-15 142-37c114-29 153-172 69-255-90-87-174-178-249-272 13-20 27-39 42-57 172 198 379 381 586 541 17 173-12 336-86 488-289 31-505 61-510 61-50 7-159 19-255 19zm2922-86c-224-23-484-48-722-61 183-114 417-271 649-455-23 182 2 356 73 516zm-2091-1c60-136 86-283 79-435 201 152 399 282 558 379-212 14-439 35-637 56z"
  })), _path6 || (_path6 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M666 6023c-64 0-126-5-170-19-31-11-73-24-231-678-75-313-141-627-142-630l-3-16 9-13c77-112 203-171 336-158 157 15 297 124 390 301 76-100 173-172 289-214 235-85 481-46 733 114 18 11 23 35 12 52-11 18-35 23-52 12-231-147-456-183-667-107-120 44-217 123-290 238l-38 60-28-66c-80-185-210-300-357-315-100-10-195 32-257 113 119 564 271 1171 325 1236 96 28 316 6 394-5 11-1 1034-139 1614-139 581 0 1604 138 1614 139 79 11 299 33 395 5 54-65 206-672 324-1236-62-81-157-123-257-113-146 15-276 130-356 315l-28 66-39-60c-72-115-169-194-289-238-213-77-440-40-673 110-17 12-41 7-52-11-11-17-6-41 11-52 251-161 506-202 740-118 115 42 213 114 289 214 93-177 233-286 390-301 133-13 259 46 336 158l9 13-3 16c-1 3-67 317-142 630-158 654-200 667-231 678-130 42-422 1-434-1-10-1-1028-138-1604-138-575 0-1593 137-1603 138-8 1-139 20-264 20z"
  })), _path7 || (_path7 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil5",
    d: "M4483 5968h76c89 0 170-53 207-134 113-255 321-815 127-1157-6-10-12-20-19-29 0 0-186-170-320 70-126 225-388 1184-71 1250z"
  })), _path8 || (_path8 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M4485 4878c25-68 48-123 69-160-21 37-44 92-69 160z"
  })), _path9 || (_path9 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil6",
    d: "M4943 4799v-1 1zm0-1c-4-13-8-26-13-39 5 13 9 26 13 39z"
  })), _path10 || (_path10 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil7",
    d: "M4930 4759c-10-29-23-56-37-82 14 26 27 53 37 82z"
  })), _path11 || (_path11 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil8",
    d: "M4968 4926c-15-37-33-72-56-104-7-10-15-20-23-29 0 0-78-58-177-58-69 0-149 29-217 128-3 5-7 10-10 15 25-68 48-123 69-160 55-99 120-128 176-128 80 0 144 58 144 58 7 9 13 19 19 29 14 26 27 53 37 82 5 13 9 26 13 39v1c12 41 20 83 25 127z"
  })), _path12 || (_path12 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M4966 4954h-6l-466-78c-21-4-35-23-31-44 3-20 22-34 43-31l467 78c20 3 34 23 31 44-3 18-19 31-38 31zM4964 5206h-6l-545-74c-21-2-36-21-33-42s22-35 43-32l545 73c21 3 36 22 33 42-3 19-19 33-37 33zM4915 5453h-4l-554-68c-21-3-36-21-33-42 2-21 21-36 42-33l554 68c21 2 35 21 33 42-3 19-19 33-38 33zM4828 5722h-4l-495-45c-21-1-36-20-35-41 2-20 21-36 41-34l496 45c21 2 36 20 34 41-2 20-18 34-37 34z"
  })), _path13 || (_path13 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil9",
    d: "M4382 5893zm0-1zm0 0zm-1-1zm0 0zm0 0v-1 1zm0-1c-31-52-45-126-48-212 3 86 17 160 48 212z"
  })), _path14 || (_path14 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil10",
    d: "M4559 5968h-76c-44-9-77-36-101-75v-1c-1 0-1-1-1-1v-1c-31-52-45-126-48-212l150 13c15 8 32 13 50 16h91c8 0 16 0 24-1l165 15c-17 42-33 80-47 113-37 81-118 134-207 134zm282-319c-3-1-7-2-10-2l-21-2c22-18 40-38 54-62-7 23-15 45-23 66zm-443-41-63-6h-2c2-66 10-137 21-210 1 86 14 160 44 216z"
  })), _path15 || (_path15 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "m4813 5721-165-15c61-4 118-26 162-61l21 2c3 0 7 1 10 2-9 25-19 49-28 72zm-330-30-150-13c-1-25-1-50 0-76h2l63 6c20 37 48 66 85 83z"
  })), _path16 || (_path16 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M4487 5930h72c74 0 142-44 172-112 102-227 317-791 129-1122-5-8-9-15-14-22-13-11-72-55-136-45-46 8-88 44-123 108-108 192-293 875-183 1116 20 43 47 68 83 77zm72 75h-84c-62-13-109-54-140-120-130-285 83-1001 186-1185 47-85 107-134 178-145 108-18 197 62 201 65l3 3 2 3c8 11 14 21 20 32 199 349 7 896-125 1191-42 95-137 156-241 156z"
  })), _path17 || (_path17 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil5",
    d: "M584 5968h-76c-90 0-170-53-207-134-114-255-321-815-127-1157 6-10 12-20 18-29 0 0 187-170 321 70 125 225 388 1184 71 1250z"
  })), _path18 || (_path18 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M582 4878c-25-68-49-123-69-160 20 37 44 92 69 160z"
  })), _path19 || (_path19 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil6",
    d: "M123 4799c4-13 9-27 13-40-4 13-9 27-13 40z"
  })), _path20 || (_path20 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil7",
    d: "M136 4759c11-29 23-56 38-82-15 26-27 53-38 82z"
  })), _path21 || (_path21 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil8",
    d: "M99 4926c5-44 13-86 24-127 4-13 9-27 13-40 11-29 23-56 38-82 6-10 12-20 18-29 0 0 64-58 144-58 57 0 122 29 177 128 20 37 44 92 69 160-4-5-7-10-10-15-69-99-148-128-218-128-98 0-177 58-177 58-8 9-15 19-22 29-23 32-41 67-56 104z"
  })), _path22 || (_path22 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M100 4954c-18 0-34-13-37-31-3-21 11-41 31-44l467-78c20-3 40 11 43 31 4 21-10 40-31 44l-466 78h-7zM103 5206c-18 0-35-14-37-33-3-20 12-39 32-42l546-73c21-3 40 11 43 32 2 21-12 40-33 42l-546 74h-5zM151 5453c-18 0-35-14-37-33-3-21 12-40 33-42l554-68c21-3 39 12 42 33s-12 39-33 42l-554 68h-5zM239 5722c-19 0-36-14-37-34-2-21 13-39 34-41l495-45c21-2 39 14 41 34 2 21-13 40-34 41l-495 45h-4z"
  })), _path23 || (_path23 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil9",
    d: "M684 5893zm0 0zm1 0v-1 1zm0-1zm0 0zm0-1h1-1zm1 0c30-52 45-127 48-213-3 86-18 161-48 213z"
  })), _path24 || (_path24 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil10",
    d: "M584 5968h-76c-90 0-170-53-207-134-14-33-31-71-47-113l165-15c8 1 16 1 24 1h90c19-3 36-8 51-16l150-13c-3 86-18 161-48 213h-1v2h-1c-23 39-56 66-100 75zm-358-319c-8-21-16-43-24-66 15 24 33 44 55 62l-21 2c-4 0-7 1-10 2zm443-41c30-56 43-130 44-216 11 73 19 144 21 210h-3l-62 6z"
  })), _path25 || (_path25 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M254 5721c-10-23-19-47-28-72 3-1 6-2 10-2l21-2c44 35 100 57 162 61l-165 15zm330-30c37-17 64-46 85-83l62-6h3c1 26 1 51 0 76l-150 13z"
  })), _path26 || (_path26 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M221 4674c-5 7-10 14-14 21-188 332 27 896 129 1123 30 68 97 112 172 112h72c36-9 63-34 83-77 110-241-76-924-183-1116-35-64-77-100-124-108-63-10-122 34-135 45zm367 1331h-80c-104 0-199-61-241-156-132-295-324-842-126-1191 6-11 13-21 20-32l3-3 3-3c4-3 93-83 201-65 71 11 131 60 178 145 103 184 316 900 185 1185-30 66-77 107-140 120h-3zM1442 5932c-4 0-9-1-13-3-14-8-19-25-12-39 135-256 137-545 6-857-98-235-239-396-240-398-10-11-9-29 3-40 11-10 29-9 40 3 6 7 147 168 249 412 136 324 133 638-8 907-5 9-14 15-25 15zM3637 5932c-10 0-20-6-25-15-140-269-143-583-7-907 102-244 243-405 249-412 11-12 28-13 40-3 12 11 13 29 3 40-2 2-142 163-240 398-131 312-129 601 6 857 7 14 1 31-12 39-5 2-9 3-14 3z"
  })), _path27 || (_path27 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M1917 4463c-172 69-438 55-619 33-109-13-185-114-169-222 14-99 101-171 201-166 170 8 424 11 585-24l2 379z"
  })), _path28 || (_path28 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M1321 4145c-78 0-144 57-155 134-6 43 5 85 30 119 26 34 64 55 106 60 184 23 438 35 600-30 47-19 56-95 58-126 5-92-25-167-41-181-162 36-410 33-591 25-2-1-5-1-7-1zm254 407c-99 0-197-9-282-19-63-7-118-39-157-89-38-51-54-113-45-176 18-118 121-204 241-198 177 8 421 11 575-23 22-5 76-5 110 102 35 113 31 301-86 349-100 40-228 54-356 54z"
  })), _path29 || (_path29 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M3850 4496c-85 10-189 19-293 18-7 0-14 0-21-1h-23c-5 0-10-1-15-1-6 0-12 0-17-1-8 0-15-1-23-1-8-1-15-1-23-2-4-1-9-1-14-2-4 0-8-1-12-1-7-1-13-2-19-3-6 0-12-1-18-2-1 0-2 0-3-1l-21-3c-6-1-13-3-19-4-1 0-1 0-2-1-4 0-7-1-11-2l-12-3c-12-3-24-6-36-10-6-2-13-4-19-6-6-3-12-5-18-7l1-182 1-197c41 9 88 15 139 20 146 13 319 10 446 4h9c96 0 178 70 192 166 16 108-60 209-169 222z"
  })), _path30 || (_path30 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M3228 4121c-16 14-45 89-40 181 2 31 11 107 57 126 162 65 416 53 600 30 43-5 80-26 106-60s37-76 31-119c-12-80-82-137-163-133-180 8-428 11-591-25zm344 431c-127 0-255-14-355-54-118-48-121-236-86-349 33-107 88-107 110-102 154 34 398 31 575 23 119-6 223 80 240 198 10 63-6 125-45 176-38 50-94 82-156 89-85 10-183 19-283 19z"
  })), _path31 || (_path31 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M3297 3958v608c0 112-92 205-205 205H1974c-112 0-205-93-205-205v-608c0-112 93-204 205-204h1118c67 0 126 32 164 81 26 34 41 77 41 123z"
  })), _path32 || (_path32 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M1974 3791c-92 0-167 75-167 167v608c0 92 75 167 167 167h1119c92 0 167-75 167-167v-608c0-92-75-167-167-167H1974zm1119 1017H1974c-134 0-242-108-242-242v-608c0-133 108-242 242-242h1119c133 0 242 109 242 242v608c0 134-109 242-242 242z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M3106 4262c0 98-79 177-176 177-98 0-177-79-177-177 0-97 79-176 177-176 97 0 176 79 176 176z",
    style: {
      fill: "#22a7f0",
      fillRule: "nonzero"
    }
  }), _path33 || (_path33 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M3106 4262c0 10-1 19-2 28-14-84-86-148-174-148s-161 64-175 148c-1-9-2-18-2-28 0-97 79-176 177-176 97 0 176 79 176 176z"
  })), _path34 || (_path34 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M2930 4114c-82 0-149 66-149 148s67 148 149 148c81 0 148-66 148-148s-67-148-148-148zm0 353c-113 0-205-92-205-205s92-205 205-205 205 92 205 205-92 205-205 205zM2429 4799c-16 0-28-13-28-28v-419l-213-160c-7-6-11-14-11-23v-415c0-16 13-29 28-29 16 0 29 13 29 29v401l212 160c7 5 11 14 11 23v433c0 15-12 28-28 28z"
  })), _path35 || (_path35 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M4099 2052c-19 2-34-12-36-30l-71-950c-1-19 13-34 31-36 191-14 357 129 372 320l24 324c14 191-129 358-320 372z"
  })), _path36 || (_path36 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M4049 1042c-8 0-17 0-26 1-14 1-25 14-24 28l71 950c0 7 4 14 9 18 5 5 12 7 19 6 91-6 173-48 233-117 59-69 88-157 81-247l-24-324c-7-91-49-173-117-233-63-53-141-82-222-82zm47 1017c-9 0-19-3-26-10-8-7-13-16-14-27l-71-950c-1-22 15-41 37-43 94-7 186 23 257 85 72 62 115 148 122 242l25 324c7 94-23 185-85 257s-148 115-242 122h-3z"
  })), _path37 || (_path37 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M4122 2011c11-59 19-119 24-180 1-18 3-36 4-54 98-22 179-86 225-170l6 76c6 82-20 162-74 225-48 56-113 92-185 103z"
  })), _path38 || (_path38 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "m4030 1074 71 940c80-7 153-45 206-106 54-63 80-143 74-225l-24-324c-6-82-44-157-107-211-61-53-139-79-220-74zm66 1016c-17 0-33-6-46-17-14-12-23-30-25-49l-70-950c-3-39 26-73 65-75 102-8 202 25 280 92s125 160 132 263l25 323c7 103-26 202-93 280s-160 125-263 133h-5z"
  })), _path39 || (_path39 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M887 1270c18-1 34 13 35 31l71 950c2 18-12 34-30 35-191 15-358-129-372-320l-24-324c-15-191 129-357 320-372z"
  })), _path40 || (_path40 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M887 1277c-187 14-327 178-314 365l25 324c14 187 177 327 364 314 7-1 14-4 18-9 5-6 7-13 7-20l-71-950c-1-14-14-25-29-24zm50 1017c-184 0-339-142-353-327l-24-324c-15-195 132-365 326-379 22-2 42 14 43 36l71 950c1 11-2 21-9 29s-17 13-28 14c-9 1-17 1-26 1z"
  })), _path41 || (_path41 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M936 2250c-160 0-295-124-307-287l-6-72c61 70 149 114 246 119 17 82 41 162 70 240h-3z"
  })), _path42 || (_path42 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M885 1308c-168 16-293 163-281 331l25 324c12 169 158 296 326 286l-70-941zm52 1017c-200 0-369-154-384-356l-24-324c-16-212 144-396 355-412 39-3 73 26 76 65l71 950c1 19-5 37-17 52-12 14-30 23-48 24-10 1-20 1-29 1z"
  })), _path43 || (_path43 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M4116 1655c4 897-721 1627-1617 1630-897 3-1626-721-1629-1618C866 770 1591 41 2487 38c897-3 1626 721 1629 1617z"
  })), _path44 || (_path44 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M2493 45h-6C1596 48 873 776 876 1667c3 889 728 1611 1617 1611h6c891-3 1614-731 1611-1623-4-889-728-1610-1617-1610zm0 3246c-896 0-1627-727-1630-1624C860 768 1588 34 2487 31h6c896 0 1627 727 1630 1624 3 899-725 1633-1624 1636h-6z"
  })), _path45 || (_path45 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M2498 3227c-30-34-62-66-96-96 20 0 40 1 59 1 17 0 34-1 51-1 29-1 58-2 87-4-35 31-69 64-101 100zm1034-369c-1 0-1-1-2-1 3-1 6-3 9-5-2 2-4 4-7 6z"
  })), _path46 || (_path46 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M2493 76h-6C1613 79 904 793 907 1667c3 872 714 1580 1586 1580h6c874-3 1583-717 1580-1591-3-873-714-1580-1586-1580zm0 3247c-913 0-1658-742-1661-1656C828 751 1571 3 2487 0h6c913 0 1658 741 1661 1655 3 916-739 1664-1655 1667-2 1-4 1-6 1z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4111 1697c6 318-91 615-263 862-129 185-666 516-1337 534-622 17-1195-304-1330-484-181-241-290-534-296-852-15-840 700-1202 1591-1219 891-16 1620 319 1635 1159z",
    style: {
      fill: "#1a1a1a",
      fillRule: "nonzero"
    }
  }), _path47 || (_path47 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M2533 576h-56c-474 9-1573 142-1554 1181 6 299 105 586 288 829 126 168 661 470 1251 470 16 0 32 0 48-1 674-18 1192-352 1307-518 173-249 262-540 257-839C4055 698 3033 576 2533 576zm-72 2556c-622 0-1172-317-1311-501-192-255-297-557-303-873-7-411 152-730 472-950 281-192 680-299 1156-307 476-9 880 82 1167 263 329 208 499 522 507 932 6 316-87 622-270 884-127 183-658 531-1367 551-17 0-34 1-51 1z"
  })), _path48 || (_path48 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil13",
    d: "M3564 1878c-9 0-17 0-25-2-113-18-185-160-160-316 24-146 123-253 227-253 9 0 17 1 25 2 92 15 156 111 164 229-11 71-26 140-45 208-44 81-114 132-186 132zM3331 2297c-10 0-20-1-29-4-60-19-91-90-70-160 19-58 68-97 118-97 10 0 20 2 30 5 59 18 90 89 69 159-18 58-68 97-118 97z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M2462 3056c-55 0-111-3-165-8-48-33-99-62-151-88 678-108 1196-443 1336-644 120-173 211-365 268-570 19-35 33-76 40-120 5-30 7-59 5-88 16-103 23-208 21-315-2-85-9-166-22-243 163 165 274 396 280 718 5 299-84 590-257 839-57 82-210 203-431 308h-26c-236 0-461 69-648 195-66 8-133 13-202 15-16 1-32 1-48 1z",
    style: {
      fill: "#000",
      fillRule: "nonzero"
    }
  }), _path49 || (_path49 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M2462 3094c-36 0-72-1-108-3-19-15-38-29-57-43 54 5 110 8 165 8 16 0 32 0 48-1 69-2 136-7 202-15-21 14-42 29-62 45-46 4-92 7-139 8-17 1-33 1-49 1zm1001-244c-26-3-51-4-77-5 221-105 374-226 431-308 173-249 262-540 257-839-6-322-117-553-280-718-3-21-7-41-11-61 201 184 322 441 328 778 6 318-91 615-263 862-57 82-193 192-385 291z"
  })), _path50 || (_path50 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil13",
    d: "M3750 1746c19-68 34-137 45-208 2 29 0 58-5 88-7 44-21 85-40 120z"
  })), _path51 || (_path51 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M993 1076c-8 0-17-3-24-8-15-13-18-35-6-52 276-422 823-672 1500-684 673-13 1229 209 1526 607 10 14 10 34-1 48-13 16-37 18-53 5l-4-3-3-4c-281-379-815-590-1463-578-653 13-1178 250-1440 652l-3 4c-7 8-18 13-29 13z"
  })), _path52 || (_path52 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil13",
    d: "M1257 2251s-276-825 165-1163c334-257 784-325 976-325 61 0 97 7 93 17 0 0-708 185-976 753-207 438-258 718-258 718z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4451 3924c0 27-1 55-4 83-35 340-277 678-579 976-491 484-1141 861-1321 961-30 17-67 17-97 0-213-115-1072-603-1560-1211-205-255-345-531-345-809 0-74 8-145 23-214 104-472 543-827 1068-827 351 0 663 158 862 402 200-244 512-402 862-402 603 0 1091 466 1091 1041z",
    style: {
      fill: "#f9195a",
      fillRule: "nonzero"
    }
  }), _path53 || (_path53 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil16",
    d: "M2498 5919c-10 0-21-3-30-8-241-130-1214-686-1660-1350 52 18 106 27 160 27 223 0 438-150 454-372v-7c4 46 4 98 0 158-10 143-104 257-228 319 36 33 73 65 110 97 342 292 764 437 1186 437 442 0 883-159 1230-476 23-21 46-43 68-64-119-63-207-174-217-313-4-60-4-112 0-158v7c16 222 230 372 454 372 52 0 104-8 155-25-138 199-336 407-593 624-439 370-921 648-1059 724-9 5-20 8-30 8z"
  })), _path54 || (_path54 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil17",
    d: "M2606 3540c-38 0-94-78-108-97-199-245-511-402-862-402-308 0-587 122-785 318 34-99 129-201 212-276 165-103 362-162 573-162 328 0 632 141 833 388l29 36 30-36c201-247 504-388 832-388 207 0 399 57 562 155 83 74 181 177 218 277-198-193-474-312-780-312-311 0-593 124-792 324-12 13 73 111 71 128-6 34-18 47-33 47z"
  })), _path55 || (_path55 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M1636 2921c-580 0-1053 450-1053 1003 0 918 1570 1816 1885 1987 19 10 41 10 60 0 138-76 620-354 1059-724 549-462 827-887 827-1263 0-553-473-1003-1054-1003-328 0-631 141-832 388l-30 36-29-36c-201-247-505-388-833-388zm862 3073c-23 0-45-5-66-16-321-175-1925-1093-1925-2054 0-595 507-1079 1129-1079 336 0 647 139 862 382 216-243 527-382 862-382 623 0 1129 484 1129 1079 0 936-1603 1874-1924 2053-21 12-44 17-67 17z"
  })), _path56 || (_path56 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M2616 3498c-13 0-25-7-32-18-52-85-115-171-116-172-12-17-9-41 8-53s40-9 53 8c2 4 65 89 119 177 11 18 6 41-12 52-6 4-13 6-20 6z"
  })), _path57 || (_path57 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil17",
    d: "M3727 3455c-77 0-166-6-248-11-219-12-657-15-490-176 82-80 244-127 413-127 172 0 351 48 461 160 126 127 22 154-136 154z"
  })), _path58 || (_path58 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M1208 2965s-868 383-740 1132c123 714 923 556 954 119 29-418-147-475-367-537-163-45-232-177-216-277 33-202 369-437 369-437z"
  })), _path59 || (_path59 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil18",
    d: "M675 4487c-98-78-175-205-207-390-16-95-16-184-4-267-12 83-12 172 4 267 32 185 109 312 207 390z"
  })), _path60 || (_path60 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M794 4556c-42-17-82-39-119-69 37 30 77 52 119 69z"
  })), _path61 || (_path61 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M968 4588c-58 0-118-10-174-32-42-17-82-39-119-69-98-78-175-205-207-390-16-95-16-184-4-267 1 9 3 19 4 29 60 350 284 490 500 490 211 0 414-133 449-335 9 56 10 122 5 202-16 222-231 372-454 372z"
  })), _path62 || (_path62 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M4097 4734c53-65 101-131 144-197 2-1 3-2 5-3-43 68-90 134-143 199-2 0-4 0-6 1z"
  })), _path63 || (_path63 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil1",
    d: "M3785 2965s868 383 739 1132c-122 714-922 556-953 119-29-418 147-475 367-537 163-45 231-177 215-277-32-202-368-437-368-437z"
  })), _path64 || (_path64 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil18",
    d: "M4314 4490c99-78 178-205 210-393 17-95 17-184 5-267 12 83 12 172-5 267-32 188-111 315-210 393z"
  })), _path65 || (_path65 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil2",
    d: "M4252 4531c21-12 42-25 62-41-20 16-41 29-62 41z"
  })), _path66 || (_path66 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil16",
    d: "M3570 4198c-4-72-2-133 6-184-8 51-10 112-6 184z"
  })), _path67 || (_path67 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil4",
    d: "M4025 4588c-224 0-438-150-454-372 0-6-1-12-1-18-4-72-2-133 6-184 35 202 238 335 449 335 216 0 440-140 499-490 2-10 4-20 5-29 12 83 12 172-5 267-32 188-111 315-210 393-20 16-41 29-62 41-71 39-150 57-227 57z"
  })), _path68 || (_path68 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M892 3211c-26 22-52 44-77 68-256 242-360 515-309 812 60 353 290 469 485 459 180-9 378-130 393-336 28-395-134-441-339-498-183-51-262-203-243-320 10-62 45-125 90-185zm76 1415c-221 0-471-136-537-522-54-320 61-624 333-881 204-192 420-288 429-293 18-7 38 0 48 16 9 17 5 39-11 50-4 2-324 228-353 412-14 85 48 196 188 235 210 59 427 120 394 576-15 219-215 394-464 406-9 1-18 1-27 1zM4101 3211c45 60 80 123 90 185 19 117-60 269-243 320-205 57-367 103-339 498 14 206 213 327 393 336 195 10 425-106 485-459 51-297-53-570-309-812-25-24-51-46-77-68zm-76 1415c-9 0-18 0-27-1-249-12-449-187-465-406-32-456 185-517 395-576 140-39 202-150 188-235-30-184-350-410-353-412-16-11-21-33-11-50 10-16 30-23 48-16 9 5 225 101 429 293 272 257 387 561 333 881-66 386-316 522-537 522z"
  })), _path69 || (_path69 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-hero_svg__fil3",
    d: "M4502 3738c-10 0-20-5-25-15-113-217-334-305-336-306-15-5-22-22-16-36 5-15 22-22 36-17 10 4 243 96 366 333 8 14 2 31-12 38-4 2-8 3-13 3zM489 3738c-4 0-9-1-13-3-14-7-19-24-12-38 123-237 356-329 366-333 15-5 31 2 37 17 5 14-2 31-17 36-2 1-223 89-336 306-5 10-15 15-25 15z"
  }))));
};
/* harmony default export */ const mpathy_hero = (SvgMpathyHero);
;// CONCATENATED MODULE: ./src/components/svgs/mpathy-join-us.svg
var _linearGradient, _style, mpathy_join_us_path, mpathy_join_us_path2, mpathy_join_us_path3, mpathy_join_us_path4, mpathy_join_us_path5, mpathy_join_us_path6, mpathy_join_us_path7, mpathy_join_us_path8, mpathy_join_us_path9, mpathy_join_us_path10, mpathy_join_us_path11, mpathy_join_us_path12, mpathy_join_us_path13, mpathy_join_us_path14, mpathy_join_us_path15, mpathy_join_us_path16, mpathy_join_us_path17;
function mpathy_join_us_extends() { mpathy_join_us_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return mpathy_join_us_extends.apply(this, arguments); }

var SvgMpathyJoinUs = function SvgMpathyJoinUs(props) {
  return /*#__PURE__*/external_react_.createElement("svg", mpathy_join_us_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 612.714,
    height: 538.809,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 112225 100175",
    xmlnsXlink: "http://www.w3.org/1999/xlink"
  }, props), /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id0",
    gradientUnits: "userSpaceOnUse",
    x1: 5671.5,
    y1: 85950.4,
    x2: 25255.1,
    y2: 84827.2
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#b62f24"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#c36311"
    }
  })), /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id1",
    gradientUnits: "userSpaceOnUse",
    x1: 13184.4,
    y1: 85854.9,
    x2: 24857.6,
    y2: 84025.7
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#fcfe01"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#ea9a10"
    }
  })), /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id2",
    gradientUnits: "userSpaceOnUse",
    x1: 13288.7,
    y1: 85854.9,
    x2: 24866.3,
    y2: 84025.7
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#d4c001"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#c6750c"
    }
  })), /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id3",
    gradientUnits: "userSpaceOnUse",
    x1: 5675.81,
    y1: 85766.6,
    x2: 25254.9,
    y2: 84686.5
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#d43d30"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#e58216"
    }
  })), /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id4",
    gradientUnits: "userSpaceOnUse",
    x1: 5673.78,
    y1: 85950,
    x2: 25255.2,
    y2: 84826.9
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#d43d30"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#ae93e5"
    }
  })), /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id5",
    gradientUnits: "userSpaceOnUse",
    x1: 5671.5,
    y1: 85950.4,
    x2: 25255,
    y2: 84827.2
  }, /*#__PURE__*/external_react_.createElement("stop", {
    offset: 0,
    style: {
      stopOpacity: 1,
      stopColor: "#ecaaa4"
    }
  }), /*#__PURE__*/external_react_.createElement("stop", {
    offset: 1,
    style: {
      stopOpacity: 1,
      stopColor: "#f4c899"
    }
  })), _linearGradient || (_linearGradient = /*#__PURE__*/external_react_.createElement("linearGradient", {
    id: "mpathy-join-us_svg__id6",
    gradientUnits: "userSpaceOnUse",
    xlinkHref: "#mpathy-join-us_svg__id3",
    x1: 5671.5,
    y1: 85950.4,
    x2: 25255,
    y2: 84827.2
  })), _style || (_style = /*#__PURE__*/external_react_.createElement("style", null, ".mpathy-join-us_svg__fil12{fill:#000}.mpathy-join-us_svg__fil0{fill:#02a9fd}.mpathy-join-us_svg__fil14{fill:#1176bb}.mpathy-join-us_svg__fil13{fill:#ad1b2f}.mpathy-join-us_svg__fil1{fill:#ea1c24}.mpathy-join-us_svg__fil24{fill:#f68a8e}.mpathy-join-us_svg__fil3{fill:#fff}"))), /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-join-us_svg__Layer_x0020_1"
  }, /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-join-us_svg___2526354620016"
  }, mpathy_join_us_path || (mpathy_join_us_path = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil0",
    d: "M36154 80823c-3187 274-6323 860-9287 1838-2334 770-4556 1781-6647 3077 4320 247 11589 298 16042-440 2024-336 3853-683 3949-2438 127-2304-2798-2145-4057-2037z"
  })), mpathy_join_us_path2 || (mpathy_join_us_path2 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil1",
    d: "M35883 90912c75 4698-4087 6194-8394 6500 6603 1707 15518 2884 17348-4144-2928-640-5914-1426-8954-2356zM61960 82487c5511 5665 15256 1787 15256-6202 0-8053-9882-11902-15357-6093 171 308 1351 1064 1781 1446 1228-1239 2910-1957 4689-1957 5867 0 8821 7125 4671 11275-2278 2277-5853 2576-8477 726-813 444-1584 652-2563 805zM89786 60571c-5616 7718-3889 18517 3833 24119l90 77c4612-3232 8777-7343 12445-12358 372-507 529-1894 138-2347-4155-4816-9590-7976-16420-9645l-86 154zM69581 36351c1104-101 2224 129 3176 636l-282-1389c-1002 76-2008 177-3005 296l111 457z"
  })), mpathy_join_us_path3 || (mpathy_join_us_path3 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil0",
    d: "M72241 48010c401 1462 813 902 1314 627 1260-692 1385-1824 1037-3127l-2351 2500z"
  })), mpathy_join_us_path4 || (mpathy_join_us_path4 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil1",
    d: "M79016 25432c-37 2952 437 4835 2330 7375 384-1270 1383-2246 2609-2996-1076-1324-1210-2568-985-3839l-3954-540z"
  })), mpathy_join_us_path5 || (mpathy_join_us_path5 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil1",
    d: "M85647 30567c-1149 550-1968 1157-2456 1819-410 555-583 1164-521 1826l1169 773c895 445 1819 581 2682 331 4438-1355 4188-10725-490-14573-3257-2679-6210-596-6872 3197 1718 535 3468 681 5272 461 1377-361 2585 914 3004 2262 480 1553 52 3491-1314 3822l-474 82zM30138 73331l4343-3541 1487-1037c-4009-1726-10876 1807-15197 4392 2891-826 7621-1919 9367 186z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M52756 39544c2887 371 7403 20 11784-1251 803-796 1629-2042 2247-2984l301-1020c-1648-1747-2104-4156-280-5860l3201-2440c0-4190-1996-8157-5000-11162-3707-3706-10881-1109-14496 1662-3181 2534-6048 7179-6775 11461 3064 606 5453 4784 3987 7835 1374 1682 2432 3426 5031 3759zm12789 41424c3557 2094 8166-455 8166-4683 0-4816-5893-7271-9294-3803 1931 2306 3390 5941 1128 8486z",
    style: {
      fill: "#1a1a1a"
    }
  }), mpathy_join_us_path6 || (mpathy_join_us_path6 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil3",
    d: "M40445 28804c1044-10125 6914-16087 16601-17628-11758-2613-21907 8588-18201 20010l1602-2214c-7-54-8-111-2-168zm28806 5632c3655-436 7771-680 11380-174-2345-2702-3607-7441-2844-10986-3218 2296-6047 3612-9582 5261-1088 429-1537 1018-1564 2299-33 1538 961 3797 2610 3600zm-1836 16967c623 1672 1039 3389 1103 5104 1327 263 2453 66 3374-593 1096-782 1959-2225 2587-4328 240-796 1416-363 2663-2141 1516-2163 841-5150-1433-6459-44 257-106 512-186 762 17 327 2234 4108-1228 6162-1493 937-2601 625-3250-882l-3630 2375zm-11260 8145c-409-2008-673-4104-537-5983l-1103-250c-514-106-1005-224-1474-352l-27 617c2232-305 3445 2573 1641 3947l-748 424 1792 1678 456-81zm920-5730c-309 1727-106 3455 471 5181 3335-278 6575-1007 9505-2370-114-1586-431-3109-962-4565-3004 1397-5517 2241-9014 1754zm-8146 13435c2043-2477 4513-4457 7385-4767-719-1800-2241-2925-3951-3891-3249 1111-7568 1285-11110 695 426 1407 980 2605 1661 3598 2193 3192 3656 2419 6015 4365zM35825 54384c-629 3527 12340 5376 17958 1958 699-496-56-1721-871-1189l-538 240c-5774 2339-14759-1254-15471-1859-496-306-959 190-1078 850zm5483-511c3390 1194 6883 1520 10163 295l102-1668c-1559-811-3503-2176-4690-3248 1690 671 3187 1221 4492 1651 3068 918 7074 2196 10217 1279 4642-1355 8435-3646 11485-7167l41-46c2849-2909 297-7816-3748-7103-3039 534-2685 2478-3677 4021-2427 3104-8335 4109-13660 418l-1494 399c-2054-390-3337 839-4526 3078 374-1599 1024-2712 1951-3342-829-294-1629-650-2394-1063-2461 3817-4076 7999-4262 12496zm715-9055c628-1404 1388-2803 2283-4196-286-188-566-384-841-589l-4718 817c1512 822 2697 2295 3276 3968zm-1107 17577c-522-1012-950-2160-1285-3442-2347-594-5753-2037-5255-4827 80-1235 1608-2748 3100-1957 812 432 1609 813 2390 1144 120-1900 479-3791 1078-5674 283-4210-4129-7710-6831-5063-4078 3998-4383 12103-3421 18480 840 5565 6593 3801 10224 1339zm37774 13890c0 7765-8231 12737-15082 9223-1352-694-2531-1676-3456-2864-2856 45-5177-923-6867-2257-1868-1475-3181-3614-3235-5430-233-7719-2682-7500-6407-8917-2112 1047-4323 1791-6097 2919-3686 3088-9356 6917-10085 11870l-14 107c3543-1030 7033-1564 10795-1720 1896 237 3080 1124 3411 3070 447 2987-2361 4049-5155 4464l-6388 560c1554 929 8742 2928 10545 3388 17641 4500 35997 5255 51768-5061-7979-6047-9784-17331-4082-25565-8558-1768-19049-1299-31117 780 3763 3100 4161 5708 4329 7598 6648-5759 17137-1062 17137 7835zm-13372 1165c-547-5103-4993-4160-5365-8564-103-1236-86-2885-1617-4837-1398-293-2788-89-4169 610-1407 713-2813 1937-4219 3671 1107 1529 1486 3663 1571 6586 37 1300 1251 3317 2677 4319 5468 3406 11479 1540 11122-1785zM49077 41208c-1571-799-2982-1935-4280-3397l-1556 137c1632 1470 3574 2599 5717 3277l119-17zm-8825-7662c-84 1909 2405 3724 4311 2055l-4311-2055zm479-1404 4621 2202c254-916-13-1880-666-2535-1134-1133-3017-982-3955 333zm4997-1375c908 908 1355 2211 1140 3535 564-1343 251-2886-765-3905-1014-1012-2546-1327-3888-774 1319-206 2608 242 3513 1144zm-2794-2847c1304-8253 7968-14561 16141-15520-9630 929-15763 5987-17070 15731 299-99 610-169 929-211z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M26147 79891c148-601 356-1140 626-1971-7633-2112-17436 4466-24345 10137 2416 481 4789 1243 6839 2520 6481 4038 14845 3375 20432-1813-1169-865-2055-1892-2659-3079 37 73 75 144 113 214-2554 18-5030-52-6933-161 1884-1169 3875-2104 5957-2841l30 193c-160-986-180-2053-60-3199zm808 5621c-35-73-69-146-102-220 33 74 67 147 102 220z",
    style: {
      fill: "#e78c12"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M23703 77516h-18 18zm-18 0h-12 12zm-12 0h-2 2zm-2 0h-6 6zm-6 0h-4 4zm-4 0h-17 17z",
    style: {
      fill: "#e78c12",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M26552 78581c69-201 142-419 221-661l-8 24c-75 233-146 442-213 637z",
    style: {
      fill: "url(#mpathy-join-us_svg__id4)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M18396 93192c253 0 507-6 760-18-253 12-506 18-760 18zm764-18c1 0 3 0 5-1-2 1-4 1-5 1zm-1618-1280c-529 0-1064-55-1589-185-5496-1355-9091-3664-13040-3664-161 0-323 4-485 12 471-387 956-778 1453-1171-268 212-533 423-793 633 8233-5952 16128-9152 23685-9599-79 242-152 460-221 661-123 365-229 677-319 988-440-26-877-40-1312-40-6176 0-11879 2733-17110 8197 4059 1977 7918 2966 11578 2966 1086 0 2154-87 3205-261-665 468-2798 1463-5052 1463zM3883 86885c4-3 8-7 12-10-4 3-8 7-12 10zm22890-8965c-993-274-2023-402-3078-404h8c1043 2 2062 128 3044 397 9 2 17 5 26 7zm-4456-338zm21-2zm19-2h3-3zm20-1c2 0 3-1 5-1-2 0-3 1-5 1zm21-2c2 0 3 0 5-1-2 0-4 1-5 1zm20-2c2 0 4 0 6-1-2 1-4 1-6 1zm20-2h7-7zm19-1c3-1 6-1 9-1-3 0-6 0-9 1zm19-2c4 0 7-1 11-1-3 0-7 1-11 1zm19-2c5 0 9-1 13-1-4 0-9 1-13 1zm16-1c381-32 758-48 1133-49h7c-377 1-757 17-1140 49z",
    style: {
      fill: "url(#mpathy-join-us_svg__id6)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M24792 81163h-191 191z",
    style: {
      fill: "url(#mpathy-join-us_svg__id3)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M15628 87797c-1161-326-2332-688-3523-993 399-269 822-584 1229-944 1541-1366 7137-4647 11267-4697h191c396 5 778 41 1139 113v1l-10 149c-3302 319-10379 3459-10293 6371m9740-448-838-36 840 36h-2zm-7417-317h-2l-12-3c-175-42-309-97-407-164 1 1 2 2 3 2 97 65 230 120 404 162l10 2c1 1 1 1 2 1h2z",
    style: {
      fill: "url(#mpathy-join-us_svg__id1)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M70239 22390c-465 313-903 625-1314 937 197 993 298 2014 301 3047v104l-11 5v1c-856 391-2281 928-2771 1346l-12 9-10 9-9 8-12 11-7 5-14 12-4 4-17 15-1 2-19 17-21 19-16 14-4 4-14 14-5 5-12 12-8 8-10 9-10 10-8 7-11 13-6 4-14 16-3 3-16 16-1 2-17 18h-1l-16 18-2 2-14 16-5 4-12 14-6 7-11 12-8 8-7 10-10 11-18 21-4 5-13 16-4 3-14 19-1 1-15 18-1 2-15 18-2 3-13 17-4 5-10 14-7 8-8 12-8 10-7 8-10 14-5 7-10 15-5 5-12 18-1 2-15 19c-458 659-679 1488-696 2349-31 1439 486 2970 1487 4032l20 21 21 21-109 165c334 330 702 658 1107 985 73-107 147-214 217-323 13 5 25 10 38 15l66 326c490 30 994 66 1514 109l-64-264c997-119 2003-220 3005-296l179 883c515 63 1042 130 1581 204l-281-1179c965-48 1920-68 2851-53 2349 38 4565 295 6448 882 1196 579 2462 744 3677 393l107-34c1783-553 3077-2150 3705-4230 2065-6834-3319-15917-9051-14181-923 287-8066 6051-11000 7498l-2-42c-29-1128-184-2251-450-3349zm-2034 6147c-321 127-655 267-906 504l-1 2c-35 34-69 69-101 106l-4 5-6 6-37 45-6 8-3 4-9 11-27 36-8 11-1 1-8 12-9 12-4 6-9 14-13 17v2l-13 20c-235 365-361 823-392 1315l-2 27v3l-1 24-2 28-1 26v10l-1 17v27c-13 617 117 1269 362 1856 251 599 622 1118 1079 1436l6 4 6 5 3 2 3 3 6 4c340 227 725 341 1145 290 1247-149 2514-271 3776-352 2455-166 5223-156 7604 178-2345-2702-3607-7441-2844-10986-3218 2296-6047 3612-9582 5261zm13141 4270c-1893-2540-2367-4423-2330-7375l3954 540c-225 1271-91 2515 985 3839-1226 750-2225 1726-2609 2996zm3103-4989c-202-667-239-1772 369-1998 480-101 1025 689 1212 1270l25 85c191 661 138 1725-354 1901-519 157-1075-698-1252-1258zm2986-1155c-419-1348-1627-2623-3004-2262-1804 220-3554 74-5272-461 331-1896 1283-3715 2957-4249 1303-393 2647 9 3915 1052 4678 3848 4928 13218 490 14573-863 250-1787 114-2682-331l-1169-773c-62-662 111-1271 521-1826 488-662 1307-1269 2456-1819l474-82c1438-455 1760-2282 1345-3718l-31-104z",
    style: {
      fill: "#5c0502"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M31337 87864c24471 8137 44577 7189 60319-2842-1345-1133-2494-2423-3439-3823-3767 1682-7664 3065-11692 4153 1060-997 1920-2222 2497-3619 1544-3737 792-8028-1931-11018 2506 4650 1142 10439-3176 13480-4319 3042-10229 2375-13763-1551-2856 45-5177-923-6867-2257-1868-1475-3181-3614-3235-5430-233-7719-2740-6544-6407-8917-369 183-737 362-1101 541-1717 842-3355 1661-4727 2721 3257-1559 5243-2086 5960-1582 765 588 1724 1209 2820 1955 1085 738 1294 2798 1699 5710 600 4309 3849 7105 9049 8241 1429 313 2713 447 3821 573 1188 1511 2762 2653 4534 3320-8441 1132-17381 1089-26836-122 572-205 1084-447 1538-726 782-481 1388-1072 1817-1774 509-1138 176-2526-998-4162 256 418 409 929 434 1551 28 190 44 373 46 548 80 2533-1927 3295-4250 3747-314 66-633 121-951 169l-1342 118-5046 442c264 158 691 347 1227 554zm54821-59890c3-279-34-565-103-799-187-637-776-1489-1237-1355-119 44-213 123-286 224l-8 12-6 8-11 16-2 4-14 21v1l-12 21-3 7-9 15-6 12-5 12-8 16-3 6-10 24-10 24-2 6-7 18-5 13-5 12-6 19-2 6-7 26-9 26-1 6-5 20-4 13-3 14-4 19-2 9-6 26v1l-5 27-1 7-4 22-3 12-2 17-3 19-1 8-4 28v2l-3 29-1 5-2 24-1 12-2 17-2 21v9l-2 28v2l-2 30v4l-1 27v29l-1 21v75l1 26v31l1 19v11l2 27v4l1 31 1 4 2 26 1 12 1 19 2 18v12l3 26v5l4 31v2l3 27 2 11 2 20 2 17 2 12 4 25v6l5 29v2l5 28 1 9 4 20 2 16 3 14 4 22 1 6 6 29 6 28 1 9 5 19 3 15 3 13 5 21 1 7 7 27 7 27 2 7 5 19 4 13 3 13 6 20 2 6 7 25c177 560 733 1415 1252 1258l15-6 7-3 7-3 14-6 1-1 13-6 8-5 6-3 12-8 3-1 12-7 8-8 5-2 12-9 3-3 10-8 9-9 2-2 13-10 4-5 7-6 11-12 12-13 5-6 6-6 9-14h2l9-14 6-8 4-5 10-15 2-2 8-13 7-10 2-4 10-16 2-5 7-11 6-12 2-5 9-15 3-7 5-10 7-16 1-2 8-17 3-8 4-10 7-18 8-19 3-10 3-8 6-19 1-3 6-16 4-13 2-8 6-19 1-4 5-16 5-15v-5l6-20 1-7 3-15 4-18 2-3 4-20 2-9 2-13 4-20v-1l4-22 2-11 2-11 4-22v-2l3-21 2-13 1-9 3-22v-4l3-19 1-16 1-7 2-22 1-7 2-17 2-19v-4l1-23 1-8 1-15 1-22v-2l2-23v-48l1-23 1-14v-10zM58597 40229c-174 21-348 40-521 56l-261 25-260 22-260 19c-174 11-347 21-519 30l-259 10-258 8-258 4v1l-257 1-256-2-255-5-254-8-254-12-252-16h-1l-250-18-250-23-249-26-247-31-246-33-244-39-243-41-241-46-240-51-237-54-236-58-234-63-232-68-229-72-228-76-225-82h-1l-223-85-220-91c-73-31-147-63-219-96l-215-100v-1c-72-34-142-69-213-105h-1l-210-110v-1l-208-115-205-122-202-125v-2c-67-42-133-85-199-131l-196-137c-65-47-130-94-193-144-64-47-127-97-190-147-63-51-125-102-187-154l-183-161c-61-54-121-109-180-165-59-57-118-113-177-172-58-57-116-117-173-177s-113-121-169-184c-56-62-111-126-165-189-153 121-313 233-479 337 1662 1761 3514 2945 5676 3519l130 34 133 32 136 31 138 30 140 27 142 27 144 26 146 24 147 22h1l149 21h1l150 20h1l152 18 155 16 155 16 157 13h1l157 13 159 10h1l160 9h1l161 7 163 6 163 5 164 3h330l166-1 166-4 167-5 167-7 166-9h1l166-9h1l167-11 167-15 167-15 167-16 165-19h2l165-19 165-22h1l164-24h1l163-25h1l163-27h1l162-29h1l161-31h1l160-32h1l159-34h1l158-36h1l156-37h2l155-40 155-41h1l152-43h1l151-46h1l149-47h1l148-48h1l146-50h1l144-53 143-55h1l140-55h1l137-58h1l136-61h1l134-61 132-64 129-66 127-68h1l124-70 122-71-256 53-257 52-257 50-257 49v1l-259 46-259 44-260 44-260 40-259 38-260 37h-1l-260 34h-1l-260 32zm-2861 3205c98 35 196 67 293 98l144 45 143 42 143 39 141 38c93 24 186 45 279 66l138 29 137 26v1c91 16 181 32 271 44h1l134 19 134 16 133 12v1c88 8 176 14 263 19l131 5 130 3h129l129-3 128-5h1l128-7v-1l127-10 127-13v-1l126-14v-1l126-18 126-21h1l124-23 126-26v-1l125-28 125-31 124-34 124-37 124-39 125-41 123-45 125-46v-1l123-50 125-51v-1l124-54 124-57 124-61h1l124-62 125-65 125-68 125-70 126-73 126-76 126-78 127-81 127-83h1l127-86 128-88 129-92 129-93 130-96 131-99 131-101 131-104 133-107 133-109c-328-192-718-433-1167-724l-101 63-100 61h-1l-101 61-102 60-102 59h-1l-102 59-103 58-104 57-104 56-104 56h-1l-105 55-105 54-106 54-106 53-106 52-107 51-107 51h-1l-107 50-108 49-108 48h-1l-108 48-109 47h-1l-110 47-109 45-111 45-111 43-110 44-112 43-112 41-111 41h-1l-112 40-112 40h-1l-113 38h-1l-112 38h-1l-113 36h-1l-113 36-115 37-114 34h-1l-115 34-115 33-116 33-116 31-116 30h-1l-116 30-117 29-117 28-118 28-117 25h-1l-118 27-118 25-118 24h-1l-118 23h-1l-119 22-119 22h-1l-119 22-120 19-120 19h-1l-120 19-120 17-122 16-121 16-121 15-122 14-122 13 149 55 148 53zm19787 314c15 298 1863 3473-443 5587-222 202-482 395-785 575-1493 937-2601 625-3250-882l-3630 2375c107 288 208 576 302 866 1252-644 2222-1316 2913-2018 1191 1045 2432 986 3727-169 581-43 373 573-626 1848-853 2344-2598 3730-5236 4160 9 139 17 278 23 417 1327 263 2453 66 3374-593 1096-782 1959-2225 2587-4328 167-553 786-512 1568-1036 965-908 1466-2205 1363-3526-101-1321-795-2526-1887-3276zm-9154 9156c-85-282-179-562-280-840-3004 1397-5517 2241-9014 1754-309 1727-106 3455 471 5181 3335-278 6575-1007 9505-2370-2647 926-5156 1311-7524 1153-941 167-1072-459-1187-1137-26-109-43-212-52-309-55-596 186-976 726-1146 12-3 23-4 35-7 108-30 229-53 361-68 1005-194 1913-426 2722-694 1612-485 3024-990 4237-1517zm-12462 5047 1792 1678 456-81c-409-2008-673-4104-537-5983l-1103-250c-514-106-1005-224-1474-352l-27 617c2232-305 3445 2573 1641 3947l-748 424zm-1080-1798c-2993 1229-7592 1160-13798-205-1533-458-2487-1223-2864-2296-164 172-286 435-340 732-629 3526 12339 5376 17958 1958 463-329 289-977-119-1223 94 527-185 871-837 1034zm16605-23336c-1293-126-1702-1552-1227-4280-1092 431-1534 1018-1564 2299-15 610 135 1339 426 1981l1 4c464 853 1330 1215 2594 1083 5237-394 8883-276 10942 354l27 4c-1676-1930-2798-4901-3025-7733-89 1585 15 2966 311 4145 20 62 36 121 47 179 103 528-172 848-825 958-205 34-447 48-727 41-1717 116-5916 1068-6980 965zm-25967 7216c-1262 369-2319 730-3174 1085 1014 1073 1731 2053 2012 3092 571-1200 1238-2396 2003-3588-286-188-566-384-841-589zm-4409-11940c-1-17-3-34-3-52-258-4341 1261-8639 4264-11871 3503-3768 8602-5627 13708-4998-11748-2596-21883 8600-18180 20014l1602-2214c-7-54-8-111-2-168 30-290 64-577 101-860-935 808-1433 858-1490 149zm3117-1040c-62 352-118 711-168 1078 299-99 610-169 929-211 50-309 106-616 169-919-308-40-618-23-930 52zm-1165 5220c232-486 630-893 1148-1130-551 151-1060 486-1425 999l277 131zm2109 3377c-1090-10-2029-765-2276-1823l-589-281c-84 1909 2405 3724 4311 2055l-392-187c-320 156-679 241-1054 236zm5960 5558c-1571-799-2982-1935-4280-3397l-1556 137c1632 1470 3574 2599 5717 3277l119-17zm7523 2488c93 24 186 45 279 66l-279-66zm-9155-1760c79 127 142 253 186 382 110 42 222 82 333 122-90 47-179 96-266 150 61 402-50 810-332 1226-871 826-2685 4072-3381 6485-696 2412 505 2129 1491 2603 1992 773 3524 481 3033-538-489-1011-3663-3022-3347-4341 398-1664 3134 145 4324 697 14608 6783 28821-7153 19884-10856 4045-713 6597 4194 3748 7103l-41 46c-3050 3521-6843 5812-11485 7167-3143 917-7149-361-10217-1279-1305-430-2802-980-4492-1651 1187 1072 3131 2437 4690 3248l-102 1668c-3280 1225-6773 899-10163-295 186-4497 1801-8679 4262-12496 511 276 1038 527 1579 750 97-64 195-128 296-191zm-13266 761c4541 334 6290 2941 5247 7825-305 550-739 747-1303 593-929-444-1741-568-2435-372-288 115-559 255-815 417-1356 865-2217 2365-2244 4017-27 1706 839 3278 2244 4174 655 266 1076 514 1261 743 89 110 124 215 106 317 672 2261-1012 3038-5053 2329 1682 3452 6530 1825 9729-345-522-1012-950-2160-1285-3442-2347-594-5753-2037-5255-4827 80-1235 1608-2748 3100-1957 812 432 1609 813 2390 1144 120-1900 479-3791 1078-5674 283-4210-4129-7710-6831-5063-72 72-145 146-216 221 95-36 189-68 282-100zm3631-106c-63-31-128-60-194-86 66 26 131 55 194 86zm8290 19130c-541-832-36-1109 1517-830 2133 110 3946-427 5440-1612l-694-684c-3167 1084-7352 1276-10842 738 1290 3481 3105 5365 4812 5946 1708 580 2184 964 2902 1611 284-330 576-650 875-957-1473-1198-2809-2602-4010-4212zm18823 14015c-2622 3193-8997 4450-9820-1111-838-4248-2102-6853-3792-7817-389 390-779 818-1169 1286 432 735 716 1544 813 2373l-138-112c150 644 280 1404 569 2446 437 4406 2647 6404 5737 7222 4546 1204 7832-180 8195-2573 11-435-289-1550-395-1714zm-2496-7969c-67-330-122-693-166-1089-204-1845-141-2959-1575-4464-47-43-88-85-124-126-539-615 175-718 2021-1135l7750-1743c-4126 289-8503 849-13109 1642 3763 3100 4161 5708 4329 7598 285-246 576-474 874-683z",
    style: {
      fill: "#cbc3cf"
    }
  }), mpathy_join_us_path7 || (mpathy_join_us_path7 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil12",
    d: "M59954 68886c371 4404 4817 3461 5364 8564 357 3325-5654 5191-11122 1785-1426-1002-2640-3019-2677-4319-85-2923-464-5057-1571-6586 1406-1734 2812-2958 4219-3671 1381-699 2771-903 4169-610 1532 1952 1514 3601 1618 4837zM40731 32142l4621 2202c61-222 94-455 94-697 0-717-291-1368-761-1837l1-1c-469-469-1120-760-1838-760-700 0-1335 276-1803 725l-34 36c-102 102-195 213-280 332zm3832 3459-4311-2055c-1 34-2 67-2 101 0 332 63 649 176 941 114 184 232 365 353 542 87 109 179 213 276 311l3 3c245 245 526 454 835 619 295 117 618 181 955 181 657 0 1258-243 1715-643zm9952 17714c369 90 737 174 1103 249-136 1879 128 3976 536 5984l-455 81-1792-1678 748-424c1804-1374 591-4252-1642-3947l29-617c468 128 959 245 1473 352zm-3141-2413c-1304-429-2801-979-4491-1650 1187 1072 3131 2437 4690 3248l-102 1669c-3280 1224-6773 898-10163-296 186-4497 1801-8679 4262-12496 765 413 1565 769 2395 1063-928 630-1578 1743-1952 3342 912-1717 1922-2743 3030-3081 489-91 998-92 1496 3 461 87 913 256 1333 510 34 27 72 51 112 70 5325 3690 11282 1707 13709-1397l127-244c918-1769 793-3292 3550-3777 4044-713 6597 4194 3748 7103l-41 46c-3050 3521-6844 5813-11485 7167-3143 917-7148-361-10218-1280zm-5141-13698c1662 1761 3514 2945 5675 3519 2565 681 7084 533 9423-796 125-70 248-144 372-218-3151 670-5885 857-8203 559-2917-375-5181-1509-6788-3401-153 121-313 233-479 337zm2844 4004c-1571-799-2982-1935-4280-3397-390 98-798 149-1217 149-114 0-227-4-339-12 1632 1470 3574 2599 5717 3276l119-16zm-1352-5423c1374 1682 3361 2691 5960 3025 2888 372 6523-77 10905-1348 803-796 1493-1639 2111-2581l-21-21-20-21c-1001-1062-1518-2593-1487-4032 17-861 238-1690 696-2348l14-20 2-2 12-18 5-4 10-16 5-7 10-14 7-8 8-11 8-11 6-8 11-14 5-5 12-17 2-3 15-18 1-2 15-18 1-1 14-18 4-3 12-17 5-5 18-21 10-11 7-10 8-8 11-12 6-7 12-14 5-4 14-16 2-2 17-17v-1l17-18 2-2 15-16 3-3 14-16 6-4 11-13 8-7 10-10 10-9 8-8 12-12 5-5 14-14 4-4 17-14 20-19 19-17 1-2 17-15 4-3 14-13 7-6 12-10 9-8 10-9 12-9c490-418 1914-955 2771-1347l11-5v-104c-13-4135-1594-8042-4560-11008-3670-3671-10537-686-14016 2072l-40 29c-3180 2535-5460 6202-6187 10483 1053 177 1994 682 2718 1405l1 1 2-1c912 912 1477 2173 1477 3565 0 1063-332 2051-896 2865zm14907 5077c449 291 839 532 1167 724-1750 1444-3286 2197-4853 2331-1099 94-2240-111-3507-591 2385-248 4624-989 6617-2120 195-111 386-225 576-344zm2360-1343c179-365 394-709 643-1023l-643 1023zm-26147-8333c255-695 657-1317 1170-1831l45-41c123-120 252-234 387-342-7-54-8-111-2-168 582-5623 2639-9927 5983-12929 2730-2450 6303-4013 10618-4699-1091-242-2225-370-3388-370-4300 0-8192 1744-11009 4560-2818 2817-4561 6709-4561 11008 0 1680 266 3297 757 4812zm3160-3056c299-98 610-168 929-210 748-4737 3248-8799 6756-11597l43-36c2650-2100 5870-3479 9342-3887-4854 468-8790 1987-11668 4570-2904 2605-4753 6321-5402 11160zm4098 2267c-646-644-1538-1043-2523-1043-484 0-944 95-1364 269 206-32 417-49 632-49 1123 0 2141 456 2877 1192l2 2 1-2c737 738 1193 1756 1193 2881 0 223-18 442-53 655 179-425 277-892 277-1382 0-985-399-1877-1044-2522l2-1zm-6135 6129v1c-369-369-667-809-873-1298-1574-2581-2482-5614-2482-8855 0-4705 1909-8967 4993-12051s7345-4993 12052-4993c4706 0 8967 1909 12051 4993 2980 2979 4870 7172 4980 11416l2 43c2934-1448 10076-7212 11000-7499 5732-1736 11116 7347 9051 14181-628 2080-1922 3677-3706 4230l-106 34c-1215 351-2481 186-3677-393-1883-587-4099-844-6448-882-931-15-1886 6-2851 53l755 3173c157 216 299 445 427 687 337 639 542 1321 620 2010 4858 2015 4879 8935 27 10978-719 2236-1731 3823-3034 4756-295 214-604 391-926 535 13596-739 26860 1344 35581 11454 904 1048 654 3199-63 4180-14924 20414-37070 25171-61060 20294-893 3576-3318 5702-7278 6376-4027 686-9683-192-16965-2633-895-263-619-1517 240-1448 5551 441 12570 218 12106-5426-1060-338-2126-695-3198-1067-6052 6051-15443 6971-22697 2451-2312-1441-5085-2166-7863-2588-619-94-849-881-366-1290 7741-6547 18565-13997 27207-11357 464-763 1017-1485 1627-2171-1499-2257-9661 576-13459 2025-808 308-1421-822-638-1321 5508-3785 10125-6274 13848-7466 3649-1168 6495-1107 8539 179 1620-1012 3373-1992 5259-2939l-976-1236c-3383 2273-8780 4183-11386 422-515-742-875-1677-1046-2809-1042-6904-615-15373 3848-19746 1568-1538 5945-2321 8894-2747-734-691-1407-1446-2009-2256zm28237-7989c-321 127-655 267-906 504l-1 2c-35 34-69 69-101 106l-4 5-6 6-37 45-6 8-3 4-9 12-27 35-8 11-1 1-8 12-9 12-4 5-9 15-13 17v2l-13 20c-235 365-361 824-393 1315l-1 27v3l-2 24-1 27-1 27v10l-1 17v27c-13 617 117 1269 362 1856 251 600 622 1118 1078 1436l7 4 6 5 3 2 3 3 6 4c340 227 725 341 1145 290 1247-149 2514-271 3777-352 2454-166 5222-156 7603 178-2345-2702-3607-7441-2844-10986-3218 2296-6047 3611-9582 5261zm-1844 9194-10 13 11-13c519-452 1121-813 1782-1056l-190-952c-13-5-25-10-37-15-467 710-990 1390-1555 2023h-1zm-22055 2891c-286-188-567-384-841-590-63 27-134 47-213 57l-4505 761c1512 822 2697 2295 3276 3968 628-1404 1389-2803 2283-4196zm12008 21864c-2872 310-5342 2290-7385 4767-2359-1946-3822-1173-6015-4365-681-993-1235-2191-1661-3598 3542 590 7861 416 11110-695l2557 2344c512 534 987 1067 1394 1547zm-2531-6144c-3004 1827-8358 2198-12525 1452-1624-289-5799-1341-5433-3411 119-659 582-1156 1078-849 712 605 9698 4197 15471 1859l538-240c815-532 1570 692 871 1189zm-3733 18615c54 1816 1367 3955 3235 5430 1690 1334 4011 2302 6867 2257 925 1188 2104 2170 3456 2864 6851 3514 15082-1458 15082-9223 0-8897-10489-13594-17137-7835-168-1890-565-4498-4329-7598 12068-2079 22560-2549 31116-780-5701 8234-3896 19518 4083 25565-15771 10316-34127 9561-51767 5061-1804-460-8992-2459-10547-3388l4269-282 2120-278c2860-475 5606-1115 5155-4464-223-5573-10747-2355-14206-1350l14-107c729-4953 6548-8588 10354-11527 1664-1285 3716-2215 5828-3262 2160 1397 4315 1549 5452 3698 593 1124 880 2733 955 5219zm-23183 7704c2964-978 6100-1565 9287-1838 1259-108 4184-267 4057 2037-96 1755-1925 2102-3949 2437-4453 739-11721 688-16042 441 2091-1297 4313-2307 6647-3077zm-8899 4376 7961 335-561-23c898-3 1702-8 2414-18 113 105 228 207 346 308l1571 1125c-5587 5188-13951 5851-20432 1813-2050-1278-4423-2039-6839-2520 6909-5671 16712-12249 24345-10137l-619 1902c-113 485-187 970-223 1454l-10 151c-2478 825-5215 2193-7370 3634-908 608-2085 1575-583 1976zm17915 3875c3039 930 6026 1716 8954 2356-1831 7028-10745 5851-17348 4144 4307-306 8470-1802 8394-6500zm-1402-21123-4343 3542c-1746-2105-6476-1012-9367-186 4320-2586 11188-6118 15197-4392l-1487 1036zm29159 1849c-430-382-1610-1138-1781-1446 5475-5809 15356-1960 15356 6093 0 7989-9744 11867-15255 6202 979-153 1750-361 2563-805 2624 1850 6199 1551 8476-726 4150-4150 1197-11275-4670-11275-1779 0-3461 719-4689 1957zm4437-13721-393 36 181-85 212 49zm3815-2003c-921 659-2047 856-3375 593-63-1715-479-3432-1102-5104l3630-2375c649 1507 1757 1819 3250 882 1089-610 1720-1489 1891-2635 148-994-73-2170-663-3527 80-250 142-505 187-762 2273 1309 2948 4296 1432 6458-1247 1779-2423 1346-2663 2142-628 2103-1491 3546-2587 4328zm-4841 715c-2930 1363-6170 2092-9505 2370-577-1727-780-3454-471-5181 3497 487 6010-357 9014-1754 531 1456 847 2979 962 4565zm2530-20278-111-457c997-119 2003-220 3005-296l282 1389c-952-507-2072-738-3176-636zm-4913 36337c1992-2030 5269-2049 7289-30 927 928 1502 2211 1502 3627 0 3998-4359 6410-7723 4429 2139-2406 759-5845-1068-8026zm28951 12002c-7722-5602-9449-16400-3833-24119l86-154c6830 1669 12265 4829 16420 9645 392 453 234 1840-138 2347-3668 5015-7833 9126-12445 12358l-90-77zM39631 58953c334 1282 763 2430 1285 3442-3631 2462-9384 4226-10224-1339-962-6377-657-14482 3421-18480 2702-2648 7114 853 6832 5063-600 1883-959 3774-1079 5674-781-331-1578-712-2390-1143-1492-792-3020 721-3100 1956-498 2790 2908 4233 5255 4827zm33924-10316c-501 275-913 835-1314-627l2351-2500c348 1303 224 2435-1037 3127zm7791-15830c-1893-2540-2368-4423-2330-7375l3954 540c-225 1271-91 2515 985 3839-1226 751-2225 1726-2609 2996zm3103-4989c-202-668-239-1772 369-1998 480-101 1025 689 1212 1270l25 86c190 660 138 1724-355 1900-518 157-1074-698-1251-1258zm2986-1154c-419-1349-1627-2624-3004-2262-1804 219-3554 73-5272-462 331-1896 1283-3715 2957-4249 1303-394 2647 9 3915 1052 4677 3848 4928 13218 490 14573-863 250-1787 114-2682-331l-1169-773c-62-662 111-1271 521-1826 645-875 1851-1716 2929-1900 1512-432 1761-2283 1346-3719l-31-103z"
  })), mpathy_join_us_path8 || (mpathy_join_us_path8 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil13",
    d: "M70194 82623c-1883 553-3976 254-5671-941-720 393-1407 601-2235 749l21-3c3313 2981 8332 3011 11681 71 3348-2940 3967-7921 1439-11591l-1-1c-1190-1544-2867-2640-4712-3161 4 0 8 2 12 3 2543 759 4549 2796 5236 5420 794 3033-333 6244-2848 8116-888 661-1885 1108-2922 1338zM35598 94507c1816-2319 4960 1248 8050 1291 403-425 1139-1862 1189-2530-2928-640-5914-1426-8954-2356 62 3897-2790 5591-6222 6230 2668-9 4290-1149 5937-2635z"
  })), mpathy_join_us_path9 || (mpathy_join_us_path9 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil14",
    d: "M37904 80800c4660 2150-1235 3796-17684 4938 1903 108 4379 179 6933 161 3245-22 6617-188 9109-601 2024-336 3853-683 3949-2438 82-1490-1113-1951-2307-2060z"
  })), mpathy_join_us_path10 || (mpathy_join_us_path10 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil13",
    d: "M27802 71421c-301 217-5494 1125-7031 1724 1789-511 4282-1124 6336-1019 1266 65 2365 402 3031 1205l4343-3541 1487-1037c-898-386-1940-509-3065-438-1986 736-3683 1768-5101 3106zM64326 71035c-448-916-797-851-1228-1465-69-99-135-209-197-330-362 283-710 600-1042 952 171 308 1351 1064 1781 1446 215-217 445-418 686-603z"
  })), mpathy_join_us_path11 || (mpathy_join_us_path11 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil14",
    d: "M72241 48010c401 1462 813 902 1314 627 424-233 720-516 912-838l-441-1687-1785 1898zM69581 36351c1104-101 2224 129 3176 636l-103-506-179-883c-1002 76-2008 177-3005 296l64 264 47 193z"
  })), mpathy_join_us_path12 || (mpathy_join_us_path12 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil13",
    d: "M82500 28969c237 1478-708 1986-1985 907-844-713-1174-2358-1499-4444-37 2952 437 4835 2330 7375 384-1270 1383-2246 2609-2996-1076-1324-1210-2568-985-3839-657 775-670 1744-470 2997zM87340 29380v2l1-2zM85647 30567c-1149 550-1968 1157-2456 1819-410 555-583 1164-521 1826l1169 773c895 445 1819 581 2682 331 1902-581 2942-2635 3142-5094-1147 4417-5123 5656-4845 3532 176-1346 645-2168 1695-3420-122 66-252 117-392 151l-474 82zM89578 80576c924 1326 2047 2542 3365 3598 4970-3376 9491-7686 13564-12929 41-478-15-952-215-1183-5250 4243-10820 7749-16714 10514z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M18366 93192c-223 0-447-4-670-13-15-1-30-1-45-2h-1c-2305-97-4609-663-6760-1705-544-263-1078-557-1599-881 2792 1733 5931 2596 9047 2601h28z",
    style: {
      fill: "#9578c0",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M18367 93192h-29 58-29zm4227-2761c487-342 530-710 10-874-207-65-410-92-611-92-459 0-914 139-1406 278-493 140-1024 279-1638 279-604 0-1287-136-2092-538-766-384-1208-968-1229-1687 1789 502 3553 921 5325 922 1643 0 3292-360 4976-1347l-557-23c896-3 1699-8 2410-18 113 105 228 207 346 308l1571 1125c-281-170-550-347-808-532-2024 1106-4123 1839-6297 2199zm-4043-5370c2155-1441 4892-2809 7370-3635-1559 520-3221 1254-4776 2086-916 490-1795 1015-2594 1549z",
    style: {
      fill: "#c46a0e",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M18396 93192h-58c-3116-5-6255-868-9047-2601-8-4-16-9-24-14-2042-1273-4404-2033-6811-2515-10-1-19-3-28-5 162-8 324-12 485-12 3949 0 7544 2309 13040 3664 525 130 1060 185 1589 185 2254 0 4387-995 5052-1463 2174-360 4273-1093 6297-2199 258 185 527 362 808 532-2962 2750-6706 4229-10534 4409-2 1-4 1-5 1h-4c-253 12-507 18-760 18zm-9129-2615zm20432-1813z",
    style: {
      fill: "url(#mpathy-join-us_svg__id0)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M20953 88719c-1772-1-3536-420-5325-922-86-2912 6991-6052 10293-6371-2478 826-5215 2194-7370 3635-796 533-1800 1343-1021 1804 100 69 238 125 421 167 5 2 11 3 17 5l6562 276 838 36h3-3l561 23c-1684 987-3333 1347-4976 1347zm-2402-3658zm7378 2311-558-23h1l557 23z",
    style: {
      fill: "url(#mpathy-join-us_svg__id2)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M18367 93192c-224 0-447-4-671-13 223 9 447 13 670 13h1zm-716-15h-1 1zm1505-3h4-4zm9-1c3828-180 7572-1659 10534-4409-2962 2751-6705 4229-10534 4409zm-8275-1701c-552-267-1094-566-1623-895-2050-1277-4423-2039-6839-2520 9 2 18 4 28 5 2407 482 4769 1242 6811 2515 8 5 16 10 24 14 521 324 1055 618 1599 881zm17238-3833c-118-101-233-203-346-308l346 308zm-2199-267zm0 0-561-23h3l558 23zm-558-23h-1l2412-18c-711 10-1514 15-2410 18h-1zm-841-36-6562-276c-6-2-12-3-17-5 5 1 11 3 16 4l6563 277zm-7000-448c-779-461 225-1271 1021-1804 799-534 1678-1059 2594-1549-916 490-1794 1015-2594 1549-795 532-1797 1340-1024 1802 1 0 2 2 3 2z",
    style: {
      fill: "#411535",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M23695 77516h-44 44z",
    style: {
      fill: "#f4cc97",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M3088 87519c260-210 525-421 793-633 1 0 1-1 2-1 4-3 8-7 12-10 5425-4283 12265-8703 18422-9293 7 0 14-1 21-2 7 0 13-1 19-2h3c6 0 12-1 17-1 2 0 3-1 5-1 5 0 11-1 16-1 1 0 3-1 5-1 5 0 10 0 15-1 2 0 4 0 6-1 5 0 9 0 14-1h7c4 0 8-1 12-1 3-1 6-1 9-1 4 0 7-1 10-1 4 0 8-1 11-1 2 0 6 0 8-1 4 0 9-1 13-1h3c383-32 763-48 1140-49h44c1055 2 2085 130 3078 404-7557 447-15452 3647-23685 9599z",
    style: {
      fill: "url(#mpathy-join-us_svg__id5)"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M3881 86886c1 0 1-1 2-1-1 0-1 1-2 1zm14-11c5426-4284 12265-8704 18422-9293-6157 590-12997 5010-18422 9293zm22878-8955zm-4456-338c7 0 14-1 21-2-7 1-14 2-21 2zm21-2c7 0 14-1 19-2-6 1-12 2-19 2zm22-2c6 0 12-1 17-1-5 0-11 1-17 1zm22-2c5 0 10-1 16-1-5 0-11 1-16 1zm21-2c5 0 10 0 15-1-5 1-10 1-15 1zm21-2c5 0 9 0 14-1-5 1-9 1-14 1zm21-1c4-1 8-1 12-1-4 0-8 1-12 1zm21-2c4 0 7-1 10-1-3 0-6 1-10 1zm21-2c3 0 5 0 8-1-2 1-6 1-8 1zm21-2h3-3z",
    style: {
      fill: "#a89aae",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M20220 85738c6145-2854 11879-4508 17203-4965-482-11-934 21-1269 50-3187 274-6323 860-9287 1838-231 77-461 155-690 236-2082 737-4073 1672-5957 2841z",
    style: {
      fill: "#9addff"
    }
  }), mpathy_join_us_path13 || (mpathy_join_us_path13 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil24",
    d: "M43648 95798c-3558 2631-8944 3170-16159 1614 5660 1463 13020 2538 16159-1614zM20771 73145c5167-2695 9211-4306 12132-4830-3894 247-8780 2824-12132 4830zM79511 22604c3687-4324 7053-2578 10096 5236-327-2667-1527-5411-3576-7097-2850-2345-5468-1043-6520 1861zM89139 61524c6736 1275 12453 4120 17153 8538-4155-4816-9590-7976-16420-9645l-86 154c-228 313-443 631-647 953z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M97456 69128c-110 0-221-14-332-44-59-19-119-38-177-58-116-37-229-72-342-108-340-161-599-465-698-839-131-492 37-1015 430-1340 237-196 532-296 828-296 168 0 338 32 498 98 23 11 47 22 70 32 114 52 226 104 340 156 530 293 790 925 599 1515-175 539-675 884-1216 884zm-3462-938c-1296-312-2475-512-3534-603-835-75-1475-775-1475-1613 0-839 640-1539 1475-1615 1083 158 2181 400 3293 725 170 49 339 101 508 154 490 244 834 730 878 1301 59 752-420 1442-1145 1651z",
    style: {
      fill: "#f05e64",
      fillRule: "nonzero"
    }
  }), mpathy_join_us_path14 || (mpathy_join_us_path14 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil24",
    d: "M68329 69681c4760 0 7602 4690 6289 8677 1346-2847 429-6251-2163-8039-2538-1749-5950-1448-8140 693 4 8 7 15 11 23 1135-866 2536-1354 4003-1354z"
  })), mpathy_join_us_path15 || (mpathy_join_us_path15 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil3",
    d: "M86053 27170c-142-479-508-1076-878-1286-236-99-463-45-628 140-5 7-11 13-15 20l-8 12-6 8-11 16c-206 275-289 780-125 1469l6 28 1 9 5 19 3 15 3 13c0 8 1 15 5 21l1 7 7 27 7 27 2 7c1 6 2 13 5 19l4 13 3 13 6 20 2 6 7 25c237 751 590 1138 916 1232 234 67 456-17 612-227 0-5 3-9 7-12 2-6 5-11 8-17l9-15 3-7c200-312 263-859 56-1576-1-7-4-14-5-21l-2-5zM90027 15970c1952-1302 3690-2578 5212-3826 1530-1255 2834-2477 3911-3662 274-301 252-768-48-1041-179-161-415-220-635-178-911 114-1745 160-2502 133-282-10-554-29-815-60 1576-2657 3475-5103 5696-7336-1400 1090-2741 2249-4023 3479-1275 1223-2483 2512-3624 3864-67 78-118 172-148 279-108 391 122 796 514 904 700 195 1486 309 2354 338 259 10 528 11 802 5-727 704-1533 1417-2416 2140-1471 1208-3169 2452-5090 3732-338 225-432 682-207 1021 223 338 680 431 1019 208zm10300 23196c49-789-11-1608-177-2458-80-413-186-833-319-1262 2281 269 4714 782 7298 1540-1610-830-3102-1522-4475-2078-1388-562-2664-989-3828-1280-148-37-308-28-461 34-374 156-553 587-396 962 342 823 588 1612 736 2366 59 307 103 607 131 901-826-443-1650-852-2468-1226-1190-543-2351-1002-3479-1374-387-128-803 83-931 469-127 387 84 804 471 930 1099 363 2210 801 3328 1312 1124 512 2280 1109 3467 1791 353 202 804 80 1006-273 63-112 95-234 97-354zm-6102-13356c1982-572 3818-1062 5510-1468 1679-400 3237-724 4670-968 401-66 671-445 605-847-29-171-115-318-234-426-453-427-977-813-1569-1157l-677-361c3110-2126 6342-4149 9695-6068-2340 792-4484 1656-6431 2592-1949 937-3693 1945-5228 3022-120 84-217 204-271 354-136 381 62 802 445 938 637 230 1213 495 1729 795l26 15c-973 195-2006 422-3100 683-1730 414-3589 910-5578 1485-390 112-614 521-502 909 113 391 521 615 910 502z"
  })), mpathy_join_us_path16 || (mpathy_join_us_path16 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil12",
    d: "M55760 38937c-160 0-317-2-473-7-558-14-1092-54-1602-120-2599-334-4586-1343-5960-3025 564-814 896-1802 896-2865 0-1392-565-2653-1477-3565l-2 1-1-1c-723-723-1665-1228-2718-1405 656-3865 2578-7229 5285-9711-1417 4107-1246 7769 509 10982 259 473 553 937 881 1392 585 1068 932 2090 1040 3069 357 3115 2475 4673 6354 4672 1696 0 3729-297 6098-893-3391 984-6334 1476-8830 1476z"
  })), mpathy_join_us_path17 || (mpathy_join_us_path17 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-join-us_svg__fil12",
    d: "M55287 38930c-558-14-1092-54-1603-120-2598-334-4585-1343-5959-3025 1374 1682 3361 2691 5960 3025 510 66 1044 106 1602 120zm-7562-3145c808-3803-208-6237-3302-7835 1053 177 1995 682 2718 1405l1 1 2-1c912 912 1477 2173 1477 3565 0 1063-332 2051-896 2865z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M71764 73043c3064 4601-666 9835-6221 8056 3364 1981 7723-430 7723-4429 0-1485-592-2733-1502-3627zM55618 15879c5762 283 9952 3136 12571 8560-2204-7894-6394-10746-12571-8560zm-5523 14069c370-165 858 124 1091 645 232 521 121 1077-249 1242-369 166-858-123-1090-644-233-522-122-1078 248-1243zm-28-6235c-842-375-1954 282-2484 1470-529 1187-277 2454 565 2830 843 376 1954-282 2485-1470 529-1186 276-2454-566-2830zm19132 49110c622 0 1127 545 1127 1217s-505 1217-1127 1217-1126-545-1126-1217 504-1217 1126-1217z",
    style: {
      fill: "#999"
    }
  }))));
};
/* harmony default export */ const mpathy_join_us = (SvgMpathyJoinUs);
;// CONCATENATED MODULE: ./src/components/svgs/mpathy-title.svg
function mpathy_title_extends() { mpathy_title_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return mpathy_title_extends.apply(this, arguments); }

var SvgMpathyTitle = function SvgMpathyTitle(props) {
  return /*#__PURE__*/external_react_.createElement("svg", mpathy_title_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 519.122,
    height: 273.916,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 5405 2852"
  }, props), /*#__PURE__*/external_react_.createElement("path", {
    d: "m257 44 180 564L618 44h257v810H679V665l19-387-196 576H373L177 278l19 387v189H0V44h257zm1292 514c0 94-21 168-63 224s-99 84-171 84c-55 0-101-20-136-61v281H991V253h176l5 55c36-44 83-67 142-67 74 0 132 28 173 82 41 55 62 130 62 226v9zm-188-12c0-107-31-160-93-160-45 0-74 16-89 48v237c16 33 46 50 90 50 60 0 90-52 92-155v-20zm609 308c-6-12-12-30-17-53-35 43-83 65-145 65-57 0-105-17-145-52-39-34-59-77-59-129 0-66 24-115 72-149 48-33 118-50 210-50h58v-32c0-55-24-83-72-83-44 0-66 22-66 66h-188c0-58 25-105 74-141 50-36 113-55 190-55s137 19 182 57c44 37 67 89 68 154v266c1 55 9 98 26 127v9h-188zm-117-122c23 0 43-5 58-15 16-10 27-21 33-34v-96h-54c-66 0-98 29-98 88 0 17 5 31 17 41 11 11 26 16 44 16zm601-628v149h99v130h-99v275c0 23 4 39 12 47 8 9 25 14 49 14 18 0 34-1 46-4v135c-33 10-69 16-105 16-65 0-112-15-143-46-31-30-46-77-46-138V383h-77V253h77V104h187zm356 213c40-50 91-76 153-76 67 0 117 20 151 59 33 40 51 98 51 174v380h-187V479c0-32-7-55-20-70s-35-23-66-23c-39 0-66 12-82 37v431h-187V0h187v317zm701 275 100-339h201l-246 702-10 25c-35 78-97 117-185 117-24 0-50-4-77-11V952h24c26 0 47-4 60-11 14-8 25-21 31-41l15-40-209-607h200l96 339z",
    style: {
      fill: "#000",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M503 1504H196v193h362v151H0v-810h559v150H196v171h307v145zm303-258 6 71c43-55 100-82 172-82 76 0 127 30 154 90 41-60 100-90 177-90 122 0 184 74 188 221v392h-188v-380c0-31-5-54-16-68-10-14-29-21-56-21-38 0-65 17-83 50v419H972v-379c0-32-5-55-15-69s-29-21-57-21c-36 0-64 17-83 50v419H630v-602h176zm780 295c0-60 12-113 35-160 24-47 57-83 101-109 44-25 95-37 154-37 90 0 161 28 213 83 52 56 78 132 78 228v7c0 94-26 168-78 223s-123 83-212 83c-85 0-154-26-206-77s-80-121-84-209l-1-32zm188 12c0 55 9 96 26 122s43 39 77 39c67 0 101-51 103-154v-19c0-108-35-162-104-162-62 0-96 47-102 140v34zm694-456v149h99v130h-99v275c0 23 4 39 12 48s24 13 48 13c19 0 35-1 47-3v134c-34 11-69 16-106 16-64 0-112-15-142-46-31-30-47-76-47-138v-299h-76v-130h76v-149h188zm371 751h-188v-602h188v602zm-200-757c0-27 10-49 29-66 20-18 45-26 75-26 31 0 56 8 75 26 20 17 29 39 29 66 0 26-9 48-29 66-19 17-44 25-75 25-30 0-55-8-75-25-19-18-29-40-29-66zm291 450c0-60 12-113 35-160 24-47 57-83 101-109 44-25 95-37 154-37 90 0 161 28 213 83 52 56 78 132 78 228v7c0 94-26 168-78 223s-123 83-212 83c-86 0-154-26-206-77s-80-121-84-209l-1-32zm188 12c0 55 8 96 26 122 17 26 43 39 77 39 67 0 101-51 102-154v-19c0-108-34-162-103-162-63 0-97 47-102 140v34zm648-307 6 71c41-55 98-82 171-82 63 0 110 18 141 56 31 37 47 94 48 169v388h-188v-380c0-31-6-53-18-67-13-14-35-22-67-22-37 0-64 15-82 44v425h-187v-602h176zm809 602c-7-13-13-30-18-54-35 43-83 65-145 65-56 0-105-17-144-52-40-34-60-77-60-129 0-66 24-115 73-148 48-34 118-50 210-50h58v-32c0-56-24-83-72-83-45 0-67 22-67 65h-187c0-58 24-105 74-141 49-36 113-54 189-54 77 0 138 18 182 56 45 37 67 89 69 154v266c0 55 9 98 25 127v10h-187zm-118-122c24 0 43-5 59-15 15-10 26-22 33-35v-96h-55c-65 0-98 29-98 88 0 17 6 31 18 42 11 10 26 16 43 16zm581 122h-188V993h188v855zM301 2555H195v286H0v-810h319c96 0 171 21 225 64s81 103 81 181c0 56-11 103-34 140s-58 67-107 90l169 326v9H444l-143-286zm-106-151h124c37 0 65-9 83-29 19-19 29-47 29-82s-10-62-29-82-47-30-83-30H195v223zm831 448c-93 0-167-27-224-82-57-56-86-127-86-216v-15c0-62 11-116 34-163s56-84 100-109c44-26 96-39 156-39 84 0 151 26 200 79 49 52 74 125 74 219v73H907c7 34 21 60 44 80 22 19 52 28 88 28 59 0 105-20 139-62l85 102c-23 32-56 57-99 76-43 20-89 29-138 29zm-21-479c-55 0-88 36-98 109h189v-15c1-30-7-53-23-70-16-16-39-24-68-24zm583 245 95-379h197l-196 602h-191l-197-602h198l94 379zm316-84c0-60 12-113 35-160 24-47 57-83 101-108 44-26 95-38 154-38 90 0 161 28 213 84 52 55 78 131 78 227v7c0 94-26 168-78 224-52 55-123 82-212 82-86 0-154-26-206-77s-80-121-84-209l-1-32zm188 12c0 56 8 97 26 123 17 26 43 38 77 38 67 0 101-51 102-154v-19c0-108-34-161-103-161-63 0-97 46-102 139v34zm673 295h-188v-855h188v855zm474-65c-40 51-93 76-161 76-66 0-116-19-150-57-34-39-51-94-51-166v-390h188v391c0 52 25 77 75 77 43 0 73-15 92-46v-422h188v602h-176l-5-65zm502-686v149h99v130h-99v276c0 22 4 38 12 47s25 13 49 13c18 0 34-1 46-3v134c-33 11-69 16-105 16-65 0-112-15-143-45-31-31-46-77-46-139v-299h-77v-130h77v-149h187zm371 751h-188v-602h188v602zm-199-757c0-27 9-49 29-66 19-17 44-26 75-26 30 0 56 9 75 26s29 39 29 66-10 49-29 66-45 25-75 25c-31 0-56-8-75-25-20-17-29-39-29-66zm290 450c0-60 12-113 35-160 24-47 57-83 101-108 44-26 95-38 154-38 90 0 161 28 213 84 52 55 78 131 78 227v7c0 94-26 168-78 224-52 55-123 82-212 82-85 0-154-26-206-77s-80-121-84-209l-1-32zm188 12c0 56 9 97 26 123s43 38 77 38c67 0 101-51 103-154v-19c0-108-35-161-104-161-62 0-96 46-102 139v34zm648-307 6 71c41-55 99-82 172-82 62 0 109 19 140 56s47 94 48 169v388h-188v-380c0-30-6-53-18-67s-34-21-67-21c-36 0-64 14-82 43v425h-187v-602h176z",
    style: {
      fill: "#fff",
      fillRule: "nonzero"
    }
  }));
};
/* harmony default export */ const mpathy_title = (SvgMpathyTitle);
;// CONCATENATED MODULE: ./src/components/svgs/mpathy-our-mission.svg
var mpathy_our_mission_defs, mpathy_our_mission_path, mpathy_our_mission_path2, mpathy_our_mission_path3, mpathy_our_mission_path4, mpathy_our_mission_path5, mpathy_our_mission_path6, mpathy_our_mission_path7, mpathy_our_mission_path8, mpathy_our_mission_path9, mpathy_our_mission_path10, mpathy_our_mission_path11, mpathy_our_mission_path12, mpathy_our_mission_path13, mpathy_our_mission_path14, mpathy_our_mission_path15, mpathy_our_mission_path16, mpathy_our_mission_path17, mpathy_our_mission_path18, mpathy_our_mission_path19, mpathy_our_mission_path20, mpathy_our_mission_path21, mpathy_our_mission_path22, mpathy_our_mission_path23, mpathy_our_mission_path24, mpathy_our_mission_path25, mpathy_our_mission_path26, mpathy_our_mission_path27, mpathy_our_mission_path28, mpathy_our_mission_path29, mpathy_our_mission_path30, mpathy_our_mission_path31, mpathy_our_mission_path32, mpathy_our_mission_path33, mpathy_our_mission_path34, mpathy_our_mission_path35, mpathy_our_mission_path36, mpathy_our_mission_path37, mpathy_our_mission_path38, mpathy_our_mission_path39, mpathy_our_mission_path40, mpathy_our_mission_path41, mpathy_our_mission_path42, mpathy_our_mission_path43, mpathy_our_mission_path44, mpathy_our_mission_path45, mpathy_our_mission_path46, mpathy_our_mission_path47, mpathy_our_mission_path48, mpathy_our_mission_path49, mpathy_our_mission_path50, mpathy_our_mission_path51, mpathy_our_mission_path52, mpathy_our_mission_path53, mpathy_our_mission_path54, mpathy_our_mission_path55, mpathy_our_mission_path56, mpathy_our_mission_path57, mpathy_our_mission_path58, mpathy_our_mission_path59, mpathy_our_mission_path60, mpathy_our_mission_path61, mpathy_our_mission_path62, mpathy_our_mission_path63, mpathy_our_mission_path64, mpathy_our_mission_path65, mpathy_our_mission_path66;
function mpathy_our_mission_extends() { mpathy_our_mission_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return mpathy_our_mission_extends.apply(this, arguments); }

var SvgMpathyOurMission = function SvgMpathyOurMission(props) {
  return /*#__PURE__*/external_react_.createElement("svg", mpathy_our_mission_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: 352.229,
    height: 569.046,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 9269 14891"
  }, props), mpathy_our_mission_defs || (mpathy_our_mission_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("style", null, ".mpathy-our-mission_svg__fil5{fill:#000;fill-rule:nonzero}.mpathy-our-mission_svg__fil14,.mpathy-our-mission_svg__fil18,.mpathy-our-mission_svg__fil9{fill:#2f1c50;fill-rule:nonzero}.mpathy-our-mission_svg__fil14,.mpathy-our-mission_svg__fil9{fill:#371a45}.mpathy-our-mission_svg__fil14{fill:#999}.mpathy-our-mission_svg__fil4,.mpathy-our-mission_svg__fil7,.mpathy-our-mission_svg__fil8{fill:#b5202f;fill-rule:nonzero}.mpathy-our-mission_svg__fil7,.mpathy-our-mission_svg__fil8{fill:#b9afbe}.mpathy-our-mission_svg__fil8{fill:#c6b9cf}.mpathy-our-mission_svg__fil10,.mpathy-our-mission_svg__fil2,.mpathy-our-mission_svg__fil6{fill:#f92323;fill-rule:nonzero}.mpathy-our-mission_svg__fil10,.mpathy-our-mission_svg__fil6{fill:#ffce00}.mpathy-our-mission_svg__fil6{fill:#fff}"))), /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-our-mission_svg__Layer_x0020_1"
  }, /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-our-mission_svg___2526325402880"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M4635 14891c-2560 0-4635-309-4635-689 0-147 309-283 835-395 12 30 27 58 45 85 46 70 111 124 179 161 67 39 138 64 207 83 140 39 280 55 418 68 138 11 275 16 411 20 62 1 121 2 183 2h77c18-1 36-3 53-4 36-1 71-6 107-10 141-18 280-53 414-106 67-28 133-59 195-100 32-18 61-42 91-64 15-13 28-26 43-39 14-12 27-26 40-41 27-28 49-61 71-94l27-55c9-17 14-33 21-50 12-33 26-65 37-99l9-29c375-15 767-22 1172-22 433 0 853 9 1251 25 6 18 11 35 17 53l24 62 12 30c5 11 7 20 14 32 42 93 109 168 181 227 74 60 154 105 237 143 82 36 167 66 254 87 86 22 174 38 263 46 62 6 127 9 189 9 25 0 50-1 74-1 171-3 342-8 514-23 87-7 173-17 260-32s175-36 262-69c44-17 87-38 128-64 42-26 82-58 116-97 31-35 56-75 75-118 483 108 763 239 763 379 0 380-2075 689-4634 689z",
    style: {
      fill: "#000",
      fillRule: "nonzero",
      fillOpacity: 0.14902
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M6593 6480c-1059-2-2110-255-2110-255l-42-1s-1052 243-2111 238c0 0-541 3438-2102 6138 0 0 1455 362 3008-173 0 0 548 368 1211 371 662 2 1213-363 1213-363 1550 547 3006 195 3006 195-1548-2711-2073-6150-2073-6150z",
    style: {
      fill: "#ff2261",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path || (mpathy_our_mission_path = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil2",
    d: "M8666 12630s-156 38-420 70c-544 64-1544 103-2587-265 0 0-549 365-1212 363-663-3-1211-371-1211-371-1043 359-2041 314-2585 246-266-34-423-73-423-73 1561-2700 2102-6138 2102-6138 1059 5 2111-238 2111-238l42 1s1051 253 2110 255c0 0 525 3439 2073 6150z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M8479 12581c-264-433-498-880-703-1319-14-135-30-270-47-405 230 577 498 1160 807 1714-18 3-37 6-57 10zm-8038-25c-30-5-58-10-82-15 391-692 717-1431 986-2147 44 26 92 49 144 68-275 676-621 1404-1048 2094z",
    style: {
      fill: "#fdbdbd",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path2 || (mpathy_our_mission_path2 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil4",
    d: "M4453 12599h-6c-278-1-536-67-741-142 69-403 129-806 209-1202 267 79 526 120 769 120 239 0 491-37 752-110 13 65 26 129 37 195 50 267 92 536 137 806-148 87-614 333-1157 333zm3429-67c-11-166-23-332-36-499 88 162 182 322 280 480-75 8-157 14-244 19zm-6469-11c-244 0-462-15-642-34v1c338-536 619-1101 850-1645-6 43-11 87-16 130-16 132-30 264-44 396-37 384-68 767-94 1152h-54z"
  })), mpathy_our_mission_path3 || (mpathy_our_mission_path3 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M3236 12342c17 0 33 5 47 15 5 3 536 354 1164 356h6c625 0 1155-345 1160-348 22-15 50-18 75-9 1267 447 2482 281 2848 215-1374-2463-1930-5505-2015-6007-978-12-1940-230-2048-255h-23c-107 24-1070 232-2048 237-88 502-658 3543-2043 5995 366 69 1581 243 2849-194 9-3 19-5 28-5zm1217 540h-6c-591-2-1086-279-1222-362-1544 519-2957 177-3017 162-26-6-47-24-58-49-10-24-8-52 5-75 1535-2655 2086-6075 2092-6109 6-42 42-72 83-72h36c1025 0 2046-233 2056-235 6-1 13-2 19-2h43c6 0 13 1 19 2 11 3 1054 252 2090 254 42 0 77 30 84 72 5 34 541 3454 2063 6120 13 24 15 51 4 76-10 24-32 42-58 49-60 14-1475 345-3016-185-136 83-629 354-1217 354z"
  })), mpathy_our_mission_path4 || (mpathy_our_mission_path4 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M1701 10435c-878-179-624-1005-619-1025h1c-36-23-71-46-104-69 0 0 1188-145 1419-695 8-19 15-40 21-60 701 1043 78 2011-718 1849z"
  })), mpathy_our_mission_path5 || (mpathy_our_mission_path5 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "m2114 8216 6 6c1143 1167 469 2394-419 2213-889-181-618-1025-618-1025-2257-1436 1031-3205 1031-3205 622-343 1261-560 1261-560l-402 1228-318 975c-431 187-541 368-541 368z"
  })), mpathy_our_mission_path6 || (mpathy_our_mission_path6 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M2047 8164c-104-79-230-158-360-207 0 0 300-165 400-283 392-461 336-851 626-881-119 222-217 453-307 688-63 167-121 336-174 506-117 86-169 153-185 177z"
  })), mpathy_our_mission_path7 || (mpathy_our_mission_path7 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1873 10537c-62 0-125-6-188-19-291-59-498-192-617-394-150-256-110-549-82-676-533-354-795-760-778-1208 41-1115 1792-2069 1866-2109 620-343 1267-563 1274-566 44-15 92 9 107 53s-9 92-53 107c-6 3-640 219-1247 554-18 10-1741 949-1778 1967-15 398 238 766 751 1093 32 20 47 60 35 97-1 3-104 339 52 604 93 158 262 263 503 312 332 68 641-79 806-384 206-379 190-1022-470-1693-27-27-32-70-12-103 11-18 119-184 495-363 42-20 92-2 112 40 21 42 3 93-39 113-213 101-327 196-382 250 672 717 673 1415 445 1836-168 310-470 489-800 489z"
  })), mpathy_our_mission_path8 || (mpathy_our_mission_path8 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M2068 8275c-29-30-61-61-93-90-32-30-65-58-98-87-68-55-138-108-216-152 87 20 172 52 255 88 41 18 82 38 123 58s80 41 122 65c36 21 49 67 28 103-21 37-68 49-104 28-6-3-12-8-17-13zM1118 9344c35 21 72 44 107 66l108 68 110 67c36 23 74 45 112 67-44-2-88-8-132-16-43-8-86-19-128-31s-84-25-125-40c-42-14-82-30-123-49-37-17-54-62-37-99 18-38 63-55 100-37 3 1 5 2 8 4z"
  })), mpathy_our_mission_path9 || (mpathy_our_mission_path9 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil8",
    d: "M1693 10347c-228-51-388-155-478-307-93-158-94-340-79-463 76 183 248 453 608 465-18 101-35 203-51 305z"
  })), mpathy_our_mission_path10 || (mpathy_our_mission_path10 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1680 10431c-706-156-657-739-616-947 15 7 29 13 44 18 7 23 16 48 28 75-15 123-14 305 79 463 90 152 250 256 478 307-5 28-9 56-13 84z"
  })), mpathy_our_mission_path11 || (mpathy_our_mission_path11 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1108 9502c-15-5-29-11-44-18 9-43 17-70 18-74h1s7 37 25 92zM489 8938c-35 0-63-29-63-64-1-249 207-509 530-660 368-173 926-219 1391 170 27 22 31 62 8 89-22 27-62 31-89 8-419-350-924-308-1256-153-278 131-458 345-458 546 1 35-28 64-63 64z"
  })), mpathy_our_mission_path12 || (mpathy_our_mission_path12 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M7631 10435c879-179 625-1005 619-1025 36-23 71-46 104-69 0 0-1188-145-1419-695-9-19-16-40-21-60-702 1043-78 2011 717 1849z"
  })), mpathy_our_mission_path13 || (mpathy_our_mission_path13 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M7218 8216c-2 2-4 4-5 6-1143 1167-470 2394 418 2213 890-181 619-1025 619-1025 2257-1436-1032-3205-1032-3205-621-343-1260-560-1260-560l401 1228 319 975c431 187 540 368 540 368z"
  })), mpathy_our_mission_path14 || (mpathy_our_mission_path14 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M7286 8164c-16-23-65-87-175-169-131-410-286-814-477-1200 274 41 226 426 612 879 100 118 400 283 400 283-131 49-256 128-360 207z"
  })), mpathy_our_mission_path15 || (mpathy_our_mission_path15 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M7460 10537c-330 0-632-179-800-489-228-421-227-1119 445-1836-54-54-169-149-382-250-42-20-60-71-40-113s71-60 113-40c376 179 484 345 495 363 20 33 15 76-12 103-660 671-676 1314-470 1693 165 305 474 452 805 384 241-49 411-154 504-312 156-265 53-601 52-604-12-37 2-77 35-97 513-327 766-695 751-1093-37-1019-1760-1957-1777-1967-608-335-1242-551-1248-554-45-15-68-63-53-107s63-68 107-53c6 3 654 223 1274 566 74 40 1825 994 1866 2109 17 448-245 854-778 1208 28 127 68 420-83 676-118 202-325 335-616 394-63 13-126 19-188 19z"
  })), mpathy_our_mission_path16 || (mpathy_our_mission_path16 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M8286 9476c-41 19-82 35-123 49-41 15-83 28-125 40-43 12-85 23-129 31-43 8-87 14-131 16 38-22 75-44 112-67l109-67 109-68c35-22 72-45 107-66 36-22 82-10 103 25 22 36 10 82-25 104-3 1-5 2-7 3z"
  })), mpathy_our_mission_path17 || (mpathy_our_mission_path17 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil8",
    d: "M7657 10343c-9-53-17-107-27-160-7-47-15-95-23-142 347-20 516-284 590-464 15 123 14 305-79 463-88 149-243 251-461 303z"
  })), mpathy_our_mission_path18 || (mpathy_our_mission_path18 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "m7669 10427-12-84c218-52 373-154 461-303 93-158 94-340 79-463 11-27 21-52 28-75 14-5 29-11 43-18 41 207 90 782-599 943z"
  })), mpathy_our_mission_path19 || (mpathy_our_mission_path19 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M8225 9502c18-55 25-92 25-92 1 4 10 31 18 74-14 7-29 13-43 18zM8844 8938c-35 0-64-29-64-64 1-201-179-415-457-546-332-155-837-197-1256 153-27 23-67 19-90-8-22-27-18-67 8-89 466-389 1024-343 1392-170 322 151 531 411 530 660 0 35-28 64-63 64z"
  })), mpathy_our_mission_path20 || (mpathy_our_mission_path20 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M8464 13651c-43 416-512 481-1392 491-426 5-919-169-1046-469-127-299-217-748-299-1226-83-479-157-987-252-1404-521 162-1079 162-1600 0h-2c-4 17-8 35-12 53-183 831-290 1992-539 2577-127 300-620 474-1046 469-880-10-1349-75-1392-491-10-91 9-173 44-246 148-302 597-445 597-445s63-1178 174-2065c189-1501 608-3036 1062-4131l429-1382h2940l457 1382c454 1095 874 2630 1062 4131 111 887 175 2065 175 2065s690 219 640 691z"
  })), mpathy_our_mission_path21 || (mpathy_our_mission_path21 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M2278 14057c-58 0-119-1-179-2-134-4-269-9-401-20s-264-28-386-61c-122-34-234-88-292-175-29-44-45-96-52-154-6-53 0-106 17-157 99 115 289 228 656 257 117 9 231 14 341 14 648 0 1150-173 1189-653 46-561-34-1157-73-1596-24-269-22-490-18-609 213 116 439 221 673 302-98 477-163 955-250 1428-49 265-101 530-178 784l-31 94c-10 31-23 61-34 92-6 14-12 31-18 44l-19 36c-16 23-30 47-51 68-10 11-19 22-31 32-11 10-21 20-33 30-24 18-48 37-75 53-51 33-109 60-167 85-119 47-245 79-373 95-32 4-64 8-96 10l-48 3h-71zM7075 14058c-58 0-113-2-171-8-80-7-160-22-238-41s-154-46-226-79c-72-32-141-71-199-119-58-47-106-103-134-165-4-7-8-18-11-27l-11-28-22-57c-14-39-26-79-39-118-96-317-156-650-214-983-57-333-109-669-171-1004-12-71-27-142-41-214 234-77 460-178 671-289 4 123 4 332-19 584-39 439-119 1035-73 1596 39 480 541 653 1190 653 109 0 223-5 340-14 367-29 558-142 656-256 6 17 11 35 14 53 6 34 6 68 3 103-8 72-32 135-76 184-43 51-107 88-178 115-72 28-150 47-230 61s-162 23-245 30c-165 14-334 19-502 22-25 0-50 1-74 1z"
  })), mpathy_our_mission_path22 || (mpathy_our_mission_path22 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M6613 6753c240 475 422 978 574 1487 77 255 146 512 207 770 63 259 117 519 167 780 24 131 48 262 69 393 23 131 42 263 62 394 37 264 69 528 95 792 52 529 90 1057 121 1587l-59-76c47 15 86 31 127 50 41 18 81 38 121 60 78 43 154 93 224 155 69 62 132 136 176 225 21 45 37 93 46 143s10 101 5 151c-5 48-17 98-36 145-19 48-47 93-81 132s-74 71-116 97c-41 26-84 47-128 64-87 33-175 54-262 69s-173 25-260 32c-172 15-343 20-514 23-83 2-176 1-263-8-89-8-177-24-263-46-87-21-172-51-254-87-83-38-163-83-237-143-72-59-139-134-181-227-7-12-9-21-14-32l-12-30-24-62c-14-42-27-83-41-125-100-333-160-669-219-1004-57-335-108-671-170-1002-15-84-32-166-48-248l-27-123-3-16-2-7-1-4c139 79 123 70 107 62-9-5-18-10-1 0h-2l-31 10-63 18c-169 45-342 75-517 89-174 13-350 10-524-9-174-21-346-57-513-109l108-62c-117 525-189 1064-286 1600-50 269-103 537-184 804l-32 99c-11 34-25 66-37 99-7 17-12 33-21 50l-27 55c-22 33-44 66-71 94-13 15-26 29-40 41-15 13-28 26-43 39-30 22-59 46-91 64-62 41-128 72-195 100-134 53-273 88-414 106-36 4-71 9-107 10-17 1-35 3-53 4h-54c-70 1-137-1-206-2-136-4-273-9-411-20-138-13-278-29-418-68-69-19-140-44-207-83-68-37-133-91-179-161-24-34-41-73-54-111-13-39-21-78-26-117-9-79 1-163 28-238 27-76 70-143 120-201 50-57 106-106 166-149 59-42 121-79 185-112 32-16 64-31 97-45 34-14 65-27 103-39l-59 76c31-530 69-1058 121-1587 14-132 28-264 44-396 7-66 16-132 25-198l27-198c39-263 84-525 134-786 51-261 107-521 168-779 62-259 124-518 199-773 72-256 154-509 248-758 95-249 200-494 329-728 8-14 25-19 39-11 12 6 17 20 13 33-73 255-152 506-229 758l-115 377-56 190c-20 62-38 126-56 189-149 505-275 1017-374 1534-50 259-94 518-132 779-10 65-18 130-27 195s-18 131-25 196c-16 131-30 262-43 393-52 525-91 1052-121 1579-2 36-26 65-58 76h-1c-27 9-58 21-87 34-30 12-59 26-88 40-57 29-112 62-163 99-51 36-97 77-136 122s-70 94-89 147c-18 52-25 107-19 162 7 58 23 110 52 154 58 87 170 141 292 175 122 33 254 50 386 61s267 16 401 20c67 1 137 3 202 2h48l48-3c32-2 64-6 96-10 128-16 254-48 373-95 58-25 116-52 167-85 27-16 51-35 75-53 12-10 22-20 33-30 12-10 21-21 31-32 21-21 35-45 51-68l19-36c6-13 12-30 18-44 11-31 24-61 34-92l31-94c77-254 129-519 178-784 97-532 169-1071 288-1607 10-46 55-74 100-64 3 1 5 1 7 2h1c157 48 318 82 481 102 164 18 328 21 492 9 164-14 327-41 485-84l59-17 30-9 2-1c17 10 9 5 0 0-15-9-30-18 109 62l1 4 2 8 3 16 27 125c17 84 34 168 49 252 62 335 114 671 171 1004 58 333 118 666 214 983 13 39 25 79 39 118l22 57 11 28c3 9 7 20 11 27 28 62 76 118 134 165 58 48 127 87 199 119 72 33 148 60 226 79s158 34 238 41c81 8 158 9 245 7 168-3 337-8 502-22 83-7 165-16 245-30s158-33 230-61c71-27 135-64 178-115 44-49 68-112 76-184 3-35 3-69-3-103-6-33-17-66-32-98-31-63-79-122-137-172-57-52-123-96-193-134-35-20-71-37-107-54-36-16-76-32-110-43h-1c-34-12-56-42-58-76-30-527-69-1054-121-1579-50-525-128-1045-231-1562-103-516-226-1029-366-1536-18-64-35-127-54-190l-54-190c-19-63-38-126-56-189-18-64-39-126-58-189-76-253-157-503-238-755v-1c-5-15 3-30 18-35 13-5 28 2 34 14z"
  })), mpathy_our_mission_path23 || (mpathy_our_mission_path23 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil9",
    d: "M1851 10009c-5 0-10 0-15-1-46-9-76-53-68-99 48-256 102-514 161-766 10-45 56-74 101-63 46 10 74 56 63 101-58 250-111 505-159 759-7 41-43 69-83 69zM4674 11249c-249 0-497-33-738-100l-3 15c-9 46-54 75-100 66-45-10-75-55-65-100 7-36 15-72 23-106 5-23 20-43 41-55s46-14 68-7c251 79 511 118 774 118s524-39 775-118c23-7 47-4 68 7 20 12 35 32 40 55 9 38 17 77 26 117 9 45-20 90-66 100-45 9-90-20-100-66-2-8-3-17-5-26-241 67-488 100-738 100zM7502 10039c-40 0-75-28-83-69-51-281-112-569-180-856-11-45 17-90 63-101 45-11 91 17 102 63 68 289 129 580 181 863 9 46-22 90-68 99-5 1-10 1-15 1z"
  })), mpathy_our_mission_path24 || (mpathy_our_mission_path24 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil2",
    d: "M4587 6892v266s-1178 169-1808-998c-89-164-166-354-229-575l645 102s258 428 626 776c225 213 492 395 766 429z"
  })), mpathy_our_mission_path25 || (mpathy_our_mission_path25 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil4",
    d: "M4266 7095c-138-13-310-43-491-113-319-122-582-325-788-607 198 193 458 417 606 417h8c192-11-225-306-205-380 1-4 4-6 8-6 29 0 123 94 228 188s221 189 294 189c23 0 42-10 55-32 22-37-119-93-156-198 96 87 199 168 307 234-18 14-32 33-39 57-13 42-1 87 31 117l142 134z"
  })), mpathy_our_mission_path26 || (mpathy_our_mission_path26 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M2640 5664c210 667 591 1110 1135 1318 331 127 629 125 748 118v-154c-666-127-1261-1033-1367-1201l-516-81zm1786 1566c-158 0-412-22-691-127-420-160-978-549-1246-1500-5-21 0-43 14-60 14-16 36-24 57-20l645 101c18 3 35 14 44 30 7 11 665 1091 1345 1175 32 4 56 31 56 63v265c0 32-23 59-54 63-7 1-69 10-170 10z"
  })), mpathy_our_mission_path27 || (mpathy_our_mission_path27 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil2",
    d: "M5978 5687s-672 1116-1391 1205v265s1531 220 2036-1572l-645 102z"
  })), mpathy_our_mission_path28 || (mpathy_our_mission_path28 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M4650 7100c119 7 417 9 748-118 544-208 925-651 1135-1318l-516 81c-106 168-701 1074-1367 1201v154zm97 130c-101 0-163-9-169-10-32-4-55-31-55-63v-265c0-32 24-59 56-63 680-84 1338-1164 1345-1175 9-16 26-27 44-30l645-101c21-4 43 4 57 20 14 17 19 39 14 60-268 951-826 1340-1246 1500-279 105-533 127-691 127z"
  })), mpathy_our_mission_path29 || (mpathy_our_mission_path29 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil4",
    d: "M4906 7095v-2l145-147c32-31 42-77 28-119-6-18-17-33-30-46 103-63 202-140 295-223 1 0 2-1 3-1-39 102-177 157-155 194 13 22 32 32 55 32 73 0 189-95 294-189 49-44 96-88 135-123 32-10 64-20 95-31-50 101-372 342-199 352h8c148 0 409-224 606-417-205 282-469 485-788 607-182 70-354 101-492 113z"
  })), mpathy_our_mission_path30 || (mpathy_our_mission_path30 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "m4918 7158-12-63c138-12 310-43 492-113 319-122 583-325 788-607 86-84 160-163 208-215-419 776-1080 961-1476 998zm131-377c-17-16-40-27-65-30l-6-1c83-48 163-106 240-169 42-7 84-15 126-23-93 83-192 160-295 223z"
  })), mpathy_our_mission_path31 || (mpathy_our_mission_path31 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil10",
    d: "m4444 6763 91-193c19-38 73-39 93-1l97 190c8 15 23 25 40 27l211 27c43 6 61 58 30 88l-150 152c-12 12-17 29-14 46l40 209c8 42-36 75-75 56l-190-96c-15-8-33-8-48 1l-187 102c-38 21-83-11-76-53l32-211c3-17-3-34-15-46l-155-146c-31-29-15-82 27-89l210-34c17-3 32-13 39-29z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "m4896 6923-203-26c-17-2-32-13-40-28l-97-189c-1-1-1-2-1-2l25-54h5l84 164c17 33 50 56 88 61l188 24-49 50z",
    style: {
      fill: "#fff0b2",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "m4372 7304 29-187c6-38-7-76-35-102l-138-130 117-19 124 118c13 11 19 28 16 45l-33 211c-1 7 0 14 1 20l-81 44z",
    style: {
      fill: "#b98f18",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path32 || (mpathy_our_mission_path32 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "m4228 6885 138 130c28 26 41 64 35 102l-29 187 167-91c33-18 73-19 107-2l169 86-35-187c-7-37 5-75 31-102l134-135-188-24c-38-5-71-28-88-61l-87-169-81 171c-16 35-48 59-85 65l-188 30zm129 556c-23 0-46-7-66-21-36-26-54-68-48-112l32-205-151-142c-32-30-44-75-31-117 13-43 48-73 92-80l204-33 89-188c19-40 58-65 102-65 43-2 84 23 104 62l95 184 205 27c44 5 80 35 95 76 14 42 4 88-28 119l-145 147 38 203c8 44-9 87-44 114-35 26-82 30-121 11l-185-94-182 100c-17 9-36 14-55 14z"
  })), mpathy_our_mission_path33 || (mpathy_our_mission_path33 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M7870 4090c-37 3-68-25-71-61l-141-1889c-3-36 25-68 61-70 380-29 711 256 739 636l48 644c29 380-256 712-636 740z"
  })), mpathy_our_mission_path34 || (mpathy_our_mission_path34 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil9",
    d: "M7771 2083c-17 0-34 0-51 2-28 2-49 26-47 54l141 1889c2 28 27 49 55 47 371-28 650-352 622-723l-48-645c-26-354-323-624-672-624zm99 2007zm-5 15c-42 0-78-32-81-75l-141-1889c-3-44 30-83 75-86 387-29 726 262 755 650l49 644c29 388-263 727-651 756h-6z"
  })), mpathy_our_mission_path35 || (mpathy_our_mission_path35 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M7927 3998c22-115 37-231 45-347 4-37 7-74 10-111 184-45 337-163 430-320l10 137c23 311-194 586-495 641z"
  })), mpathy_our_mission_path36 || (mpathy_our_mission_path36 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "m7744 2153 138 1851c324-34 564-321 540-647l-48-644c-24-327-305-574-630-560zm126 1937zm-5 85c-78 0-144-61-150-139l-141-1890c-6-82 56-154 139-161 426-32 798 289 830 715l48 644c31 426-289 798-715 830-4 0-8 1-11 1z"
  })), mpathy_our_mission_path37 || (mpathy_our_mission_path37 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M1483 2535c37-2 68 25 71 61l141 1889c3 36-24 68-61 71-380 28-711-257-739-637l-48-644c-29-380 256-711 636-740z"
  })), mpathy_our_mission_path38 || (mpathy_our_mission_path38 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil9",
    d: "M1484 2551c-179 13-343 96-461 232-117 137-175 311-161 491l48 644c13 180 96 343 233 461 136 118 310 175 490 162 28-3 49-27 47-55l-141-1889c-2-28-26-48-55-46zm98 2022c-169 0-330-60-459-171-143-123-229-294-243-482l-48-644c-14-188 46-370 168-513 123-142 294-229 482-243 45-3 84 30 87 75l141 1889c3 45-30 83-75 87-18 1-35 2-53 2z"
  })), mpathy_our_mission_path39 || (mpathy_our_mission_path39 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M1574 4473c-142-2-277-53-386-147-123-105-197-252-209-413l-10-132c118 129 285 213 468 225 34 160 80 316 137 467z"
  })), mpathy_our_mission_path40 || (mpathy_our_mission_path40 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1471 2621c-154 17-294 90-395 207-106 123-157 279-145 441l48 644c12 161 86 308 209 413 118 102 267 153 421 147l-138-1852zm111 2021c-186 0-363-65-504-187-157-135-252-323-267-530l-49-644c-15-206 51-406 186-563s323-251 529-267c83-6 155 56 161 139l141 1889c6 83-56 155-138 161-20 1-40 2-59 2z"
  })), mpathy_our_mission_path41 || (mpathy_our_mission_path41 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M7905 3301c6 1783-1434 3233-3217 3240-1782 6-3233-1434-3239-3217C1442 1541 2883 91 4665 84c1783-6 3234 1434 3240 3217z"
  })), mpathy_our_mission_path42 || (mpathy_our_mission_path42 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil9",
    d: "M4677 100h-12c-858 3-1663 340-2268 949s-936 1417-933 2275c6 1768 1446 3202 3213 3202h11c1772-7 3208-1453 3202-3225-3-858-340-1664-949-2268-606-602-1410-933-2264-933zm0 6456c-1783 0-3237-1447-3243-3232-3-866 331-1682 941-2297C2986 413 3799 72 4665 69h12c862 0 1673 334 2285 942 615 610 955 1424 958 2290 7 1788-1443 3249-3231 3255h-12z"
  })), mpathy_our_mission_path43 || (mpathy_our_mission_path43 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M4677 6456c-729 0-1401-249-1936-668 491 248 1158 458 1873 458 34 0 67-1 101-2 795-22 1477-251 1968-512-542 450-1237 722-1995 724h-11z"
  })), mpathy_our_mission_path44 || (mpathy_our_mission_path44 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M4677 169h-11c-840 3-1628 333-2220 929-591 596-916 1386-913 2226 6 1729 1416 3132 3144 3132h11c1734-6 3139-1421 3133-3155-3-839-333-1628-929-2219-593-589-1379-913-2215-913zm0 6456c-1821 0-3306-1478-3313-3301-3-884 339-1717 962-2345C2950 351 3780 3 4665 0c884-3 1718 338 2346 962 628 623 975 1454 979 2339 6 1826-1475 3318-3301 3324h-12z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M7895 3384c12 632-182 1222-524 1714-256 368-1325 1025-2659 1062-1237 34-2375-605-2645-963-359-479-575-1062-587-1693-31-1671 1392-2391 3163-2424 1772-33 3221 633 3252 2304z",
    style: {
      fill: "#1a1a1a",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path45 || (mpathy_our_mission_path45 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M4757 1163c-39 0-76 0-112 1-939 18-3119 281-3081 2338 12 594 209 1162 571 1644 257 342 1369 963 2575 929 1337-37 2363-697 2592-1026 344-495 520-1070 509-1663-37-1980-2064-2223-3054-2223zm-143 5083c-1241 0-2338-632-2614-999-384-510-593-1112-605-1742-15-820 302-1458 943-1897 559-383 1355-595 2304-613 949-17 1752 164 2325 526 657 415 997 1041 1013 1861 11 630-175 1239-539 1764-253 364-1312 1059-2726 1098-34 1-67 2-101 2z"
  })), mpathy_our_mission_path46 || (mpathy_our_mission_path46 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil14",
    d: "M6806 3744c-16 0-33-1-49-4-226-36-368-318-317-630 47-289 243-501 451-501 16 0 32 1 49 4 182 29 310 219 326 455-22 140-52 278-89 413-87 160-226 263-371 263zM6343 4577c-19 0-39-3-58-9-119-37-180-179-138-317 36-116 134-193 235-193 19 0 39 3 58 9 119 36 180 178 138 317-36 116-134 193-235 193z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4616 6077c-346 0-683-53-992-135 1525-142 2717-892 3019-1327 239-344 421-726 534-1134 38-70 66-151 80-238 10-60 12-119 9-175 31-204 46-414 42-627-3-163-17-319-41-467 318 327 532 781 544 1412 11 593-165 1168-509 1663-229 329-1255 989-2592 1026-31 1-62 2-94 2z",
    style: {
      fill: "#000",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path47 || (mpathy_our_mission_path47 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M4615 6161c-436 0-858-81-1230-202 80-4 160-10 239-17 309 82 646 135 992 135 32 0 63-1 94-2 1337-37 2363-697 2592-1026 344-495 520-1070 509-1663-12-631-226-1085-544-1412-7-46-16-92-25-138 399 367 640 877 653 1548 12 632-182 1222-524 1714-256 368-1325 1025-2659 1062-32 1-64 1-97 1z"
  })), mpathy_our_mission_path48 || (mpathy_our_mission_path48 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil14",
    d: "M7177 3481c37-135 67-273 89-413 3 56 1 115-9 175-14 87-42 168-80 238z"
  })), mpathy_our_mission_path49 || (mpathy_our_mission_path49 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1695 2159c-18 0-36-6-52-18-36-28-43-79-17-116 551-842 1641-1340 2992-1365 1339-26 2445 414 3036 1206 29 30 32 76 5 110-28 37-82 43-119 14-1 0-2-1-3-2-5-4-9-9-13-15-558-751-1616-1168-2903-1144-1295 24-2335 494-2855 1291-1 2-3 5-5 7-17 21-41 32-66 32z"
  })), mpathy_our_mission_path50 || (mpathy_our_mission_path50 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil14",
    d: "M2219 4485s-549-1639 328-2313c664-510 1558-646 1941-646 122 0 192 14 185 34 0 0-1409 369-1942 1498-410 871-512 1427-512 1427z"
  })), mpathy_our_mission_path51 || (mpathy_our_mission_path51 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1512 12874c55-13 107-21 161-26 27-3 53-5 80-7s54-2 81-2c107-2 215 7 322 23 106 17 211 44 313 80 101 39 197 90 281 155 5 4 6 10 2 15-3 4-8 5-12 4l-1-1c-96-39-194-68-294-87-100-17-201-27-302-31-102-3-203 0-304 5-101 4-204 12-302 20h-3c-41 3-77-28-80-70-3-37 22-70 58-78zM7789 13022c-98-8-201-16-302-20-101-5-202-8-304-5-101 4-202 14-302 31-100 19-198 48-294 87l-1 1c-5 2-12-1-14-6s0-10 3-13c85-65 181-116 282-155 101-36 207-63 313-80 107-16 215-25 322-23 27 0 54 0 81 2 26 2 53 4 80 7 54 5 106 13 161 26 41 9 66 50 56 90-8 37-42 61-78 58h-3z"
  })), mpathy_our_mission_path52 || (mpathy_our_mission_path52 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil2",
    d: "M7502 9955c-340 303-1117 930-2002 1203-265 82-540 132-816 132-279 0-561-54-833-143-852-277-1621-888-2000-1222 48-257 102-512 160-763 904 103 3258 279 5310-67 67 282 128 569 181 860z"
  })), mpathy_our_mission_path53 || (mpathy_our_mission_path53 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil4",
    d: "M4684 11206c-253 0-524-47-807-140-809-262-1546-834-1934-1173 6-32 12-64 19-96 461 281 1103 613 1793 790 304 78 618 125 930 125 307 0 614-44 910-116 705-171 1348-501 1797-772l18 99c-381 335-1109 899-1935 1154-276 85-542 129-791 129z"
  })), mpathy_our_mission_path54 || (mpathy_our_mission_path54 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M1943 9893c388 339 1125 911 1934 1173 283 93 554 140 807 140 249 0 515-44 791-129 826-255 1554-819 1935-1154-45-241-96-487-153-732-2158 350-4551 132-5181 63-48 211-92 426-133 639zm2741 1482c-270 0-560-50-860-148-863-280-1642-896-2029-1239-22-19-32-49-27-79 48-256 102-514 161-766 9-42 49-70 92-65 487 56 3032 314 5286-66 44-8 86 20 97 64 68 289 129 580 181 863 6 29-5 59-27 79-380 339-1150 948-2033 1221-292 90-575 136-841 136z"
  })), mpathy_our_mission_path55 || (mpathy_our_mission_path55 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M3348 9172c-350 142-892 112-1261 67-221-27-376-231-344-451 30-202 207-348 410-339 346 17 863 24 1191-49l4 772z"
  })), mpathy_our_mission_path56 || (mpathy_our_mission_path56 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M2656 9192c-195 0-391-16-559-37-84-10-158-53-210-120-51-67-73-151-60-235 3-20 7-39 14-57 61 69 147 117 246 129 165 20 365 37 566 37 63 0 126-2 189-6h-1c66 94 135 181 205 262-123 19-256 27-390 27z"
  })), mpathy_our_mission_path57 || (mpathy_our_mission_path57 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M2134 8533c-154 0-284 113-307 267-13 84 9 168 60 235 52 67 126 110 210 120 375 46 890 72 1219-61 85-35 105-172 110-230 16-183-42-345-75-378-332 70-835 65-1202 48-5 0-10-1-15-1zm518 828c-202 0-403-17-575-38-130-16-245-81-324-185s-113-233-93-363c36-245 249-422 497-410 361 17 856 22 1169-47 47-10 163-10 232 214 72 231 65 620-179 718-204 83-466 111-727 111z"
  })), mpathy_our_mission_path58 || (mpathy_our_mission_path58 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "M6024 9172c349 142 891 112 1260 67 221-27 377-231 344-451-30-202-207-348-410-339-345 17-863 24-1191-49l-3 772z"
  })), mpathy_our_mission_path59 || (mpathy_our_mission_path59 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil7",
    d: "M6715 9192c-140 0-281-9-409-31 67-78 133-162 197-252l-12-12c75 6 151 8 227 8 201 0 401-17 566-37 99-12 184-59 246-127 7 19 11 38 14 59 13 84-9 168-60 235-52 67-126 110-210 120-168 21-364 37-559 37z"
  })), mpathy_our_mission_path60 || (mpathy_our_mission_path60 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M6021 8486c-34 33-92 195-76 378 5 58 25 195 110 230 329 133 844 107 1219 61 84-10 158-53 210-120 51-67 73-151 60-235-23-159-162-274-322-266-366 17-870 22-1201-48zm698 875c-261 0-523-28-727-111-244-98-251-487-179-718 69-224 185-224 232-214 313 69 809 64 1169 47 248-12 461 165 498 410 19 130-14 259-94 363-79 104-194 169-324 185-172 21-373 38-575 38z"
  })), mpathy_our_mission_path61 || (mpathy_our_mission_path61 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil10",
    d: "M5833 8216H3531l-670 693c726 1033 1821 1270 1821 1270s1095-237 1821-1270l-670-693z"
  })), mpathy_our_mission_path62 || (mpathy_our_mission_path62 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil2",
    d: "M5302 8614H4023l-373 272c403 574 1012 705 1012 705s609-131 1012-705l-372-272z"
  })), mpathy_our_mission_path63 || (mpathy_our_mission_path63 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil6",
    d: "m5878 8263-45-47h2z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    style: {
      fill: "#ffeb99",
      fillRule: "nonzero"
    },
    d: "M6031 8427H3337l196-211h2300l45 47z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4557 10144c-232-70-814-284-1339-798 5 0 10 0 14 1 513 503 1080 721 1325 797z",
    style: {
      fill: "#ca2334",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path64 || (mpathy_our_mission_path64 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil18",
    d: "M3232 9347c-4-1-9-1-14-1l-36-36c4 0 8-1 11-2l39 39z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "m2842 8903 261-270c4 5 7 10 11 15l-245 253c-9 1-18 2-27 2z",
    style: {
      fill: "#cfd3e4",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M3046 9165c-70-81-139-168-205-262h1c9 0 18-1 27-2l-8 8c64 91 130 175 198 254-4 0-8 1-13 2z",
    style: {
      fill: "#9793b0",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path65 || (mpathy_our_mission_path65 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil18",
    d: "M3182 9310c-46-46-91-94-136-145 5-1 9-2 13-2 44 50 89 99 134 145-3 1-7 2-11 2z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4662 10172s-38-8-105-28c-245-76-812-294-1325-797l-39-39c-45-46-90-95-134-145-68-79-134-163-198-254l8-8 245-253c655 839 1548 1048 1548 1048s1040-293 1559-1063l262 270c-726 1033-1821 1269-1821 1269z",
    style: {
      fill: "#cfac18",
      fillRule: "nonzero"
    }
  }), mpathy_our_mission_path66 || (mpathy_our_mission_path66 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-mission_svg__fil5",
    d: "M2971 8917c646 876 1571 1139 1711 1175 139-36 1065-299 1711-1175l-596-617H3567l-596 617zm1711 1346c-6 0-12-1-18-2-46-10-1136-255-1872-1303-23-33-20-78 9-107l670-694c15-16 37-26 60-26h2302c23 0 45 10 60 26l670 694c29 29 32 74 9 107-736 1048-1826 1293-1872 1303-6 1-12 2-18 2zM7146 8157c42-24 81-45 122-65s82-40 123-58c83-36 168-68 255-88-78 44-148 97-216 152-33 29-66 57-98 87-32 29-64 60-93 90s-77 31-108 2c-30-29-31-77-2-107 5-5 11-10 17-13zM3708 11994c-14 0-27-4-39-13-834-637-2006-536-2018-535-35 3-66-22-69-57s22-66 57-69c50-5 1232-107 2107 560 28 21 33 61 12 89-13 16-31 25-50 25zM5649 11994c-19 0-38-9-51-25-21-28-15-68 12-89 875-667 2057-565 2107-560 35 3 61 34 57 69-3 35-34 60-69 57-11-1-1183-102-2018 535-11 9-25 13-38 13z"
  })))));
};
/* harmony default export */ const mpathy_our_mission = (SvgMpathyOurMission);
;// CONCATENATED MODULE: ./src/components/svgs/mpathy-our-crew.svg
var mpathy_our_crew_defs, mpathy_our_crew_path, mpathy_our_crew_path2, mpathy_our_crew_path3, mpathy_our_crew_path4, mpathy_our_crew_path5, mpathy_our_crew_path6, mpathy_our_crew_path7, mpathy_our_crew_path8, mpathy_our_crew_path9, mpathy_our_crew_path10, mpathy_our_crew_path11, mpathy_our_crew_path12, mpathy_our_crew_path13, mpathy_our_crew_path14, mpathy_our_crew_path15, mpathy_our_crew_path16, mpathy_our_crew_path17, mpathy_our_crew_path18, mpathy_our_crew_path19, mpathy_our_crew_path20, mpathy_our_crew_path21, mpathy_our_crew_path22, mpathy_our_crew_path23, mpathy_our_crew_path24, mpathy_our_crew_path25, mpathy_our_crew_path26, mpathy_our_crew_path27, mpathy_our_crew_path28, mpathy_our_crew_path29, mpathy_our_crew_path30, mpathy_our_crew_path31, mpathy_our_crew_path32, mpathy_our_crew_path33, mpathy_our_crew_path34, mpathy_our_crew_path35, mpathy_our_crew_path36, mpathy_our_crew_path37, mpathy_our_crew_path38, mpathy_our_crew_path39, mpathy_our_crew_path40, mpathy_our_crew_path41, mpathy_our_crew_path42, mpathy_our_crew_path43, mpathy_our_crew_path44, mpathy_our_crew_path45, mpathy_our_crew_path46, mpathy_our_crew_path47, mpathy_our_crew_path48, mpathy_our_crew_path49, mpathy_our_crew_path50, mpathy_our_crew_path51, mpathy_our_crew_path52, mpathy_our_crew_path53, mpathy_our_crew_path54, mpathy_our_crew_path55, mpathy_our_crew_path56, mpathy_our_crew_path57, mpathy_our_crew_path58, mpathy_our_crew_path59, mpathy_our_crew_path60, mpathy_our_crew_path61, mpathy_our_crew_path62, mpathy_our_crew_path63, mpathy_our_crew_path64, mpathy_our_crew_path65, mpathy_our_crew_path66, mpathy_our_crew_path67, mpathy_our_crew_path68, mpathy_our_crew_path69, _path70, _path71, _path72, _path73, _path74, _path75, _path76, _path77, _path78, _path79, _path80, _path81, _path82, _path83, _path84, _path85, _path86, _path87;
function mpathy_our_crew_extends() { mpathy_our_crew_extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return mpathy_our_crew_extends.apply(this, arguments); }

var SvgMpathyOurCrew = function SvgMpathyOurCrew(props) {
  return /*#__PURE__*/external_react_.createElement("svg", mpathy_our_crew_extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlSpace: "preserve",
    width: "131.7mm",
    height: 587.943,
    style: {
      shapeRendering: "geometricPrecision",
      textRendering: "geometricPrecision",
      imageRendering: "optimizeQuality",
      fillRule: "evenodd",
      clipRule: "evenodd"
    },
    viewBox: "0 0 6005 6655"
  }, props), mpathy_our_crew_defs || (mpathy_our_crew_defs = /*#__PURE__*/external_react_.createElement("defs", null, /*#__PURE__*/external_react_.createElement("style", null, ".mpathy-our-crew_svg__fil2{fill:#000;fill-rule:nonzero}.mpathy-our-crew_svg__fil4,.mpathy-our-crew_svg__fil6,.mpathy-our-crew_svg__fil9{fill:#371a45;fill-rule:nonzero}.mpathy-our-crew_svg__fil6,.mpathy-our-crew_svg__fil9{fill:#845ebe}.mpathy-our-crew_svg__fil6{fill:#999}.mpathy-our-crew_svg__fil1,.mpathy-our-crew_svg__fil17,.mpathy-our-crew_svg__fil3{fill:#b9afbe;fill-rule:nonzero}.mpathy-our-crew_svg__fil1,.mpathy-our-crew_svg__fil17{fill:#fdf2f2}.mpathy-our-crew_svg__fil1{fill:#fff}"))), /*#__PURE__*/external_react_.createElement("g", {
    id: "mpathy-our-crew_svg__Layer_x0020_1"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M2466 6655c1256 0 2275-122 2275-272 0-92-382-173-966-222-5 17-11 33-18 49-17 33-41 62-70 84-28 23-60 39-92 51-64 24-130 33-194 37-23 1-45 2-67 2-42 0-84-2-126-6-32-2-64-5-95-9l-94-13c-62-8-126-19-189-35-31-9-63-19-94-33-31-13-61-30-89-53-14-11-27-24-39-39-11-14-21-32-28-48-5-12-10-24-14-36h-244c-4 12-9 24-14 36-7 16-17 34-28 48-12 15-25 28-39 39-28 23-58 40-89 53-31 14-63 24-94 33-63 16-127 27-189 35l-94 13c-31 4-63 7-95 9-42 4-84 6-126 6-22 0-44-1-67-2-64-4-130-13-194-37-32-12-64-28-92-51-29-22-53-51-70-84-7-15-12-30-17-45-560 49-923 129-923 218 0 150 1019 272 2275 272z",
    style: {
      fill: "#000",
      fillRule: "nonzero",
      fillOpacity: 0.14902
    }
  }), mpathy_our_crew_path || (mpathy_our_crew_path = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3647 2858v1529c0 88-23 171-63 242-86 151-248 254-433 254H1727c-178 0-335-95-422-237-47-76-73-164-73-259V2858c0-34 3-66 10-98 17-88 58-167 116-232 91-101 223-166 369-166h1424c213 0 396 136 466 325 19 53 30 111 30 171z"
  })), mpathy_our_crew_path2 || (mpathy_our_crew_path2 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3151 2399c253 0 459 206 459 459v1529c0 253-206 459-459 459H1727c-253 0-458-206-458-459V2858c0-253 205-459 458-459h1424zM1727 4920h1424c294 0 533-239 533-533V2858c0-294-239-533-533-533H1727c-293 0-532 239-532 533v1529c0 294 239 533 532 533z"
  })), mpathy_our_crew_path3 || (mpathy_our_crew_path3 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3329 2507s617 701 617 1287c0 501-617 674-617 674l-855-1448 855-513z"
  })), mpathy_our_crew_path4 || (mpathy_our_crew_path4 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3946 3794c0 502-617 674-617 674l-21-36-834-1412 645-387 210-126s617 701 617 1287z"
  })), mpathy_our_crew_path5 || (mpathy_our_crew_path5 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M3614 4142c13-22 24-46 34-70-9 2-19 4-29 5-3 0-6 1-9 1 2 21 3 43 4 64zm53-472c-32-163-99-327-178-478 21 97 39 194 54 292 9 58 17 116 24 174 6 0 12 0 17-1h11c25 0 50 5 72 13z"
  })), mpathy_our_crew_path6 || (mpathy_our_crew_path6 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3321 2555c105 126 588 733 588 1239 0 410-448 590-563 630l-821-1391 796-478zm-9 1956 27-7c7-2 162-46 319-154 213-146 325-338 325-556 0-593-601-1282-626-1311l-21-24-912 548 888 1504z"
  })), mpathy_our_crew_path7 || (mpathy_our_crew_path7 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M1491 3357s-261 327-680 255c-434-75-357-797-357-797l660-254s-41 226 54 226c107-1 298-252 465-328l-142 898z"
  })), mpathy_our_crew_path8 || (mpathy_our_crew_path8 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M930 3585c187 0 334-81 426-152l4-25c6-31 12-63 18-94 12-62 26-125 40-187l3-12c-104 159-263 331-468 331-21 0-42-2-64-6-310-53-336-425-132-462-17 1-33 2-49 2-55 0-101-8-128-14-35-9-66-21-94-36-1 197 35 595 332 646 39 6 76 9 112 9z"
  })), mpathy_our_crew_path9 || (mpathy_our_crew_path9 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M933 3660c359 0 577-267 587-280 13-16 10-39-6-52s-39-10-52 6c-2 3-253 309-644 242-354-61-337-616-329-735l580-223c-4 56-2 133 33 174 17 21 40 32 66 32 71-1 155-74 251-160 77-68 157-138 229-171 19-8 27-30 19-49-9-19-31-27-49-18-83 37-167 111-248 183-74 66-159 141-202 141-4 0-7-2-9-5-23-27-19-122-9-178l12-64-742 285-3 23c-3 31-75 758 388 838 45 7 87 11 128 11z"
  })), mpathy_our_crew_path10 || (mpathy_our_crew_path10 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3746 6111c0 6-1 12-2 18-32 186-249 252-641 201-177-23-422-50-487-192-129-281 3-852-12-1217v-1s-72 9-160 9-160-9-160-9v9c-13 366 116 930-12 1209-65 142-310 169-487 192-392 51-610-15-641-201l-3-18c-22-227 294-333 294-333s-69-481-114-916c-19-183-24-372-18-560 2-48 4-97 7-145 4-69 9-138 15-206 6-59 12-117 19-174 26-216 60-420 96-600 32-161 65-302 93-414 6-25 12-48 18-70 34-133 58-210 58-210h1670s24 78 58 211c21 78 44 175 69 287 10 43 20 89 30 137 40 194 79 420 108 660 7 57 13 113 18 171 7 70 12 141 16 213 3 51 5 101 7 152 1 34 2 68 2 102 1 150-5 300-20 446-45 435-114 916-114 916s316 106 293 333z"
  })), mpathy_our_crew_path11 || (mpathy_our_crew_path11 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1554 6310c40 0 80-2 120-5 31-3 61-6 92-10l93-12c61-9 122-18 180-34 57-16 113-37 155-71 10-8 19-17 27-27l6-8 5-8c1-2 2-5 4-8l2-4 2-5c12-26 20-54 27-83 14-57 20-118 23-179s2-123 0-184c-5-124-17-248-27-374-9-114-19-229-17-347-29-6-56-14-84-23-37-13-73-28-108-46-18-9-35-19-52-29-16-10-33-20-48-32-32-24-61-51-86-81 0 0 15 340 210 601s175 471 49 680c-62 105-321 173-583 173-126 0-253-16-359-51 3 12 8 23 13 34 23 46 67 79 121 99 53 20 113 28 173 32 20 1 41 2 62 2zM3334 6310c21 0 42-1 62-2 60-4 120-12 173-32 54-20 98-53 121-99 6-12 11-25 14-38-106 24-225 36-342 36-270 0-528-61-588-161-125-209-112-424 71-694 227-335 174-580 174-580-25 30-54 57-86 81-15 12-32 22-48 32-17 10-34 20-52 29-35 18-71 33-108 46-28 9-55 17-84 23 3 118-7 233-16 347-10 126-22 250-27 374-2 61-3 123 0 184s9 122 23 179c7 29 15 57 27 83l2 5 2 4c2 3 3 6 4 8l5 8 6 8c8 10 17 19 27 27 41 34 98 55 155 71 58 16 119 25 180 34l93 12c31 4 61 7 92 10 40 3 80 5 120 5z"
  })), mpathy_our_crew_path12 || (mpathy_our_crew_path12 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M1521 2760c-40 121-73 244-103 367-14 62-28 125-40 187-6 31-12 63-18 94l-16 94c-5 32-10 63-15 95l-14 94c-4 32-8 63-12 95s-7 63-10 95c-14 127-21 254-27 382-3 128-5 256 2 383l3 48 1 24 2 24 8 96c5 64 13 127 20 190 29 252 61 504 97 755l25-40c-17 6-32 12-47 19s-30 14-45 22c-29 15-57 33-84 53s-52 43-74 70c-23 26-42 57-55 91-12 34-17 71-15 107s11 72 27 105c17 33 41 62 70 84 28 23 60 39 92 51 64 24 130 33 194 37 65 3 130 1 193-4 32-2 64-5 95-9l94-13c62-8 126-19 189-35 31-9 63-19 94-33 31-13 61-30 89-53 14-11 27-24 39-39 11-14 21-32 28-48 14-31 23-63 31-96 16-64 22-128 25-192 3-65 2-128 0-191-6-127-17-252-28-377-10-124-19-248-15-370l-41 35c28 3 55 5 82 7 27 1 55 2 82 2s55-1 82-2c27-2 54-4 82-7l-41-35c4 122-6 246-15 370-11 125-22 250-28 377-2 63-3 126 0 191 3 64 9 128 25 192 8 33 17 65 31 96 7 16 17 34 28 48 12 15 25 28 39 39 28 23 58 40 89 53 31 14 63 24 94 33 63 16 127 27 189 35l94 13c31 4 63 7 95 9 63 5 128 7 193 4 64-4 130-13 194-37 32-12 64-28 92-51 29-22 53-51 70-84 16-33 25-69 27-105s-3-73-15-107c-13-34-32-65-55-91-22-27-47-50-74-70s-55-38-84-53c-15-8-30-15-45-22s-30-13-47-19l25 40c36-253 69-507 98-761 7-64 14-127 20-191 3-33 6-65 8-97l5-97c5-128 5-257 0-386s-16-257-29-385c-3-32-7-63-10-95l-12-96c-8-64-16-127-26-191-20-127-44-253-74-379-7-31-16-62-24-93-9-31-18-61-28-92-20-61-41-122-68-181-3-7-10-9-16-7-5 3-8 9-7 14 26 125 49 250 74 375 22 124 44 250 65 376 42 250 71 503 81 757 5 127 5 254 0 380-5 127-18 252-33 380-29 253-62 506-97 759l-4 30 29 10c12 5 27 11 40 17 14 6 27 12 40 19 26 14 51 30 74 47 47 35 86 78 104 127 9 25 13 51 11 78-2 26-8 53-20 76-23 46-67 79-121 99-53 20-113 28-173 32-60 3-121 1-182-3-31-3-61-6-92-10l-93-12c-61-9-122-18-180-34-57-16-114-37-155-71-10-8-19-17-27-27l-6-8-5-8c-1-2-2-5-4-8l-2-4-2-5c-12-26-20-54-27-83-14-57-20-118-23-179s-2-123 0-184c5-124 17-248 27-374 10-125 20-251 16-379l-2-40-40 5c-25 2-51 4-77 6-26 1-52 2-78 2s-52-1-78-2c-26-2-52-4-77-6l-40-5-2 40c-4 128 6 254 16 379 10 126 22 250 27 374 2 61 3 123 0 184s-9 122-23 179c-7 29-15 57-27 83l-2 5-2 4c-2 3-3 6-4 8l-5 8-6 8c-8 10-17 19-27 27-42 34-98 55-155 71-58 16-119 25-180 34l-93 12c-31 4-61 7-92 10-61 4-122 6-182 3-60-4-120-12-173-32-54-20-98-53-121-99-12-23-18-50-20-76-2-27 2-53 11-78 18-49 57-92 104-127 23-17 48-33 74-47 13-7 26-13 40-19 13-6 28-12 40-17l29-10-4-30c-35-251-68-502-97-754-6-62-14-125-20-188l-7-94-2-23-1-24-2-47c-6-125-4-251 0-377 12-252 39-502 76-752 38-250 83-498 126-748 1-7-3-13-10-15-6-1-12 3-14 9z"
  })), mpathy_our_crew_path13 || (mpathy_our_crew_path13 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3127 5504c303 0 407-132 414-140 12-17 9-40-8-52-16-12-39-9-51 7-4 4-202 240-876 9-20-6-40 4-47 23-7 20 4 41 23 47 229 79 407 106 545 106zM1731 5521c271 0 562-96 581-102s29-27 23-47c-7-19-28-29-47-23-6 2-656 216-881 8-15-14-38-13-52 2s-13 38 2 52c90 83 229 110 374 110z"
  })), mpathy_our_crew_path14 || (mpathy_our_crew_path14 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3838 2060c-16-3-27-17-24-33l111-815c3-15 17-26 33-24 164 22 278 174 256 338l-38 277c-23 164-174 279-338 257z"
  })), mpathy_our_crew_path15 || (mpathy_our_crew_path15 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil4",
    d: "M3954 1194h3c77 11 146 51 193 114 48 62 68 139 57 217l-38 278c-11 77-51 146-113 193-63 47-140 68-217 57-12-2-21-13-19-25l112-815c1-6 4-11 9-14 3-3 8-5 13-5zm-75 875c67 0 131-21 185-62 65-50 107-122 118-203l38-278c11-81-10-161-59-226-50-65-121-107-202-119-10-1-19 1-27 7-7 6-12 14-13 23l-112 815c-3 20 11 37 30 40 14 2 28 3 42 3z"
  })), mpathy_our_crew_path16 || (mpathy_our_crew_path16 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M3879 2025c57 0 112-18 158-53 56-42 92-104 102-174l8-58c-54 58-129 94-211 96-5 17-10 33-15 49-14 48-31 95-50 140h8z"
  })), mpathy_our_crew_path17 || (mpathy_our_crew_path17 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3961 1226c66 11 124 46 165 100 43 56 61 125 51 195l-38 277c-10 70-46 132-102 174-53 41-119 59-186 52l110-798zm-82 873c73 0 144-23 203-68 72-54 118-133 130-222l38-278c13-90-11-178-65-250-54-71-133-118-222-130-18-2-35 2-49 13s-23 26-25 43l-112 815c-5 36 20 69 56 74 15 2 31 3 46 3z"
  })), mpathy_our_crew_path18 || (mpathy_our_crew_path18 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M1267 819c16 2 27 16 25 32l-112 815c-2 15-17 26-32 24-164-22-279-174-256-337l38-278c22-164 173-279 337-256z"
  })), mpathy_our_crew_path19 || (mpathy_our_crew_path19 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil4",
    d: "M1266 825c12 2 21 13 19 25l-112 815c0 6-3 11-8 14-5 4-11 5-16 5-78-11-147-51-194-114-47-62-67-139-57-217l38-278c11-77 51-146 114-193 62-47 139-68 216-57zm-114 872c7 0 15-2 21-7 7-6 12-14 13-23l112-815c3-20-10-37-30-40-81-11-161 10-226 59-66 50-108 122-119 203l-38 278c-11 81 10 161 59 226 50 66 122 108 203 119h5z"
  })), mpathy_our_crew_path20 || (mpathy_our_crew_path20 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1129 1649c-10-69-15-139-15-210-77-22-140-73-178-138l-8 57c-9 69 9 138 51 194 38 50 90 83 150 97z"
  })), mpathy_our_crew_path21 || (mpathy_our_crew_path21 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "m1254 854-110 798c-66-11-124-46-165-100-42-56-60-125-51-194l38-278c10-70 46-132 102-174 54-41 119-59 186-52zm-102 873c32 0 60-23 65-56l111-815c5-36-20-69-56-74-89-12-177 11-249 65-71 54-118 133-130 223l-38 277c-12 90 11 178 65 250 55 71 134 118 223 130h9z"
  })), mpathy_our_crew_path22 || (mpathy_our_crew_path22 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M3559 2744c10-9 19-18 29-28-22-67-59-127-107-177-15 13-31 25-47 37 35 44 78 101 125 168zm-2160-161c49-42 98-84 147-117-7-6-14-13-20-20-56 27-106 66-146 112 7 9 13 17 19 25z"
  })), mpathy_our_crew_path23 || (mpathy_our_crew_path23 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "m3588 2716 29-29c-24-65-61-123-108-172-10 8-19 16-28 24 48 50 85 110 107 177zm-2208-158c40-46 90-85 146-112-9-9-18-18-27-28-53 28-101 66-141 110 7 10 15 20 22 30z"
  })), mpathy_our_crew_path24 || (mpathy_our_crew_path24 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M3401 2873c35-25 69-51 102-79-49-70-94-129-129-173-11 8-23 16-35 23-4 3-8 6-13 8 4 14 8 27 11 42 4 14 7 28 11 43 1 0 1 1 1 2 20 43 37 88 52 134z"
  })), mpathy_our_crew_path25 || (mpathy_our_crew_path25 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3503 2794c12-10 25-21 37-32 6-6 13-12 19-18-47-67-90-124-125-168-19 16-39 30-60 45 35 44 80 103 129 173z"
  })), mpathy_our_crew_path26 || (mpathy_our_crew_path26 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1540 2737c3-15 7-30 11-44 20-79 37-137 47-173-49 32-101 75-151 120 29 34 60 66 93 97z"
  })), mpathy_our_crew_path27 || (mpathy_our_crew_path27 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M1447 2640c50-45 102-88 151-120 1-1 1-2 1-4-18-16-36-33-53-50-49 33-98 75-147 117 8 10 16 19 24 29 7 9 15 19 24 28z"
  })), mpathy_our_crew_path28 || (mpathy_our_crew_path28 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M2553 3143c8 0 16 0 23-1 283-4 553-90 781-239-10-53-20-105-31-157-1-5 2-11 7-14 2 0 3-1 5-1 4 0 8 2 10 6-4-15-7-29-11-43-3-15-7-28-11-42-233 149-499 226-770 226-100 0-200-10-300-31-253-53-476-170-657-331 0 2 0 3-1 4-10 36-27 94-47 173-4 14-8 29-11 44 14 14 28 27 43 40 184 162 411 280 667 334 102 21 203 32 303 32z"
  })), mpathy_our_crew_path29 || (mpathy_our_crew_path29 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3357 2903c9-6 18-12 27-19 6-3 12-7 17-11-15-46-32-91-52-134 0-1 0-2-1-2-2-4-6-6-10-6-2 0-3 1-5 1-5 3-8 9-7 14 11 52 21 104 31 157z"
  })), mpathy_our_crew_path30 || (mpathy_our_crew_path30 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3925 1728c-160 757-903 1242-1661 1083-758-160-1243-903-1083-1661C1340 393 2084-92 2842 67c757 160 1242 903 1083 1661z"
  })), mpathy_our_crew_path31 || (mpathy_our_crew_path31 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil4",
    d: "M2552 44c95 0 192 9 288 30 365 76 678 291 881 603 204 312 274 685 197 1049-77 365-291 678-603 882-312 203-685 273-1050 196-752-158-1236-899-1078-1652C1326 495 1907 44 2552 44zm4 2804c270 0 535-78 766-229 315-206 532-522 609-890 78-368 7-744-198-1059-206-316-522-532-890-609-760-160-1509 328-1669 1088s329 1508 1089 1668c97 21 195 31 293 31z"
  })), mpathy_our_crew_path32 || (mpathy_our_crew_path32 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M2556 2804c218 0 433-52 629-155-147 42-326 72-524 72-114 0-235-10-359-33-320-60-600-215-794-372 189 227 453 393 764 459 94 20 189 29 284 29z"
  })), mpathy_our_crew_path33 || (mpathy_our_crew_path33 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2552 74c93 0 188 10 282 29 357 76 663 285 862 590 199 306 268 670 192 1027-75 357-284 663-590 862-305 199-670 268-1026 193-737-155-1210-881-1055-1617C1352 516 1921 74 2552 74zm4 2804c276 0 546-79 783-234 322-210 543-532 622-909 79-376 7-760-203-1082s-533-543-909-622c-776-163-1541 335-1704 1112-164 776 335 1541 1111 1704 100 21 200 31 300 31z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M3913 1762c-53 269-189 502-378 680-143 133-656 315-1226 209-529-98-954-472-1036-649-109-236-148-503-95-773 139-712 808-888 1564-741 755 147 1310 562 1171 1274z",
    style: {
      fill: "#1a1a1a",
      fillRule: "nonzero"
    }
  }), mpathy_our_crew_path34 || (mpathy_our_crew_path34 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3877 1755c-50 253-177 481-368 660-127 119-622 306-1193 200-516-96-931-460-1009-629-110-237-142-497-93-749 63-324 241-548 529-667 258-106 601-122 992-46 390 76 702 220 902 415 222 218 303 492 240 816zm-1216 966c441 0 787-147 899-252 202-189 337-432 389-700 68-350-19-647-261-883-210-205-535-356-939-435-405-78-762-61-1034 51-313 128-505 371-573 720-53 269-19 544 98 795 86 186 514 569 1062 671 124 23 245 33 359 33z"
  })), mpathy_our_crew_path35 || (mpathy_our_crew_path35 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil6",
    d: "M3446 1819c54 0 109-30 153-81 28-54 53-110 75-167 15-102-22-194-97-223-15-7-32-10-49-10-81 0-167 70-208 175-50 128-15 261 77 297 16 6 32 9 49 9zM3164 2129c37 0 76-23 98-62 31-55 18-121-29-147-13-8-28-11-43-11-37 0-76 23-98 62-31 55-18 121 30 147 13 8 27 11 42 11z"
  })), mpathy_our_crew_path36 || (mpathy_our_crew_path36 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2658 2646c418 0 751-137 851-231 191-179 318-407 368-660 47-244 13-461-103-646-3 64-11 131-25 199-17 91-43 179-75 263-3 24-10 49-19 73-14 36-33 68-56 94-85 163-197 309-330 433-143 134-580 306-1114 306-93 0-190-6-288-17 135 68 287 125 449 155 118 22 233 31 342 31z"
  })), mpathy_our_crew_path37 || (mpathy_our_crew_path37 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2657 2683c421 0 765-136 878-241 189-178 325-411 378-680 56-286-1-524-137-716 0 21 0 42-2 63 116 185 150 402 103 646-50 253-177 481-368 660-100 94-433 231-851 231-109 0-224-9-342-31-162-30-314-87-449-155-34-4-69-9-104-15 158 92 345 169 546 206 119 22 236 32 348 32z"
  })), mpathy_our_crew_path38 || (mpathy_our_crew_path38 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil6",
    d: "M3599 1738c23-26 42-58 56-94 9-24 16-49 19-73-22 57-47 113-75 167z"
  })), mpathy_our_crew_path39 || (mpathy_our_crew_path39 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3917 1151c8 0 17-2 24-8 13-12 17-31 9-46-179-391-609-679-1181-790-576-112-1085 0-1396 309l26 26 24 29-24-29 24 29 2-3c294-291 778-396 1330-289 549 107 960 381 1128 750l2 4 3 5c8 9 18 13 29 13z"
  })), mpathy_our_crew_path40 || (mpathy_our_crew_path40 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil6",
    d: "M1402 1713s94-227 348-559c329-431 961-460 961-460 10-17-144-57-356-57-181 0-404 29-603 124-433 206-350 952-350 952z"
  })), mpathy_our_crew_path41 || (mpathy_our_crew_path41 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "m2291 4884-53-14c-17-4-35-9-53-14-35-11-70-22-105-34s-69-27-105-40c-35-14-69-29-107-42 25 30 54 57 86 81 15 12 32 22 48 32 17 10 34 20 52 29 35 18 71 33 108 46 38 12 75 23 116 29 20 3 39-11 42-32 3-18-9-36-27-41h-2zM2609 4957c41-6 78-17 116-29 37-13 73-28 108-46 18-9 35-19 52-29 16-10 33-20 48-32 32-24 61-51 86-81-38 13-72 28-107 42-35 13-70 28-105 40s-70 23-105 34c-18 5-36 10-53 14l-52 14h-2c-20 5-32 26-27 45s23 30 41 28z"
  })), mpathy_our_crew_path42 || (mpathy_our_crew_path42 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil4",
    d: "M1442 5815c22-3 45-5 68-7s47-4 70-5c46-3 93-3 139-1 47 2 93 8 139 16 46 9 90 21 137 37-35-35-79-61-125-80-46-18-95-30-144-38-49-7-99-10-148-10-25 1-50 2-75 4s-48 6-74 11c-20 4-33 23-29 44 4 18 22 31 40 29h2z"
  })), mpathy_our_crew_path43 || (mpathy_our_crew_path43 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3459 5742c-26-5-49-9-74-11s-50-3-75-4c-49 0-99 3-148 10-49 8-98 20-144 38-46 19-90 45-125 80 47-16 92-28 137-37 47-8 92-14 139-16 46-2 93-2 139 1 23 1 47 3 70 5s46 4 68 7h1c21 2 39-12 42-32 2-20-11-37-30-41z"
  })), mpathy_our_crew_path44 || (mpathy_our_crew_path44 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M2444 4892c26 0 52-1 78-2 25-1 50-3 74-6h1l52-14c17-4 35-9 53-14 35-11 70-22 105-34s70-27 105-40c22-9 43-18 66-27-85 11-376 47-569 47-188 0-422-34-497-46 21 9 42 18 63 26 36 13 70 28 105 40s70 23 105 34c18 5 36 10 53 14l52 14c25 3 51 5 76 6 26 1 52 2 78 2z"
  })), mpathy_our_crew_path45 || (mpathy_our_crew_path45 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2456 4921c39 0 76-3 111-7 3-14 13-26 28-30h1c-24 3-49 5-74 6-26 1-52 2-78 2s-52-1-78-2c-25-1-51-3-76-6h3c13 4 24 15 27 28 35 5 74 7 114 8 7 0 15 1 22 1z"
  })), mpathy_our_crew_path46 || (mpathy_our_crew_path46 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2320 4912c-3-13-14-24-27-28h-3l-52-14c-17-4-35-9-53-14-35-11-70-22-105-34s-69-27-105-40c-21-8-42-17-63-26-16-2-25-4-25-4s149 126 433 160zM2567 4914c270-30 434-162 434-162s-8 1-23 3c-23 9-44 18-66 27-35 13-70 28-105 40s-70 23-105 34c-18 5-36 10-53 14l-52 14h-2c-15 4-25 16-28 30z"
  })), mpathy_our_crew_path47 || (mpathy_our_crew_path47 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1896 4415h1082c109 0 198-89 198-198v-79c3 1 5 1 7 2l12 3c3 1 6 1 10 2h2c6 2 12 3 19 4 6 1 13 3 19 4h4c5 1 11 2 17 3s12 1 18 2c4 1 8 1 12 1 5 1 9 1 14 2 7 1 14 1 22 2 7 0 14 1 22 1 5 1 11 1 17 1 4 0 9 1 14 1h22c7 1 14 1 21 1h15c33 0 66-1 98-3-1-26-3-52-5-78-53 4-111 7-169 7-71 0-142-4-208-17v27c0 121-99 220-220 220h-997c-122 0-220-99-220-220v-16c-44 5-90 6-136 6-81 0-161-6-231-13-2 26-4 53-6 80 52 4 106 7 162 7 63 0 127-4 187-13v63c0 109 90 198 198 198z"
  })), mpathy_our_crew_path48 || (mpathy_our_crew_path48 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3541 4164c13-1 25-1 37-2-1-27-3-53-5-80-12 1-24 3-37 4 2 26 4 52 5 78zm-2192-4c2-27 4-54 6-80l-21-3c-7-1-13-2-19-3-2 27-4 55-5 83l39 3z"
  })), mpathy_our_crew_path49 || (mpathy_our_crew_path49 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1698 3659c8-1 16-1 24-2v-96c0-9 1-19 2-28-16 29-26 62-26 97v29zm1478-6v-23c0-30-6-57-17-82v103c6 0 12 1 17 2z"
  })), mpathy_our_crew_path50 || (mpathy_our_crew_path50 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M1890 4011c-153 62-390 49-552 29-97-11-165-101-151-198 13-88 91-152 180-148 151 7 378 11 522-21l1 338z"
  })), mpathy_our_crew_path51 || (mpathy_our_crew_path51 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1587 4020c46 0 91-2 135-7v-138c-44 5-90 7-136 7-88 0-176-7-248-16-42-5-78-24-104-52-5 10-8 22-10 34-6 37 4 73 26 103 23 29 56 48 93 53 73 8 159 16 244 16z"
  })), mpathy_our_crew_path52 || (mpathy_our_crew_path52 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M1876 3977c-144 58-369 46-533 27-37-5-70-24-93-53-22-30-32-66-26-103 10-70 71-120 141-117 161 8 381 10 527-21 14 15 40 86 33 166-2 25-11 85-49 101zm-290 116c114 0 229-12 318-48 107-43 110-213 79-315-31-98-82-98-102-93-137 30-354 28-512 20-108-5-202 72-218 180-9 57 6 113 41 159 34 45 85 74 142 81 75 9 163 16 252 16z"
  })), mpathy_our_crew_path53 || (mpathy_our_crew_path53 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3615 4040c-76 10-168 17-261 16h-39c-5-1-9-1-14-1s-10-1-16-1-13-1-19-1h-1c-6-1-13-1-20-2-4 0-8-1-13-1-3-1-7-1-11-1-5-1-11-2-17-3-5 0-10-1-15-2-1 0-2 0-3-1-6 0-12-2-18-3l-18-3h-2l-9-3c-4 0-7-1-11-2-11-3-22-6-32-9-6-2-12-4-17-6-6-2-11-4-16-6v-162l1-176c37 8 79 14 124 18 131 12 286 8 398 3h8c86 0 159 63 172 148 14 97-54 187-151 198z"
  })), mpathy_our_crew_path54 || (mpathy_our_crew_path54 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M3366 4020c85 0 171-8 245-16 36-5 69-24 92-53 22-30 32-66 26-103-1-7-2-14-4-21-28 31-66 53-110 58-72 9-159 16-247 16h-33c-7 0-14 0-20-1h-14c-5 0-10-1-16-1s-13-1-19-1h-1c-7-1-13-1-20-2-4-1-8-1-13-2-3 0-7 0-11-1-5 0-11-1-17-2-5-1-10-1-15-2-1 0-2-1-3-1l-18-3c-3 0-6-1-9-2v118c64 14 135 19 207 19z"
  })), mpathy_our_crew_path55 || (mpathy_our_crew_path55 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M3594 3731c68 0 125 49 135 117 6 37-4 73-26 103-23 29-56 48-92 53-164 19-390 31-534-27l-14 34 14-34c-38-16-47-76-49-101-7-80 19-151 33-166 146 31 366 29 527 21h6zm-227 362c89 0 177-7 252-16 57-7 108-36 142-81 35-46 50-102 41-159-15-108-109-185-218-180-157 8-374 10-512-20-20-5-71-5-102 93-31 102-28 272 79 315 89 36 204 48 318 48z"
  })), mpathy_our_crew_path56 || (mpathy_our_crew_path56 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M3122 3561v542c0 100-82 183-183 183h-997c-101 0-183-83-183-183v-542c0-100 82-183 183-183h997c59 0 112 29 146 73 23 30 37 69 37 110z"
  })), mpathy_our_crew_path57 || (mpathy_our_crew_path57 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M2212 4087c12 0 23 0 36-1 313-18 359-270 359-270h30c3-30 14-57 32-79 28-38 74-63 125-63 64 0 119 38 143 93 7 15 12 31 14 49h29s-1 162 60 163c19 0 33-11 45-31v-387c0-80-65-146-146-146h-997c-81 0-146 66-146 146v147c143 100 96 379 416 379z"
  })), mpathy_our_crew_path58 || (mpathy_our_crew_path58 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M1942 4249h997c81 0 146-66 146-146v-155c-12 20-26 31-45 31-61-1-60-163-60-163h-29v16c0 7 0 15-1 22-11 76-76 136-156 136-79 0-145-59-156-135-1-7-2-15-2-23 0-6 1-11 1-16h-30s-46 252-359 270c-13 1-24 1-36 1-320 0-273-279-416-379v395c0 80 65 146 146 146z"
  })), mpathy_our_crew_path59 || (mpathy_our_crew_path59 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2939 3415c81 0 146 66 146 146v542c0 80-65 146-146 146h-997c-81 0-146-66-146-146v-542c0-80 65-146 146-146h997zm-997 908h997c121 0 220-99 220-220v-542c0-121-99-220-220-220h-997c-122 0-220 99-220 220v542c0 121 98 220 220 220z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M2951 3832c0 87-70 158-157 158s-158-71-158-158 71-158 158-158 157 71 157 158z",
    style: {
      fill: "#22a7f0",
      fillRule: "nonzero"
    }
  }), mpathy_our_crew_path60 || (mpathy_our_crew_path60 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M2951 3832c0 9 0 17-2 25-12-75-77-132-155-132-79 0-144 57-156 132-1-8-2-16-2-25 0-87 71-158 158-158s157 71 157 158z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M2794 3989c78 0 143-57 155-132-3-21-10-40-21-57-27 45-77 75-134 75s-107-30-134-75c-11 17-18 36-22 57 12 75 77 132 156 132z",
    style: {
      fill: "#2976b4",
      fillRule: "nonzero"
    }
  }), mpathy_our_crew_path61 || (mpathy_our_crew_path61 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M2638 3857c4-21 11-40 22-57-5-8-9-16-13-25-7 18-11 37-11 57 0 8 1 17 2 25zm311 0c2-8 2-17 2-25 0-20-3-39-10-57-4 9-8 17-13 25 11 17 18 36 21 57z"
  })), mpathy_our_crew_path62 || (mpathy_our_crew_path62 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M2794 3702c72 0 130 58 130 130s-58 130-130 130-130-58-130-130 58-130 130-130zm0 315c102 0 185-83 185-185s-83-185-185-185-185 83-185 185 83 185 185 185zM2347 4323c21 0 37-17 37-37v-315c0-56-27-111-72-144l-84-64c-27-20-43-52-43-86v-299c0-20-17-37-37-37-21 0-37 17-37 37v299c0 57 27 111 72 145l85 64c27 20 42 52 42 85v315c0 20 17 37 37 37z"
  })), mpathy_our_crew_path63 || (mpathy_our_crew_path63 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M1133 2662c-87 362-453 328-553 304-210-51-282-249-282-249l169-224 75-121 90-27c71-129 221-275 308-223 0 0 269 227 193 540z"
  })), mpathy_our_crew_path64 || (mpathy_our_crew_path64 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M631 2785c32 0 66-3 102-7 72-8 135-43 172-97-58-55-70-119-68-168-38 35-75 53-108 58l-25 63c-2 4-4 7-6 10 4 12 6 25 6 38 0 23-8 57-47 87-8 6-17 12-26 16z"
  })), mpathy_our_crew_path65 || (mpathy_our_crew_path65 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M278 2234c84 84 157 146 157 146l234 240 159-386s1-78-6-182c-11-204-50-508-177-500-227 14-77 613-77 613s-362-484-508-346c-85 80 81 278 218 415z"
  })), mpathy_our_crew_path66 || (mpathy_our_crew_path66 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M639 2332c38-64 94-131 151-174-1-24-1-50-3-78-62 49-146 117-179 160-20 26-48 35-81 35-36 0-76-11-116-21-28-8-55-15-80-19 16 16 32 31 47 45 11-1 23-2 35-2 67 0 156 20 226 54z"
  })), mpathy_our_crew_path67 || (mpathy_our_crew_path67 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "m791 2226-135 328-195-200c-1-1-2-1-2-2-147-124-382-363-385-474 0-19 6-27 12-32 12-12 26-16 44-15 124 11 337 261 409 356 10 14 29 19 45 11 16-7 25-25 20-42-28-114-86-433-10-537 14-19 31-28 54-30 7 0 18 1 32 14 94 89 112 473 111 623zm-122 431h7c13-3 23-11 28-23l158-386c2-5 3-9 3-14 0-56 2-556-134-684-25-25-56-37-88-35-44 3-82 24-108 60-73 99-56 307-33 451-97-110-247-258-365-268-40-4-75 8-102 34-24 22-36 53-35 88 5 179 362 487 409 527l234 239c7 7 16 11 26 11z"
  })), mpathy_our_crew_path68 || (mpathy_our_crew_path68 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M255 2675c56 90 292 133 380 65 74-58 0-132-21-151-4-3-6-4-6-4s91-28 107-105c1-5 2-10 2-15 6-88-230-165-337-147-80 12-111 45-118 80-8 37 10 77 22 98 5 10 10 15 10 15s-84 92-39 164z"
  })), mpathy_our_crew_path69 || (mpathy_our_crew_path69 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M571 2586c0-3 0-5 1-8 2-13 12-25 25-29 0 0 11-3 25-11-10-12-18-26-23-41-15 1-31 1-47 1-83 0-178-15-254-70 3 25 19 52 26 62 6 8 8 18 6 28 61 27 147 57 241 68zM506 2736c45 0 84-9 106-26 16-12 18-22 18-28 0-2 0-5-1-7-29 16-69 23-111 23-90 0-192-31-238-81-2 13-1 27 6 39 20 31 80 61 150 74 24 4 47 6 70 6z"
  })), _path70 || (_path70 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M414 2352c76 0 195 34 248 82 12 11 18 21 18 28-4 62-82 87-83 87-13 4-23 16-25 29-3 14 3 27 13 36 15 11 45 43 45 68 0 6-2 16-18 28-32 25-103 33-176 20-70-13-130-43-150-74-28-47 34-119 35-120 12-13 13-32 3-46s-36-61-24-92c12-27 53-39 86-44 8-1 18-2 28-2zm92 458c63 0 116-14 151-41 39-30 47-64 47-87 0-34-16-64-34-86 37-23 80-64 84-129 1-21-5-54-43-88-78-72-249-112-337-98-75 12-123 42-142 89-22 53 0 108 17 139-27 37-69 115-26 185 32 51 106 92 200 109 29 5 57 7 83 7z"
  })), _path71 || (_path71 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M579 2623c10 0 21-1 31-1 21-2 36-19 35-39-1-21-19-37-39-35-159 9-292-68-294-68-17-11-40-5-50 13-10 17-5 40 13 50 6 4 136 80 304 80z"
  })), _path72 || (_path72 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M940 2122c-115-69-342 211-346 336-4 96 110 176 245 54 138-124 281-283 101-390z"
  })), _path73 || (_path73 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M298 2717s72 198 282 249c100 24 466 58 553-304 76-313-193-540-193-540-115-69-342 211-346 336-4 96 139 150 258-18 0 0-63 153 71 257l-316 182-239-47-70-115z"
  })), _path74 || (_path74 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "m861 2624 6-4c-5-4-9-7-13-11 2 5 4 10 7 15z"
  })), _path75 || (_path75 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M613 2516c-11-13-18-30-19-50 1 20 8 37 19 50z"
  })), _path76 || (_path76 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M687 2548c34 0 75-15 116-52 6-50 44-85 44-85 3-10 0-14-7-14-14 0-48 19-87 38-40 19-85 38-124 38-13 0-24-2-35-7 1 20 8 37 19 50 17 20 43 32 74 32z"
  })), _path77 || (_path77 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil9",
    d: "M413 2878c-17-15-32-30-45-46 13 16 28 31 45 46zm732-369c-1-6-1-13-2-19 1 6 1 13 2 19z"
  })), _path78 || (_path78 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M757 2978c117-10 255-56 334-202-77 142-210 190-325 201-3 0-6 0-9 1z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M708 2980c16 0 32-1 49-2-17 1-33 2-49 2-55 0-101-8-128-14-35-9-66-21-94-36 28 15 59 27 94 36 27 6 73 14 128 14z",
    style: {
      fill: "#8c7b94",
      fillRule: "nonzero"
    }
  }), _path79 || (_path79 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil4",
    d: "M486 2930c-3-2-6-4-10-6-23-14-45-30-63-46 21 19 45 36 73 52zm605-154c17-33 32-71 42-114 13-54 16-105 12-153 4 48 1 99-12 153-10 43-25 81-42 114z"
  })), _path80 || (_path80 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M708 2980c16 0 32-1 49-2 3-1 6-1 9-1-20 2-39 3-58 3-55 0-101-8-128-14-39-10-74-24-104-42 4 2 7 4 10 6 28 15 59 27 94 36 27 6 73 14 128 14zm-299-140-27-5 27 5z"
  })), _path81 || (_path81 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil9",
    d: "M1143 2490v-1 1zm0-1zm-1-1z"
  })), _path82 || (_path82 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil3",
    d: "M708 2980c19 0 38-1 58-3 115-11 248-59 325-201 17-33 32-71 42-114 13-54 16-105 12-153-1-6-1-13-2-19v-1s0-1-1-1c-17-132-87-238-140-301 61 96 114 236 75 398-63 264-276 318-425 318-55 0-101-8-128-14-45-11-83-28-115-49l-27-5-14-3c13 16 28 31 45 46 18 16 40 32 63 46 30 18 65 32 104 42 27 6 73 14 128 14z"
  })), _path83 || (_path83 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M298 2717c1 2 6 17 19 39l6 2-25-41zM312 2755c4 4 7 8 11 12-2-3-5-7-6-11l-5-1z"
  })), _path84 || (_path84 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M987 2913c20-4 39-13 56-24 18-12 33-26 46-41 27-32 47-68 60-106 26-76 40-157 32-237-7-80-33-157-71-226-19-35-41-67-65-98-12-16-25-31-38-45l-21-21c-7-8-13-14-22-22-2-1-3-2-4-3h-1c-24-14-53-18-77-15-24 4-45 12-64 22-19 9-36 21-52 33s-31 25-45 39c-28 27-53 56-76 87-23 32-43 65-60 101-8 18-16 37-22 57-2 11-5 22-6 34v18c1 6 0 13 2 19 4 26 19 51 39 68 19 17 44 28 69 31 6 1 12 1 18 1s12 0 18-1c11-1 23-3 34-7 5-1 11-3 16-5l15-7c10-5 19-11 28-17 35-24 62-55 86-87l-64-35c-4 8-5 14-7 21s-4 13-5 20c-3 13-4 27-5 40-2 28 0 56 6 83 2 14 8 28 13 41 3 6 7 12 11 18 3 7 8 12 13 17 18 22 43 37 72 41 7 1 14-5 15-12 1-2 1-4 0-5v-3c-4-14-9-24-13-34-4-11-10-19-13-29-9-17-17-35-23-53-6-19-9-39-7-59 0-10 1-21 4-31 1-5 2-10 3-14 1-5 3-11 4-13v-1c7-19-2-40-22-47-15-6-33-1-42 12-20 27-42 52-68 69-25 17-53 27-77 23-12-1-22-6-30-13s-14-15-15-26c-1-2-1-5-1-8v-9c1-6 2-13 4-21 4-14 10-30 17-45 29-61 72-118 121-166 24-24 51-45 79-60 13-7 27-12 39-13 13-2 22 0 30 5l-5-4c5 5 12 11 18 17s12 13 18 19c12 13 24 27 35 40 22 28 41 58 58 88 34 62 57 129 63 197 6 69-4 139-32 202-13 32-29 61-47 90-18 28-37 55-57 90-3 6-1 15 5 18 3 2 7 2 10 2zM263 2730c4 10 7 17 11 26 4 8 8 15 12 23s9 15 14 23l15 21 16 21 18 19c12 13 25 25 39 36 13 11 28 21 42 30 16 9 31 18 47 24 31 15 67 22 102 16 2-1 3-2 3-4 0-1-1-2-1-2h-1c-27-24-53-38-79-55-13-8-24-18-37-27-11-10-22-19-33-31-5-5-10-10-15-16s-10-11-14-17l-14-18-13-18c-8-13-16-26-23-39-4-6-7-13-10-19-4-7-7-14-9-19l-1-2c-9-19-30-27-49-19-18 8-27 28-20 47zM873 3647c68 0 301-19 376-260 107-348-50-605-57-615-8-13-26-17-39-9-12 8-16 25-8 38 2 3 150 247 51 569-74 240-327 222-338 221-15-1-28 10-30 25-1 15 10 29 25 30 1 0 8 1 20 1zM3533 3724c2 0 5 0 7-1 282-77 353-306 356-315 4-15-4-30-19-35-14-4-30 4-34 19-3 9-66 209-317 278-15 4-24 19-20 34 3 12 15 20 27 20z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M4768 1734c7 0 15-2 22-6l273-160c16-9 33-13 51-13 9 0 17 1 25 3 54 14 109 22 164 22h6c354 0 647-288 653-642 2-176-64-343-188-468-124-126-289-195-465-195h-13c-356 7-643 302-640 658 1 159 61 313 168 432 30 33 35 82 12 121l-106 183c-10 17-7 38 7 53 8 8 19 12 31 12z",
    style: {
      fill: "#f9195a",
      fillRule: "nonzero"
    }
  }), _path85 || (_path85 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil2",
    d: "M5309 231c188 0 364 74 496 208s203 312 200 500c-6 378-318 685-696 685h-6c-59-1-118-9-175-24-4-1-9-2-14-2-10 0-20 3-29 8l-273 160c-14 8-29 12-44 12-23 0-45-9-62-26-28-28-34-71-14-105l107-183c13-22 10-51-7-70-115-127-178-290-180-461-2-380 304-694 683-702h14zm0 87h-12c-332 7-600 282-597 614 1 155 60 296 157 403 43 48 49 118 17 174l-106 182 273-160c23-13 48-20 73-20 12 0 25 2 37 5 49 13 100 20 153 21h5c330 0 604-269 609-600 5-341-269-619-609-619z"
  })), /*#__PURE__*/external_react_.createElement("path", {
    d: "M5826 1238c5-4 9-9 14-14 48-85 76-183 78-287 1-87-16-170-47-245-91-216-303-369-551-374h-23c-23 1-45 3-67 5l-1 1h-3c-137 19-260 84-352 178-6 11-12 23-18 34 107-102 251-166 409-170h12c340 0 614 278 609 619-1 91-23 177-60 253z",
    style: {
      fill: "#fc8cad",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M5871 692c-91-216-303-369-551-374 248 5 460 158 551 374zm-645-368zm1 0h1-1zm1 0h1-1zm1 0 1-1-1 1zm1-1c22-2 44-4 67-5h8-8c-23 1-45 3-67 5z",
    style: {
      fill: "#9b8da2",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "m4768 1691 101-59 172-101c23-13 48-20 73-20 12 0 25 2 37 5h1c24 7 48 12 73 15h2c25 4 51 5 77 6h5c67 0 131-11 191-31 0-1 1-1 1-1h2c144-49 264-150 338-281h-1c-12 22-26 43-41 63 10-16 19-32 27-49-110 106-259 171-421 171h-5c-53-1-104-8-153-21-5-1-13-2-23-3-90-6-172-55-227-127-14-18-29-34-44-51-97-106-156-248-157-403-1-95 21-187 60-268-25 25-49 51-69 80 24-41 54-80 87-114-109 111-176 264-174 430 1 154 59 294 154 400v1c1 0 1 0 1 1 0 0 1 1 2 1 25 28 38 64 37 100 0 25-6 50-19 72l-29 50-78 134z",
    style: {
      fill: "#b31d61",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "m4768 1691 78-134-78 134zm101-59 172-101c23-13 48-20 73-20 12 0 25 2 37 5-12-3-25-5-37-5-25 0-50 7-73 20l-172 101zm440-95c67 0 131-11 191-31-60 20-124 31-191 31h-5c-26-1-52-2-77-6 25 4 51 5 77 6h5zm-82-6h-1 1zm-1 0zm-1 0zm276-26zm0 0h1-1zm1 0h1-1zm-608-70c1-36-12-72-37-100-1 0-2-1-2-1 26 28 39 64 39 101zm-40-102zm0-1z",
    style: {
      fill: "#2b1e52",
      fillRule: "nonzero"
    }
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M5799 1287c15-20 29-41 41-63-5 5-9 10-14 14-8 17-17 33-27 49zM4787 616c20-29 44-55 69-80 6-11 12-23 18-34-33 34-63 73-87 114z",
    style: {
      fill: "#b56e9b",
      fillRule: "nonzero"
    }
  }), _path86 || (_path86 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil1",
    d: "M5087 724c62-62 163-51 225 11l10 10 9-10c63-62 164-73 226-11s62 163 0 225l-10 10-195 196c-17 16-43 16-60 0l-196-196-9-10c-62-62-62-163 0-225z"
  })), _path87 || (_path87 = /*#__PURE__*/external_react_.createElement("path", {
    className: "mpathy-our-crew_svg__fil17",
    d: "M5109 887c11 0 22-25 39-48 19-26 38-41 27-49-4-3-11-4-19-4-16 0-36 6-49 24-19 26-13 68-2 76 2 1 3 1 4 1zM5208 774c2 0 4 0 7-1 7-3 12-10 11-18-1-6-7-10-14-10-2 0-5 1-8 2-10 4-14 14-10 21 3 4 9 6 14 6z"
  }))));
};
/* harmony default export */ const mpathy_our_crew = (SvgMpathyOurCrew);
;// CONCATENATED MODULE: ./src/components/ui/MouseScroll.js

const MouseSCcroll = ({ removeScroller  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: ` mouse_scroll ${removeScroller ? "remove-scroll" : ""} `,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mouse",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "wheel"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "m_scroll_arrows unu"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "m_scroll_arrows doi"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "m_scroll_arrows trei"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const MouseScroll = (MouseSCcroll);

;// CONCATENATED MODULE: ./src/components/layout/sections/Hero.js











const Hero = ({ title , description  })=>{
    const { pathname  } = (0,router_.useRouter)();
    const [removeScroller, setRemoveScroller] = (0,external_react_.useState)(false);
    const isMainPage = pathname === "/";
    const isOurMissionPage = pathname === "/our-mission";
    const isJoinUsPage = pathname === "/get-involved";
    const isOurCrewPage = pathname === "/our-team";
    (0,external_react_.useEffect)(()=>{
        const handleScroll = ()=>{
            let height = screen.height;
            let top = window.pageYOffset;
            if (top > height / 4) {
                setRemoveScroller(true);
                return;
            }
            setRemoveScroller(false);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `container ${(Hero_module_default()).Hero} ${isOurCrewPage ? (Hero_module_default()).OurCrewHero : ""} ${isMainPage ? (Hero_module_default()).HeroExtendedPadding : ""} ${isJoinUsPage ? (Hero_module_default()).HeroSvgJoinUsPosition : ""} ${isOurMissionPage ? (Hero_module_default()).HeroSvgOurMissionPosition : ""}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    isMainPage && /*#__PURE__*/ jsx_runtime_.jsx(mpathy_hero, {}),
                    isJoinUsPage && /*#__PURE__*/ jsx_runtime_.jsx(mpathy_join_us, {}),
                    isOurMissionPage && /*#__PURE__*/ jsx_runtime_.jsx(mpathy_our_mission, {}),
                    isOurCrewPage && /*#__PURE__*/ jsx_runtime_.jsx(mpathy_our_crew, {})
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    isMainPage && /*#__PURE__*/ jsx_runtime_.jsx(mpathy_title, {
                        className: (Hero_module_default()).Title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        dangerouslySetInnerHTML: {
                            __html: title
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: isMainPage || isJoinUsPage ? (Hero_module_default()).MaxWidth : "",
                        dangerouslySetInnerHTML: {
                            __html: description
                        }
                    }),
                    (isMainPage || isJoinUsPage) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Hero_module_default()).LinksWrapper,
                        children: [
                            !isJoinUsPage && /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "https://www.paypal.com/donate/?hosted_button_id=8XD94W7RRUQMC",
                                target: "_blank",
                                children: "Donate"
                            }),
                            isMainPage && /*#__PURE__*/ jsx_runtime_.jsx(ui_Link, {
                                type: isMainPage && "transparent",
                                href: "/get-envolved",
                                children: "Join us"
                            })
                        ]
                    })
                ]
            }),
            !isMainPage && /*#__PURE__*/ jsx_runtime_.jsx(MouseScroll, {
                removeScroller: removeScroller
            })
        ]
    });
};
/* harmony default export */ const sections_Hero = (Hero);


/***/ }),

/***/ 8017:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);


const SEO = ({ metaTitle , metaDescription  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
        canonical: "https://mpathyapps.com/",
        title: metaTitle,
        description: metaDescription,
        openGraph: {
            url: "https://mpathyapps.com/",
            title: "Mpathy emotional revolution | Social Enterprise",
            description: "Mpathy Apps is a unique Social Enterprise, dedicated to developing and distributing new mobile applications to boost positive emotional resilience and mental health.",
            images: [
                {
                    url: "https://mpathyapps.com/assets/mpathy-share.jpg",
                    width: 800,
                    height: 600,
                    alt: "og-image",
                    type: "image/jpg"
                }
            ],
            site_name: "https://mpathyapps.com/"
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SEO);


/***/ })

};
;