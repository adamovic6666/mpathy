import PrivacyPolicy from "../src/components/layout/sections/PrivacyPolicy";

const privacyPolicy = () => {
  return <PrivacyPolicy />;
};

export default privacyPolicy;
