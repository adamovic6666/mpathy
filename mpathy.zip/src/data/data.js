export const NAV_LINKS = [
  { id: 1, name: "home", href: "" },
  { id: 2, name: "our mission", href: "our-mission" },
  { id: 3, name: "our team", href: "our-team" },
  { id: 4, name: "get involved", href: "get-involved" },
];
